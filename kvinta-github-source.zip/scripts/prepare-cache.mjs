import fs from 'node:fs';import path from 'node:path';
import {createHash} from 'node:crypto';
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(e.name.startsWith('.')||e.name==='server'||e.name==='sw.js')continue;const file=path.join(dir,e.name);if(e.isDirectory())walk(file);else files.push('./'+path.relative('dist',file).replaceAll('\\','/'));}}
walk('dist');files.sort();const hash=createHash('sha256');for(const file of files){hash.update(file);hash.update(fs.readFileSync(path.join('dist',file.slice(2))));}
fs.writeFileSync('dist/sw.js',`const CACHE='kvinta-shell-v221-${hash.digest('hex').slice(0,12)}';
const FILES=${JSON.stringify(files)};
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(names=>Promise.all(names.filter(n=>n.startsWith('kvinta-shell-')&&n!==CACHE).map(n=>caches.delete(n)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/'))return;
 event.respondWith((async()=>{const cache=await caches.open(CACHE);
  if(event.request.mode==='navigate'){
   const base=new URL('./',self.registration.scope),songRoot=new URL('songs/',base);
   const page=new URL(url.pathname.startsWith(songRoot.pathname)?'songs/index.html':'index.html',base);
   return await cache.match(page.href)||fetch(event.request);
  }
  return await cache.match(event.request)||fetch(event.request);
 })());
});
`);
