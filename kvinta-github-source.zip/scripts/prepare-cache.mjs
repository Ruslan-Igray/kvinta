import fs from 'node:fs';import path from 'node:path';
import {createHash} from 'node:crypto';
const version=JSON.parse(fs.readFileSync('package.json','utf8')).version;
fs.writeFileSync('dist/version.json',JSON.stringify({version}));
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(e.name.startsWith('.')||e.name==='server'||e.name==='sw.js')continue;const file=path.join(dir,e.name);if(e.isDirectory())walk(file);else files.push('./'+path.relative('dist',file).replaceAll('\\','/'));}}
walk('dist');files.sort();const hash=createHash('sha256');for(const file of files){hash.update(file);hash.update(fs.readFileSync(path.join('dist',file.slice(2))));}
const revision=hash.digest('hex').slice(0,12),hashes=Object.fromEntries(files.map(file=>[file,createHash('sha256').update(fs.readFileSync(path.join('dist',file.slice(2)))).digest('hex')]));
const updateWorker=fs.readFileSync('dist/modules/update-worker.js','utf8').replace(/^export /gm,''),updateCache=fs.readFileSync('dist/modules/update-cache.js','utf8').replace(/^export /gm,'');
fs.writeFileSync('dist/sw.js',`${updateWorker}
${updateCache}
const REVISION=${JSON.stringify(revision)};
const HASHES=${JSON.stringify(hashes)};
const CACHE='kvinta-shell-v290-${revision}';
const WORKER_VERSION=${JSON.stringify(version)};
const FILES=${JSON.stringify(files)};
function requestLegacyRefresh(){self.registration.active?.postMessage({type:'KVINTA_REFRESH_LEGACY',version:WORKER_VERSION});}
self.addEventListener('install',event=>event.waitUntil(cacheRelease({caches,cacheName:CACHE,files:FILES,scope:self.registration.scope,revision:REVISION,hashes:HASHES}).then(async()=>{if(!self.registration.active||await clientsReady(self.clients,{scope:self.registration.scope}).catch(()=>false))await self.skipWaiting();})));
self.addEventListener('message',event=>{if(event.data?.type==='KVINTA_GET_VERSION'){event.ports?.[0]?.postMessage({version:WORKER_VERSION});return;}if(event.data?.type==='KVINTA_REFRESH_LEGACY'&&event.data.version===WORKER_VERSION){event.waitUntil((async()=>{for(let i=0;i<40&&self.registration.active?.state!=='activated';i++)await new Promise(resolve=>setTimeout(resolve,25));if(self.registration.active?.state==='activated')await refreshSafeLegacyClients(self.clients,{scope:self.registration.scope,version:WORKER_VERSION}).catch(()=>{});})());return;}if(event.data?.type==='KVINTA_APPLY_UPDATE')event.waitUntil((async()=>{if(await clientsReady(self.clients,{scope:self.registration.scope}).catch(()=>false)){await self.skipWaiting();try{await self.clients.claim();}catch{return;}requestLegacyRefresh();}else event.source?.postMessage({type:'KVINTA_UPDATE_DEFERRED'});})());});
// Navigation fetches wait for activation to finish. Refresh old pages in a separate message event.
self.addEventListener('activate',event=>event.waitUntil((async()=>{const names=await caches.keys(),keep=new Set([CACHE,...names.filter(n=>n.startsWith('kvinta-shell-')&&n!==CACHE).slice(-2)]);await Promise.all(names.filter(n=>n.startsWith('kvinta-shell-')&&!keep.has(n)).map(n=>caches.delete(n)));await self.clients.claim();requestLegacyRefresh();})()));
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/'))return;
 event.respondWith((async()=>{const cache=await caches.open(CACHE);
  if(url.pathname===new URL('version.json',self.registration.scope).pathname)return fetch(event.request,{cache:'no-store'});
  if(event.request.mode==='navigate'){
   const base=new URL('./',self.registration.scope),songRoot=new URL('songs/',base);
   const page=new URL(url.pathname.startsWith(songRoot.pathname)?'songs/index.html':'index.html',base);
   return await cache.match(page.href)||fetch(event.request);
  }
  return await cache.match(event.request)||fetch(event.request);
 })());
});
`);
