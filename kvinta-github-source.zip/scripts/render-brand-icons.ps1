Add-Type -AssemblyName System.Drawing
# Raster exports of the selected vector concept. No external fonts or image assets.
foreach ($size in @(192,512)) {
 $bitmap = [System.Drawing.Bitmap]::new($size,$size)
 $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
 $path = [System.Drawing.Drawing2D.GraphicsPath]::new([System.Drawing.Drawing2D.FillMode]::Alternate)
 $brush = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#edc892'))
 try {
  $graphics.Clear([System.Drawing.ColorTranslator]::FromHtml('#181b22'))
  $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
  $factor = $size / 512.0
  $graphics.Transform = [System.Drawing.Drawing2D.Matrix]::new([single](6*$factor),0,0,[single](6*$factor),[single](64*$factor),[single](64*$factor))
  $path.AddBezier(12,11,25,3,45,2,54,11)
  $path.AddBezier(54,11,64,22,57,37,50,47)
  $path.AddBezier(50,47,39,63,31,67,21,54)
  $path.AddBezier(21,54,9,40,-5,22,12,11)
  $path.CloseFigure()
  foreach ($bar in @(@(14,27,9),@(22,21,21),@(30,14,36),@(38,21,21),@(46,27,9))) {
   $x=[single]$bar[0];$y=[single]$bar[1];$height=[single]$bar[2]
   $path.StartFigure()
   $path.AddArc($x,$y,4,4,180,90)
   $path.AddArc($x,$y,4,4,270,90)
   $path.AddArc($x,($y+$height-4),4,4,0,90)
   $path.AddArc($x,($y+$height-4),4,4,90,90)
   $path.CloseFigure()
  }
  $graphics.FillPath($brush,$path)
  $bitmap.Save((Join-Path (Get-Location).Path "dist/icon-$size.png"),[System.Drawing.Imaging.ImageFormat]::Png)
 } finally {$brush.Dispose();$path.Dispose();$graphics.Dispose();$bitmap.Dispose()}
}
