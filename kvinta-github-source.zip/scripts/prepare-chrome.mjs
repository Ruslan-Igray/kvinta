import fs from 'node:fs';
import {appHeaderMarkup} from '../dist/modules/app-chrome.js';
function prepare(path,mode){
 let html=fs.readFileSync(path,'utf8');
 html=html.replace(/<body(?: class="[^"]*")?>/,'<body class="kv-app-body">');
 html=html.replace(/<link rel="stylesheet" href="(?:\.\/|\.\.\/)?app-chrome\.css">/g,'');
 html=html.replace('</head>','<link rel="stylesheet" href="'+(mode==='song'?'../':'./')+'app-chrome.css"></head>');
 if(mode==='tools')html=html.replace(/class="app(?: kv-app-frame)?"/,'class="app kv-app-frame"').replace(/<header class="(?:kv-chrome )?topbar">[\s\S]*?<\/header>/,appHeaderMarkup(mode));
 else html=html.replace(/<div class="qs-phone(?: kv-app-frame)?"([\s\S]*?)>[\s\S]*?<\/div><\/div><\/section>/,'<div class="qs-phone kv-app-frame"$1>'+appHeaderMarkup(mode)+'</div></div></section>');
 fs.writeFileSync(path,html);
}
prepare('dist/index.html','tools');prepare('features/songs/src/index.html','song');
