import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url)),feature=path.join(root,'features/songs'),previous=process.cwd();
try{process.chdir(feature);await import('../features/songs/scripts/prepare-ui.mjs');}finally{process.chdir(previous);}
fs.mkdirSync(path.join(root,'dist/songs'),{recursive:true});
for(const name of fs.readdirSync(path.join(feature,'dist')))if(name!=='sw.js')fs.copyFileSync(path.join(feature,'dist',name),path.join(root,'dist/songs',name));
fs.copyFileSync(path.join(feature,'assets/lucide.js'),path.join(root,'dist/songs/lucide.js'));

for(const name of ['select-wheel.js','drum-picker.js'])fs.copyFileSync(path.join(root,'dist/modules',name),path.join(root,'dist/songs',name));
