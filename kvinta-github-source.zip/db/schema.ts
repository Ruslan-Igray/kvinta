import {sqliteTable,text,integer,index} from 'drizzle-orm/sqlite-core';
export const instances=sqliteTable('telemetry_instances',{
 id:text('id').primaryKey(),source:text('source').notNull(),platform:text('platform').notNull(),firstSeen:integer('first_seen').notNull(),lastSeen:integer('last_seen').notNull(),installedAt:integer('installed_at'),
},t=>[index('telemetry_instances_installed').on(t.installedAt)]);
export const events=sqliteTable('telemetry_events',{
 id:text('id').primaryKey(),instanceId:text('instance_id').notNull().references(()=>instances.id),type:text('type').notNull(),day:text('day').notNull(),occurredAt:integer('occurred_at').notNull(),
},t=>[index('telemetry_events_day_type').on(t.day,t.type),index('telemetry_events_instance_day').on(t.instanceId,t.day)]);
export const songRequestLimits=sqliteTable('song_request_limits',{
 id:text('id').primaryKey(),hits:integer('hits').notNull(),expiresAt:integer('expires_at').notNull(),
},t=>[index('song_request_limits_expiry').on(t.expiresAt)]);
