import test from 'node:test';import assert from 'node:assert/strict';
import {createReleaseNoticeState,createReleaseNotice,RELEASE_NOTICE,RELEASE_SEEN_KEY} from '../dist/modules/release-notice.js';
function memory(initial={}){const data=new Map(Object.entries(initial));return {getItem:key=>data.get(key)??null,setItem:(key,value)=>data.set(key,value),removeItem:key=>data.delete(key)};}
const returning=()=>memory({'kvinta.preferences.v1':'{}'});
test('Release notice distinguishes existing users from a clean first launch without needing analytics',()=>{
 const fresh=memory();assert.equal(createReleaseNoticeState({storage:fresh}).pending,false);assert.equal(fresh.getItem(RELEASE_SEEN_KEY),RELEASE_NOTICE.version);
 const old=returning(),state=createReleaseNoticeState({storage:old});assert.equal(state.pending,true);assert.equal(old.getItem(RELEASE_SEEN_KEY),null);state.acknowledge();assert.equal(createReleaseNoticeState({storage:old}).pending,false);
 assert.equal(createReleaseNoticeState({storage:memory({'kvinta-song-current':'{}'})}).pending,true);
});
test('Skipped releases collapse to one current notice; stale code cannot replace a newer seen version',()=>{
 const old=memory({[RELEASE_SEEN_KEY]:'1.9.0'}),state=createReleaseNoticeState({storage:old});assert.equal(state.pending,true);state.acknowledge();assert.equal(old.getItem(RELEASE_SEEN_KEY),RELEASE_NOTICE.version);
 const newer=memory({[RELEASE_SEEN_KEY]:'9.0.0'});assert.equal(createReleaseNoticeState({storage:newer}).pending,false);assert.equal(newer.getItem(RELEASE_SEEN_KEY),'9.0.0');
 assert.equal(createReleaseNoticeState({storage:memory({[RELEASE_SEEN_KEY]:RELEASE_NOTICE.version})}).pending,false);
 const broken={getItem(){throw Error('blocked');},setItem(){throw Error('blocked');}};assert.equal(createReleaseNoticeState({storage:broken}).pending,false);
});
function fixture({storage=returning(),session=memory(),now=1000}={}){
 const events={},timers=new Map(),nodes=[];let nextTimer=0,busy=false,hidden=false;
 const element=tag=>{const handlers={},el={tag,children:[],attrs:{},open:false,removed:false,textContent:'',className:'',append(...children){this.children.push(...children);},setAttribute(k,v){this.attrs[k]=v;},addEventListener(k,cb){handlers[k]=cb;},getClientRects(){return this.open?[{}]:[];},getBoundingClientRect(){return {left:10,right:310,top:30,bottom:330};},showModal(){this.open=true;},close(){this.open=false;handlers.close?.();},remove(){this.removed=true;},fire(k,event={}){handlers[k]?.({target:this,...event});}};return el;};
 const doc={get hidden(){return hidden;},body:{append:node=>nodes.push(node)},createElement:element,querySelector:()=>null,querySelectorAll:()=>busy?[{getClientRects:()=>[{}]}]:nodes.filter(n=>n.open)};
 const win={localStorage:storage,sessionStorage:session,addEventListener:(k,cb)=>events[k]=cb,removeEventListener:k=>delete events[k]};
 const notice=createReleaseNotice({win,doc,storage,session,now:()=>now,later:cb=>{timers.set(++nextTimer,cb);return nextTimer;},cancel:id=>timers.delete(id)});
 return {notice,nodes,events,storage,session,timers,setBusy:v=>busy=v,setHidden:v=>hidden=v,flush(){const callbacks=[...timers.values()];timers.clear();callbacks.forEach(cb=>cb());},ok(){nodes.at(-1).children[2].children[0].fire('click');}};
}
test('Startup consumes its tip slot, shows approved text once, and acknowledges only on dismissal',()=>{
 const f=fixture();assert.equal(f.notice.startup(),true);assert.equal(f.nodes.length,1);assert.equal(f.nodes[0].children[0].textContent,RELEASE_NOTICE.title);assert.deepEqual(f.nodes[0].children[1].children.map(x=>x.textContent),RELEASE_NOTICE.items);
 assert.equal(f.storage.getItem(RELEASE_SEEN_KEY),null);f.notice.startup();assert.equal(f.nodes.length,1);f.ok();assert.equal(f.storage.getItem(RELEASE_SEEN_KEY),RELEASE_NOTICE.version);assert.equal(f.nodes[0].removed,true);assert.equal(f.notice.startup(),true,'No tip after closing the notice in this launch');
 const next=fixture({storage:f.storage});assert.equal(next.notice.startup(),false,'Tips available next ordinary launch');assert.equal(next.nodes.length,0);
});
test('Release notice waits until the existing modal and hidden document are gone; page hide cancels waiting',()=>{
 const f=fixture();f.setBusy(true);assert.equal(f.notice.startup(),true);assert.equal(f.nodes.length,0);f.flush();assert.equal(f.nodes.length,0);f.setBusy(false);f.setHidden(true);f.flush();assert.equal(f.nodes.length,0);f.setHidden(false);f.flush();assert.equal(f.nodes.length,1);
 const away=fixture();away.setBusy(true);away.notice.startup();away.events.pagehide();assert.equal(away.timers.size,0);away.setBusy(false);away.flush();assert.equal(away.nodes.length,0);
});
test('Automatic update restores an unread notice, but never replaces an acknowledged notice with a tip',()=>{
 const first=fixture();first.notice.startup();first.events['kvinta-before-update']();const unread=fixture({storage:first.storage,session:first.session,now:1050});assert.equal(unread.notice.startup(),true);assert.equal(unread.nodes.length,1);unread.ok();unread.events['kvinta-before-update']();
 const reloaded=fixture({storage:first.storage,session:first.session,now:1100});assert.equal(reloaded.notice.startup(),true);assert.equal(reloaded.nodes.length,0);const ordinary=fixture({storage:first.storage,session:first.session,now:1200});assert.equal(ordinary.notice.startup(),false);
});
test('Expired reload handoffs do not suppress ordinary tips and outside clicks acknowledge normally',()=>{
 const f=fixture();f.notice.startup();f.nodes[0].fire('click',{clientX:100,clientY:100});assert.equal(f.notice.pending,true);f.nodes[0].fire('click',{clientX:0,clientY:0});assert.equal(f.notice.pending,false);f.events['kvinta-before-update']();
 const expired=fixture({storage:f.storage,session:f.session,now:122000});assert.equal(expired.notice.startup(),false);
});
test('An unread notice resumes after Safari restores the page from its cache',()=>{const f=fixture();f.setBusy(true);f.notice.startup();f.events.pagehide();assert.equal(f.timers.size,0);f.setBusy(false);f.events.pageshow();assert.equal(f.nodes.length,1);assert.equal(f.nodes[0].open,true);f.ok();assert.equal(f.notice.pending,false);});
