import test from 'node:test';
import assert from 'node:assert/strict';
import {createLiveUpdates,updateBusy,UPDATE_INTERVAL} from '../dist/modules/live-updates.js';
import {clientsReady} from '../dist/modules/update-worker.js';
function fixture({controlled=true,busy=true,waiting=true}={}){
 let time=0,reloads=0,checks=0,block=busy;const timers=[],sent=[];
 const win=new EventTarget();win.Event=Event;win.navigator={onLine:true};
 const doc=new EventTarget();doc.hidden=false;doc.querySelector=()=>null;
 const worker=new EventTarget();worker.state='installed';worker.postMessage=m=>sent.push(m);
 const registration=new EventTarget();Object.assign(registration,{active:controlled?{}:null,waiting:waiting?worker:null,update:async()=>{checks++;}});
 const sw=new EventTarget();sw.controller=controlled?{}:null;sw.register=async()=>registration;
 const updates=createLiveUpdates({scriptUrl:'./sw.js',scope:'./',win,doc,sw,isBusy:()=>block,now:()=>time,repeat:(fn,ms)=>{const timer={fn,ms};timers.push(timer);return timer;},cancel:timer=>{if(timer)timer.cancelled=true;},reload:()=>reloads++});
 return {updates,doc,win,sw,registration,worker,sent,timers,setTime:n=>time=n,setBusy:value=>block=value,idle:()=>timers.find(t=>t.ms===1000).fn(),get reloads(){return reloads;},get checks(){return checks;}};
}
test('A downloaded update waits through playback, then applies in an idle pause without an app restart',async()=>{
 const f=fixture();await f.updates.ready;f.setTime(2000);f.idle();assert.equal(f.sent.length,0);assert.equal(f.updates.pending,true);
 f.setBusy(false);f.idle();assert.deepEqual(f.sent,[{type:'KVINTA_APPLY_UPDATE'}]);f.sw.dispatchEvent(new Event('controllerchange'));assert.equal(f.reloads,1);f.sw.dispatchEvent(new Event('controllerchange'));assert.equal(f.reloads,1);f.updates.dispose();
});
test('An update activated elsewhere never reloads a playing, editing, hidden or touched client',async()=>{
 const f=fixture({waiting:false});await f.updates.ready;f.setTime(5000);f.sw.dispatchEvent(new Event('controllerchange'));assert.equal(f.reloads,0);f.setBusy(false);f.doc.hidden=true;f.idle();assert.equal(f.reloads,0);f.doc.hidden=false;f.doc.dispatchEvent(new Event('pointerdown'));f.idle();assert.equal(f.reloads,0);f.doc.dispatchEvent(new Event('pointercancel'));f.setTime(6300);f.idle();assert.equal(f.reloads,1);f.updates.dispose();
});
test('First installation does not reload, periodic and reconnect checks run while the app remains open',async()=>{
 const f=fixture({controlled:false,waiting:false,busy:false});await f.updates.ready;assert.equal(f.checks,1);f.sw.dispatchEvent(new Event('controllerchange'));assert.equal(f.reloads,0);f.setTime(UPDATE_INTERVAL+1);f.timers.find(t=>t.ms===UPDATE_INTERVAL).fn();await Promise.resolve();assert.equal(f.checks,2);f.sw.dispatchEvent(new Event('controllerchange'));assert.equal(f.reloads,1);f.updates.dispose();assert.ok(f.timers.every(t=>t.cancelled));
});
test('Every client reports real activity to a waiting worker; a blocked peer defers activation',async()=>{
 const f=fixture();await f.updates.ready;let reply;const event=new Event('message');event.data={type:'KVINTA_CAN_UPDATE'};event.ports=[{postMessage:data=>reply=data}];f.setTime(2000);f.sw.dispatchEvent(event);assert.deepEqual(reply,{safe:false});f.setBusy(false);f.sw.dispatchEvent(event);assert.deepEqual(reply,{safe:true});f.idle();const deferred=new Event('message');deferred.data={type:'KVINTA_UPDATE_DEFERRED'};f.sw.dispatchEvent(deferred);f.idle();assert.equal(f.sent.length,2);f.updates.dispose();
});
function channel(){const port1={close(){}},port2={host:port1};return {port1,port2};}
test('Worker requires all open app windows to be safe, including legacy clients with no response',async()=>{
 const scope='https://example.test/kvinta/',page=safe=>({url:scope+'songs/',postMessage(message,[port]){port.host.onmessage({data:{safe}});}});
 const options={scope,makeChannel:channel};assert.equal(await clientsReady({matchAll:async()=>[page(true),page(true)]},options),true);assert.equal(await clientsReady({matchAll:async()=>[page(true),page(false)]},options),false);
 const timers=[];const pending=clientsReady({matchAll:async()=>[{url:scope,postMessage(){}}]},{...options,later:fn=>{timers.push(fn);return fn;},cancel(){}});await Promise.resolve();timers.forEach(fn=>fn());assert.equal(await pending,false);
 assert.equal(await clientsReady({matchAll:async()=>[{url:'https://example.test/elsewhere/'}]},options),true);
});
test('Activity guard covers microphone, set rehearsal, count-in, song editing, open dialogs and loading',()=>{
 const doc={documentElement:{dataset:{}},activeElement:null,querySelector:()=>null,querySelectorAll:()=>[]};assert.equal(updateBusy(doc,{}),false);assert.equal(updateBusy(doc,{kvintaEditing:true}),true);doc.documentElement.dataset.kvintaReady='false';assert.equal(updateBusy(doc,{}),true);doc.documentElement.dataset.kvintaReady='true';doc.querySelector=()=>({});assert.equal(updateBusy(doc,{}),true);doc.querySelector=()=>null;doc.querySelectorAll=()=>[{getClientRects:()=>[{}]}];assert.equal(updateBusy(doc,{}),true);
});
