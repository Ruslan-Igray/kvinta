import test from 'node:test';
import assert from 'node:assert/strict';
import {beatGroups} from '../dist/modules/beat-dots.js';
import {movedOrder,orderIndexAt} from '../dist/modules/order-drag.js';
import {makeRehearsalPlan} from '../dist/modules/rehearsal-model.js';
import {createSetLink,readSetLink} from '../dist/modules/composition-link.js';
import {newSet,addSetChord} from '../dist/modules/composition-model.js';
import {addSection} from '../dist/modules/composition-sections.js';
import {setPlayOrder} from '../dist/modules/arrangement.js';
test('Beat dots encode all supported durations exactly and fit into a single compact row',()=>{
 for(let n=1;n<=32;n++){const groups=beatGroups(n);assert.equal(groups.reduce((sum,g)=>sum+g.dots*g.repeat,0),n);assert.ok(groups.reduce((sum,g)=>sum+g.dots,0)<=8);assert.ok(groups.every(g=>g.dots>0&&g.dots<=4));if(n<=8)assert.ok(groups.every(g=>g.repeat===1));}
 assert.deepEqual(beatGroups(16),[{dots:4,repeat:4}]);assert.deepEqual(beatGroups(11),[{dots:4,repeat:2},{dots:3,repeat:1}]);assert.deepEqual(beatGroups(null),beatGroups(4));
});
test('Reordering moves an occurrence, preserves repeated references, and rejects invalid indices',()=>{
 const source=['verse','verse','chorus','verse','chorus'];assert.deepEqual(movedOrder(source,1,3),['verse','chorus','verse','verse','chorus']);assert.deepEqual(source,['verse','verse','chorus','verse','chorus']);assert.deepEqual(movedOrder(source,4,0),['chorus','verse','verse','chorus','verse']);assert.deepEqual(movedOrder(source,-1,3),source);assert.deepEqual(movedOrder(source,2,99),source);
 const rects=[{top:40,bottom:90},{top:100,bottom:150},{top:160,bottom:210}];assert.equal(orderIndexAt(-20,rects),0);assert.equal(orderIndexAt(120,rects),1);assert.equal(orderIndexAt(230,rects),2);assert.equal(orderIndexAt(10,[]),-1);
});
test('A dragged arrangement plays and shares the resulting order with the same musical durations',()=>{
 let s=addSetChord(newSet(),{root:'A',type:'minor',beats:7}),p=addSection(s,'Припев');s=addSetChord(p.set,{root:'C',type:'major',beats:2,sectionId:p.id});s=setPlayOrder(s,['main','main',p.id]);s=setPlayOrder(s,movedOrder(s.playOrder,2,0));
 const received=readSetLink(new URL(createSetLink(s,'https://example.test/')).hash);assert.deepEqual(makeRehearsalPlan(received).chords.map(c=>[c.root,c.beats]),[['C',2],['A',7],['A',7]]);
});
