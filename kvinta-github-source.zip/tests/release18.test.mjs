import test from 'node:test';
import assert from 'node:assert/strict';
import {newSet,addSetChord,normalizeDraft,createCompositionStore,draftSignature,transposeSet} from '../dist/modules/composition-model.js';
import {addSection,changeSection} from '../dist/modules/composition-sections.js';
import {setPlayOrder,sectionOrder,normalizePlayOrder} from '../dist/modules/arrangement.js';
import {makeRehearsalPlan,rehearsalFrame} from '../dist/modules/rehearsal-model.js';
import {createSetLink,readSetLink} from '../dist/modules/composition-link.js';
import {createTipSession} from '../dist/modules/tip-session.js';
import {tipSwipeDirection} from '../dist/modules/tip-swipe.js';
import {createUpsideTracker,createUpsideController} from '../dist/modules/upside-down.js';
import {createPitchDetector,createPitchTracker,normalizeTuner,centsBetween,frequencyFor} from '../dist/modules/tuner-pitch.js';
import {tuningGuidance} from '../dist/modules/tuner-guidance.js';
import {createTipRotation} from '../dist/modules/tip-rotation.js';
function electricSignal(f,rate,{level=1,noise=0,harmonics=[.002,.03,.001],decay=0}={}){let seed=41;return Float32Array.from({length:16384},(_,i)=>{seed=(seed*1664525+1013904223)>>>0;return level*(harmonics.reduce((s,a,h)=>s+a*Math.sin(2*Math.PI*f*(h+1)*i/rate+.37),0)*Math.exp(-i/rate*decay)+noise*(seed/2**32-.5));});}
test('Quiet electric low E and dominant even partials retain E2 rather than E3 at phone sample rates',()=>{
 for(const rate of [44100,48000,96000])for(const cents of [-20,0,19])for(const options of [{},{level:.008},{harmonics:[.00012,.0003,.00006],noise:.00005,decay:1.5}]){const f=frequencyFor(40)*2**(cents/1200),r=createPitchDetector()(electricSignal(f,rate,options),rate);assert.ok(r.frequency,`quiet E absent at ${rate}`);assert.ok(Math.abs(centsBetween(r.frequency,f))<5,`E octave error: ${r.frequency}`);}
});
test('Harmonic correction does not fold real high notes and fading pure tones to a lower octave',()=>{
 const detect=createPitchDetector();for(const rate of [44100,48000,96000])for(const midi of [28,40,45,50,55,59,64,69,76,83])for(const cents of [-35,13]){const f=frequencyFor(midi)*2**(cents/1200),r=detect(electricSignal(f,rate,{harmonics:[.00025],noise:.000015,decay:1}),rate);assert.ok(r.frequency);assert.ok(Math.abs(centsBetween(r.frequency,f))<5,`${midi}: ${r.frequency}`);}
});
test('Lower volume gate still rejects unpitched noise; unclear estimates never tell the user to tension a string',()=>{
 const detect=createPitchDetector();for(const noise of [.0001,.001,.03])assert.equal(detect(electricSignal(0,48000,{harmonics:[],noise}),48000).frequency,null);
 const tracker=createPitchTracker();let model;for(let i=0;i<12;i++)model=tracker.update({frequency:frequencyFor(40)*.99,clarity:.85,rms:.0002},i*40,normalizeTuner({string:6}));assert.ok(model);assert.equal(model.tuned,false);assert.equal(model.stable,false);assert.equal(tuningGuidance(model).direction,'waiting');
});
test('Humour headings alternate while original phrases and fact/help cadence remain intact',()=>{
 const r=createTipRotation({facts:[['Fact','text']],guides:[['Help','text']],phrases:['one','two','three'],random:()=>.2,storage:{getItem:()=>null,setItem(){}}});const a=r.next(2),b=r.next(5),c=r.next(8);assert.deepEqual([a.card[0],b.card[0],c.card[0]],['С улыбкой','Шутка ли…','Из юмора']);assert.ok(['one','two','three'].includes(a.card[1]));assert.equal(r.next(0).kind,'Факт');assert.equal(r.next(1).kind,'Из справки');
});
function song(){let s=addSetChord(newSet(),{root:'C',type:'major',beats:2});const part=addSection(s,'Припев');s=addSetChord(part.set,{root:'G',type:'major',beats:3,sectionId:part.id});return setPlayOrder(s,['main','main',part.id,'main',part.id]);}
test('Repeated parts expand on the beat timeline and transition automatically, including the last loop',()=>{
 const s=song(),p=makeRehearsalPlan(s);assert.deepEqual(p.chords.map(c=>c.root),['C','C','G','C','G']);assert.equal(p.total,12);assert.equal(p.chords[0].id,p.chords[1].id);
 assert.equal(rehearsalFrame(p,4).chord.root,'G');assert.equal(rehearsalFrame(p,11).next.root,'C');assert.equal(rehearsalFrame(p,12).cycle,2);
 assert.equal(rehearsalFrame({...p,settings:{...p.settings,loop:false}},12).ended,true);
});
test('Arrangement survives local storage, transposition and sharing without leaking local identities',()=>{
 const s=song(),data=new Map(),storage={getItem:k=>data.get(k),setItem:(k,v)=>data.set(k,v)},store=createCompositionStore({storage});assert.equal(store.save(s).ok,true);
 const restored=createCompositionStore({storage}).list()[0];assert.deepEqual(restored.playOrder,s.playOrder);assert.deepEqual(transposeSet(s,2).playOrder,s.playOrder);
 const url=new URL(createSetLink(s,'https://example.test/'));assert.ok(url.hash.startsWith('#set=v3.'));const copy=readSetLink(url.hash);assert.deepEqual(makeRehearsalPlan(copy).chords.map(c=>[c.root,c.beats]),makeRehearsalPlan(s).chords.map(c=>[c.root,c.beats]));
 assert.notEqual(draftSignature(s),draftSignature(setPlayOrder(s,[s.sections[1].id,'main'])));
});
test('Deleted parts drop all repeated references; corrupt and overlong orders are bounded',()=>{
 const s=song(),removed=changeSection(s,s.sections[1].id,{remove:true});assert.deepEqual(removed.playOrder,['main','main','main']);assert.equal(setPlayOrder(s,['missing']),null);
 assert.equal(normalizePlayOrder(Array(99).fill('main'),s.sections).length,64);assert.equal(normalizeDraft({...s,playOrder:['missing']}).playOrder,undefined);assert.deepEqual(sectionOrder(addSetChord(newSet(),{root:'A',type:'minor'})),['main']);
 const raw=[3,'Song',0,'major',[96,'4/4',true],[['C','major',null,4]],[['Verse'],[0]],[1]];assert.throws(()=>readSetLink('#set=v3.'+Buffer.from(JSON.stringify(raw)).toString('base64url')),/повреждена/);
});
test('Tip history revisits cards without consuming the seven-card allowance; swipes reject vertical drags',()=>{
 let draws=0;const s=createTipSession({next:()=>++draws});assert.equal(s.next(),1);assert.equal(s.next(),2);assert.equal(s.previous(),1);assert.equal(s.previous(),null);assert.equal(s.next(),2);assert.equal(draws,2);
 while(s.canNext)s.next();assert.equal(draws,7);assert.equal(s.next(),null);assert.equal(s.previous(),6);assert.equal(s.next(),7);assert.equal(draws,7);
 assert.equal(tipSwipeDirection(-80,10),'next');assert.equal(tipSwipeDirection(80,10),'previous');assert.equal(tipSwipeDirection(30,0),null);assert.equal(tipSwipeDirection(80,90),null);
});
test('Upside-down sensor tracking ignores sideways/flat motion and requires a stable reversal',()=>{
 const t=createUpsideTracker();assert.equal(t.update({x:0,y:9},0),false);assert.equal(t.update({x:0,y:-9},10),false);assert.equal(t.update({x:0,y:-9},700),true);assert.equal(t.update({x:9,y:0},800),true);assert.equal(t.update({x:0,y:9},900),true);assert.equal(t.update({x:0,y:9},1600),false);
 t.reset();assert.equal(t.update({x:0,y:-9},2000),false);assert.equal(t.update({x:0,y:9},2100),false);assert.equal(t.update({x:0,y:9},2800),true);
});
test('Motion access is requested only on explicit enable; denial leaves manual flipping available',async()=>{
 let requests=0;const root={dataset:{}},view={DeviceMotionEvent:{requestPermission:async()=>{requests++;return 'denied';}},addEventListener(){},removeEventListener(){}},c=createUpsideController({root,view,orientation:{type:'portrait-primary'}});assert.equal(requests,0);await assert.rejects(()=>c.enable(),/не разрешён/);assert.equal(c.enabled,false);c.flip();assert.equal(root.dataset.upsideDown,'true');c.flip();assert.equal(root.dataset.upsideDown,'false');
});
