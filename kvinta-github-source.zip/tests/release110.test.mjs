import test from 'node:test';
import assert from 'node:assert/strict';
import {newSet,addSetChord} from '../dist/modules/composition-model.js';
import {addSection} from '../dist/modules/composition-sections.js';
import {setPlayOrder} from '../dist/modules/arrangement.js';
import {makeRehearsalPlan} from '../dist/modules/rehearsal-model.js';
import {createRehearsalTransport} from '../dist/modules/rehearsal-transport.js';
import {loadPresentation,savePresentation,focusGroups,createTapAction} from '../dist/modules/rehearsal-presentation.js';
import {createRehearsalChords} from '../dist/modules/rehearsal-chords.js';
import {rehearsalFrame} from '../dist/modules/rehearsal-model.js';
function song(meter='4/4'){let s=addSetChord(newSet(),{root:'A',type:'minor',beats:4});s=addSetChord(s,{root:'C',type:'major',beats:2});return {...s,rehearsal:{bpm:120,meter,loop:false}};}
function harness({countIn=true,set=song()}={}){
 let config,raf,time=0,queue=[],starts=0,stops=0;const frames=[],counts=[],states=[],strums=[],renderer={prepare(){},schedule(frame,event){strums.push([frame,event]);},stop(){}};
 const engine={async start(){starts++;return true;},stop(){stops++;queue=[];},drain(){const next=queue;queue=[];return next;}};
 const transport=createRehearsalTransport({getSet:()=>set,getPresentation:()=>({countIn}),getChordSound:()=>true,chordRenderer:renderer,onFrame:v=>frames.push(v),onCount:v=>counts.push(v),onState:s=>states.push(s),engineFactory:c=>{config=c;return engine;},requestFrame:f=>{raf=f;return 1;},cancelFrame(){raf=null;},now:()=>time});
 return {transport,engine,frames,counts,states,strums,get config(){return config;},get starts(){return starts;},get stops(){return stops;},beat(ordinal){const e={ordinal,part:0,duration:.5,time};if(config.shouldSound(e))config.onSchedule(e,{});queue=[e];time+=16;raf?.();}};
}
test('Count-in is one bar on the same timeline and never strums before the first song beat',async()=>{
 const h=harness();await h.transport.start();for(let i=0;i<4;i++){assert.deepEqual(h.config.beatSound({ordinal:i},{sound:'bell'}),{sound:'wood',kind:'beat'});h.beat(i);assert.equal(h.strums.length,0);assert.equal(h.counts.at(-1).beat,i+1);}
 h.beat(4);assert.equal(h.frames.at(-1).ordinal,0);assert.equal(h.strums[0][0].beatInChord,0);assert.deepEqual(h.config.beatSound({ordinal:4},{sound:'bell'}),{sound:'bell',kind:'accent'});h.beat(9);assert.equal(h.transport.active,true);assert.equal(h.config.shouldSound({ordinal:10}),false);h.beat(10);assert.equal(h.transport.active,false);
});
test('Count-in can be disabled and follows compound and odd meter pulses',async()=>{
 for(const [meter,beats] of [['3/4',3],['6/8',2],['7/8',7]]){const h=harness({set:song(meter)});await h.transport.start();for(let i=0;i<beats;i++)h.beat(i);assert.equal(h.counts.at(-1).total,beats);h.beat(beats);assert.equal(h.frames.at(-1).ordinal,0);h.transport.stop();}
 const h=harness({countIn:false});await h.transport.start();h.beat(0);assert.equal(h.frames.at(-1).ordinal,0);assert.equal(h.counts.filter(Boolean).length,0);
});
test('Pause silences playback, keeps the current pulse and resumes without repeating the count-in',async()=>{
 const h=harness();await h.transport.start();h.beat(4);h.beat(5);assert.equal(h.frames.at(-1).beatInChord,1);assert.equal(h.transport.pause(),true);assert.equal(h.transport.paused,true);assert.equal(h.frames.at(-1).beatInChord,1);assert.equal(h.transport.active,true);assert.equal(h.transport.pause(),false);
 await h.transport.resume();h.beat(0);assert.equal(h.frames.at(-1).ordinal,1);assert.equal(h.frames.at(-1).beatInChord,1);assert.equal(h.strums.at(-1)[1].resume,true);assert.deepEqual(h.config.beatSound({ordinal:0},{sound:'click'}),{sound:'click',kind:'beat'});h.beat(1);assert.equal(h.frames.at(-1).ordinal,2);h.transport.stop();assert.equal(h.transport.paused,false);
});
test('Stopping during a delayed resume prevents a late restart and clears the full-screen frame',async()=>{
 const h=harness({countIn:false});await h.transport.start();h.beat(2);h.transport.pause();let done;h.engine.start=()=>new Promise(r=>done=r);const resumed=h.transport.resume();h.transport.stop();done(true);assert.equal(await resumed,false);assert.equal(h.transport.active,false);assert.equal(h.frames.at(-1),null);
});
test('Full score headings follow repeated arrangement occurrences, including an interlude, without changing chords',()=>{
 let s=song(),p=addSection(s,'Проигрыш');s=addSetChord(p.set,{root:'D',type:'minor',beats:8,sectionId:p.id});const chorus=addSection(s,'Припев');s=addSetChord(chorus.set,{root:'F',type:'major',beats:4,sectionId:chorus.id});s=setPlayOrder(s,['main',p.id,chorus.id,'main']);const plan=makeRehearsalPlan(s),groups=focusGroups(plan);assert.deepEqual(groups.map(g=>g.title),['Куплет 1','Проигрыш 1','Припев 1','Куплет 1']);assert.deepEqual(groups.flatMap(g=>g.chords.map(c=>c.index)),[0,1,2,3,4,5]);assert.equal(groups[0].chords[0].id,groups[3].chords[0].id);
});
test('Double tap exits without executing a pause; single tap toggles once and cancellation stays quiet',()=>{
 let now=0,timer,action,paused=0,exited=0;const taps=createTapAction({single:()=>paused++,double:()=>exited++,clock:()=>now,setTimer:f=>{timer=f;return 1;},clearTimer(){timer=null;}});
 taps.tap();now=150;taps.tap();assert.equal(paused,0);assert.equal(exited,1);assert.equal(timer,null);now=500;taps.tap();action=timer;action();assert.equal(paused,1);now=1000;taps.tap();taps.cancel();assert.equal(timer,null);
});
test('Presentation choices persist separately from musical set data and handle blocked storage',()=>{
 const data=new Map(),storage={getItem:k=>data.get(k),setItem:(k,v)=>data.set(k,v)};assert.deepEqual(loadPresentation(storage),{countIn:true,fullscreen:false});assert.equal(savePresentation({countIn:false,fullscreen:true},storage),true);assert.deepEqual(loadPresentation(storage),{countIn:false,fullscreen:true});assert.equal(savePresentation({}, {setItem(){throw Error();}}),false);assert.deepEqual(loadPresentation({getItem(){throw Error();}}),{countIn:true,fullscreen:false});
});
test('A chord resumed in its middle is audible but stops at its remaining duration',async()=>{
 const sources=[],ctx={sampleRate:8000,createBuffer:(c,n)=>({getChannelData:()=>new Float32Array(n)}),createGain:()=>({gain:{setValueAtTime(){},setTargetAtTime(){}},connect(){},disconnect(){}}),createBufferSource(){const s={connect(){},disconnect(){},start(t){this.at=t;},stop(t){this.end=t;}};sources.push(s);return s;}};
 const plan=makeRehearsalPlan(song()),renderer=createRehearsalChords();await renderer.prepare(plan,ctx);renderer.schedule(rehearsalFrame(plan,2),{ordinal:2,time:10,duration:.5,resume:true},{context:ctx,output:{},track(){}});assert.ok(sources.length>=3);assert.equal(sources[0].at,10);assert.ok(sources.every(s=>s.end===11));renderer.stop();
});
