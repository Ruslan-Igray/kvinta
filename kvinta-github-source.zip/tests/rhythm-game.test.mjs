import test from 'node:test';import assert from 'node:assert/strict';
import {gamePlan,gamePhase,normalizeGame,randomGame,scoreGame} from '../dist/modules/rhythm-game-model.js';
import {createRhythmGameSession} from '../dist/modules/rhythm-game-session.js';
import {appHeaderMarkup} from '../dist/modules/app-chrome.js';
const settings={bpm:120,meter:'4/4',duration:30},taps=(s=settings,offset=0)=>Array.from({length:gamePlan(s).total},(_,n)=>n*60/s.bpm+offset);
test('Random tests have feasible settings and custom values retain supported meters and lengths',()=>{const r=randomGame({},()=>0);assert.equal(r.bpm,60);assert.equal(r.meter,'2/4');assert.ok(r.pauses>=1);assert.equal(randomGame({},()=>1).bpm,160);assert.equal(normalizeGame({bpm:900,meter:'7/8',duration:90}).bpm,240);assert.equal(gamePlan({meter:'6/8'}).beats,2);assert.equal(gamePlan({meter:'12/8'}).beats,4);});
test('Count-in always has four beats, followed by complete silent bars and an exact finish',()=>{const p=gamePlan(settings);assert.equal(gamePhase(p,.1).kind,'count-in');assert.equal(gamePhase(p,1.9).count,4);assert.equal(gamePhase(p,2).kind,'guided');assert.equal(gamePhase(p,p.countIn+p.silences[0].from+.01).kind,'silent');assert.equal(gamePhase(p,p.countIn+p.silences[0].to).kind,'guided');assert.equal(gamePhase(p,p.countIn+p.duration).kind,'finished');});
test('Even the slowest 30-second exercise includes a blind segment',()=>{const s={bpm:20,meter:'7/4',duration:30},p=gamePlan(s);assert.ok(p.guideBeats<p.total);assert.ok(Array.from({length:p.total},(_,i)=>gamePhase(s,p.countIn+i*p.period+.01).kind).includes('silent'));});
test('Exact taps score 100 and report the intended tempo',()=>{const r=scoreGame(settings,taps());assert.equal(r.score,100);assert.equal(r.actualBpm,120);assert.equal(r.missed,0);assert.equal(r.extra,0);assert.ok(r.expected>10);});
test('Consistent device/input offset is estimated from guided taps and does not punish a steady player',()=>{for(const offset of [-.08,.08]){const r=scoreGame(settings,taps(settings,offset));assert.equal(r.score,100);assert.equal(r.calibrationMs,offset*1000);}});
test('No input or only guided input cannot set a perfect record',()=>{assert.equal(scoreGame(settings,[]).score,0);assert.equal(scoreGame(settings,taps().filter(t=>gamePhase(settings,t+2).kind!=='silent')).score,0);});
test('Missing, extra and accelerating taps reduce the score',()=>{assert.ok(scoreGame(settings,taps().filter((_,i)=>i%3)).score<80);const doubled=taps().flatMap(t=>[t,t+.12]);assert.ok(scoreGame(settings,doubled).score<=60);const faster=Array.from({length:65},(_,i)=>i*60/130);assert.ok(scoreGame(settings,faster).score<85);assert.ok(scoreGame(settings,faster).tempoDifference>9);});
function fixture({defer=false,sessionOptions={}}={}){let options,finish;const ctx={time:.04},frames=[],results=[],errors=[];const engine={async start(){options.onPrepare(ctx);options.shouldSound({time:.04,ordinal:0});if(defer)await new Promise(r=>finish=r);return true;},stop(){},drain(){return [];}};const session=createRhythmGameSession({engineFactory:o=>(options=o,engine),clock:c=>c.time,now:()=>1000,request:fn=>(frames.push(fn),frames.length),cancel(){},onResult:r=>results.push(r),onError:e=>errors.push(e),...sessionOptions});return {session,ctx,frames,results,errors,get options(){return options;},finish:()=>finish()};}
test('The audio scheduler suppresses silent measures and accents the first musical beat after count-in',async()=>{const f=fixture();await f.session.start({...settings,meter:'3/4'});const p=gamePlan({...settings,meter:'3/4'}),ordinal=4+Math.round(p.silences[0].from/p.period);assert.equal(f.options.shouldSound({time:.04+ordinal*p.period,ordinal}),false);assert.equal(f.options.beatSound({ordinal:4}).kind,'accent');assert.equal(f.options.beatSound({ordinal:7}).kind,'accent');f.session.stop();});
test('A stopped asynchronous start cannot resume the exercise later',async()=>{const f=fixture({defer:true}),pending=f.session.start(settings);f.session.stop();f.finish();assert.equal(await pending,false);assert.equal(f.session.active,false);assert.equal(f.frames.length,0);assert.equal(f.results.length,0);});
test('Only completion records a result, and all timing follows the audible output clock',async()=>{const f=fixture();await f.session.start(settings);assert.equal(f.session.tap(),false);for(const t of taps()){f.ctx.time=.04+2+t;assert.equal(f.session.tap(),true);}f.ctx.time=.04+32;f.frames.at(-1)();assert.equal(f.results.length,1);assert.equal(f.results[0].score,100);assert.equal(f.session.active,false);});
test('Both loading and ready headers omit the obsolete context icon',()=>{for(const mode of ['tools','song']){const header=appHeaderMarkup(mode);assert.ok(!header.includes('qs-help'));assert.ok(!header.includes('id="help"'));}});
test('A stalled scheduler cannot publish a misleading game result',async()=>{const f=fixture();await f.session.start(settings);assert.equal(f.options.shouldSound({time:2.3,ordinal:4}),false);f.frames.at(-1)();assert.equal(f.session.active,false);assert.equal(f.results.length,0);assert.match(f.errors[0],/Ритм прервался/);});

test('A hanging audio activation times out and cannot start a late game',async()=>{let timer;const f=fixture({defer:true,sessionOptions:{later:fn=>(timer=fn,1),clearLater(){}}}),pending=f.session.start(settings);timer();assert.equal(await pending,false);assert.equal(f.session.active,false);assert.match(f.errors[0],/Не удалось включить звук/);f.finish();await Promise.resolve();assert.equal(f.frames.length,0);});
test('A natural finish sounds once when enabled and a stopped or muted test stays quiet',async()=>{
 for(const {tempoSound,stopped,volume,expected} of [
  {tempoSound:true,volume:65,expected:1},
  {tempoSound:false,volume:65,expected:0},
  {tempoSound:true,volume:0,expected:0},
  {tempoSound:true,stopped:true,volume:65,expected:0}
 ]){
  const f=fixture({sessionOptions:{getSound:()=>({sound:'wood',volume})}});
  let sounds=0;
  Object.assign(f.ctx,{state:'running',sampleRate:8000,destination:{},
   createBuffer:(_,length)=>({getChannelData:()=>new Float32Array(length)}),
   createBufferSource:()=>({connect(){},disconnect(){},stop(){},start(){sounds++;}})
  });
  await f.session.start({...settings,tempoSound});
  if(stopped)f.session.stop();
  f.ctx.time=.04+32;
  f.frames.at(-1)();
  f.frames.at(-1)();
  assert.equal(sounds,expected);
  assert.equal(f.results.length,stopped?0:1);
 }
});
