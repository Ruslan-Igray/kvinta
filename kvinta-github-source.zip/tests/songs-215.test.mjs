import test from 'node:test';
import assert from 'node:assert/strict';
import {chordWordPositions} from '../features/songs/src/editor-controls.js';
import {normalizeRehearsal,CUE_PRESETS,cueLabel,normalizeSong} from '../features/songs/src/score-model.js';
import {sharedSongSettings,quickActions} from '../features/songs/src/song-settings.js';
import {songChordNotes} from '../dist/songs/chord-audition.js';
import {voicingsFor,soundingNotes} from '../dist/modules/guitar.js';

test('Word picker marks occupied and overlapping positions while keeping the edited chord available',()=>{
 const line={text:'Раз два три четыре',chords:[{id:'a',column:0,symbol:'C'},{id:'b',column:8,symbol:'G'}]};
 const positions=chordWordPositions(line,0,'C','a');
 assert.deepEqual(positions.map(w=>[w.column,w.occupied]),[[0,false],[4,false],[8,true],[12,false]]);
 assert.equal(chordWordPositions(line,0,'C#sus4','a').find(w=>w.column===4).occupied,true);
 assert.equal(chordWordPositions(line,0,'Am').find(w=>w.column===0).occupied,true);
});
test('Audition uses the actual Instruments voicing and all editor qualities retain the right intervals',()=>{
 assert.deepEqual(songChordNotes('Am'),soundingNotes(voicingsFor('A','minor')[0]));
 const expected={'C5':[0,7],Caug:[0,4,8],Cadd9:[0,2,4,7],C9:[0,2,4,7,10],Cm7b5:[0,3,6,10]};
 for(const [symbol,pcs] of Object.entries(expected)){const notes=songChordNotes(symbol);assert.equal(notes.length,6);assert.deepEqual([...new Set(notes.filter(n=>n!==null).map(n=>n%12))].sort((a,b)=>a-b),pcs);}
 const slash=songChordNotes('Am/G').filter(n=>n!==null);assert.equal(Math.min(...slash)%12,7);
 assert.deepEqual(songChordNotes('B♭m'),songChordNotes('Bbm'));assert.deepEqual(songChordNotes('Cunrecognized'),[]);assert.deepEqual(songChordNotes('Cconstructor'),[]);
});
test('Font size 10 survives both document validation and shared settings',()=>{
 for(const fontSize of [10,17,18,28]){assert.equal(normalizeRehearsal({fontSize}).fontSize,fontSize);assert.equal(sharedSongSettings({fontSize}).fontSize,fontSize);}
 assert.equal(normalizeRehearsal({fontSize:9}).fontSize,22);assert.equal(sharedSongSettings({fontSize:9}).fontSize,undefined);
});
test('Fullscreen beat dots are off by default, persist and can be put on the five-button panel',()=>{
 assert.equal(normalizeRehearsal({}).fullBeatDots,false);
 assert.equal(normalizeRehearsal({fullBeatDots:true}).fullBeatDots,true);
 assert.deepEqual(sharedSongSettings({fullBeatDots:true}),{fullBeatDots:true});
 assert.deepEqual(quickActions(['fullBeatDots','clicks']),['fullBeatDots','clicks']);
});
test('Preset labels use one word and old standard labels migrate without replacing custom notes',()=>{
 assert.ok(CUE_PRESETS.every(p=>!p.label.includes(' ')));assert.equal(cueLabel('Пауза всем'),'Пауза');assert.equal(cueLabel('Соло после баса'),'Соло после баса');assert.equal(cueLabel('toString'),'toString');
 const song=normalizeSong({schema:2,id:'sample',title:'Пример',parts:[{name:'Куплет',lines:[{text:'Слова',chords:[],cues:[{preset:'pause',label:'Пауза всем'},{preset:'custom',label:'Моя метка'}]}]}]});
 assert.deepEqual(song.parts[0].lines[0].cues.map(c=>c.label),['Пауза','Моя метка']);
});
