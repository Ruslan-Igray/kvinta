import test from 'node:test';
import assert from 'node:assert/strict';
import {estimateTempo,createOnsetEnvelope} from '../dist/modules/tempo-detection.js';
import {createTempoCapture} from '../dist/modules/tempo-capture.js';
import {createTuningConfirmation} from '../dist/modules/tuner-confirmation.js';
import {createTunerAudio} from '../dist/modules/tuner-audio.js';
import {TUNINGS,normalizeTuningSettings,stringsFor} from '../dist/modules/tuner-tunings.js';
import {createTipSession} from '../dist/modules/tip-session.js';

test('Tempo estimation measures regular and accented rhythms, with small timing and level changes',()=>{
 for(const bpm of [60,72,80,96,100,110,120,128,144,160,180]){
  const frames=Array(601).fill(.001);let beat=0;
  for(let t=0;t<12000;t+=60000/bpm){const index=Math.round((t+Math.sin(beat)*5)/20),level=beat++%4===0?1:.7;frames[index]=level;if(index+1<frames.length)frames[index+1]=level*.5;}
  const result=estimateTempo(frames);assert.ok(result,bpm);assert.ok(Math.abs(result.bpm-bpm)<=2,`${bpm}: ${result.bpm}`);
 }
});
test('Silence, sustained sound, short captures and nonperiodic noise do not invent a tempo',()=>{
 assert.equal(estimateTempo(Array(600).fill(0)),null);assert.equal(estimateTempo(Array(600).fill(.2)),null);assert.equal(estimateTempo([0,1,0]),null);
 let seed=17;const noise=Array.from({length:600},()=>{seed=(1664525*seed+1013904223)>>>0;return seed/2**32;});assert.equal(estimateTempo(noise),null);
 const envelope=createOnsetEnvelope(),spectrum=Float32Array.from({length:64},()=>-25);assert.equal(envelope(spectrum),0);assert.equal(envelope(spectrum),0);assert.equal(envelope(new Float32Array(64).fill(-70)),0);assert.ok(envelope(spectrum)>0);
});
test('Tuner confirms sustained tuning once, rearms after a departure, and rejects brief or stalled matches',()=>{
 const confirm=createTuningConfirmation(),model={stable:true,target:{id:6}};let hits=0;
 for(let t=0;t<4000;t+=40)hits+=confirm.update(model,t);assert.equal(hits,1);
 for(let t=4000;t<6000;t+=40)assert.equal(confirm.update(null,t),false);
 for(let t=6000;t<7000;t+=40)hits+=confirm.update(model,t);assert.equal(hits,2);
 confirm.reset();assert.equal(confirm.update(model,0),false);assert.equal(confirm.update(model,2000),false);
 for(let t=2040;t<2500;t+=40)assert.equal(confirm.update(model,t),false);
 assert.equal(confirm.update({...model,stable:false},2540),false);
});
test('Instrument presets retain guitar drop tunings, bass and ukulele, and all twelve individual string octaves',()=>{
 for(const group of ['Гитара · 6 струн','Бас · 4 струны','Укулеле · 4 струны','Гитара · 12 струн'])assert.ok(TUNINGS.filter(t=>t.group===group).length>=3);
 const state=normalizeTuningSettings({tuning:'guitar12-standard',string:'auto'}),strings=stringsFor(state);
 assert.equal(state.string,12);assert.deepEqual(strings.map(s=>s.midi),[40,52,45,57,50,62,55,67,59,59,64,64]);assert.deepEqual(strings.map(s=>s.id),[12,11,10,9,8,7,6,5,4,3,2,1]);
 const custom=normalizeTuningSettings({tuning:'custom',custom:strings.map(s=>s.midi)});assert.equal(custom.custom.length,12);assert.equal(stringsFor(custom).length,12);
 assert.equal(stringsFor(normalizeTuningSettings({tuning:'bass-standard',string:12})).length,4);
});
test('A tip session stops at five cards without consuming more from the persistent deck',()=>{
 let consumed=0;const session=createTipSession({next:()=>[++consumed,'body'],limit:5});for(let i=1;i<=5;i++)assert.equal(session.next()[0],i);
 assert.equal(session.done,true);assert.equal(session.count,5);for(let i=0;i<10;i++)assert.equal(session.next(),null);assert.equal(consumed,5);
});

function fixture(){
 let tick,now=0,stopped=0,closed=0,cleared=0;const listeners=new Map(),sources=[];
 const track={stop(){stopped++;},addEventListener(n,f){listeners.set(n,f);},removeEventListener(n){listeners.delete(n);}};
 const stream={getTracks:()=>[track],getAudioTracks:()=>[track]};
 const node=()=>({connect(){},disconnect(){}});
 const ctx={state:'running',currentTime:0,sampleRate:8000,destination:{},resume:async()=>{},close(){closed++;this.state='closed';return Promise.resolve();},addEventListener(){},removeEventListener(){},createMediaStreamSource:node,createGain(){return {...node(),gain:{value:1,setValueAtTime(){},linearRampToValueAtTime(){}}};},createAnalyser(){return {...node(),frequencyBinCount:128,getFloatFrequencyData(a){a.fill(now%500<40?-20:-85);},getFloatTimeDomainData(a){a.fill(0);}};},createBuffer(c,n,rate){const data=new Float32Array(n);return {duration:n/rate,getChannelData:()=>data};},createBufferSource(){const source={...node(),start(){this.started=true;},stop(){this.stopped=true;}};sources.push(source);return source;}};
 return {ctx,stream,sources,track,options:{contextFactory:()=>ctx,mediaDevices:{getUserMedia:async()=>stream},clock:()=>now,setTimer:f=>{tick=f;return 1;},clearTimer:()=>cleared++},step(t){now=t;tick?.();},get stopped(){return stopped;},get closed(){return closed;},get cleared(){return cleared;}};
}
test('Tempo capture is explicit, releases microphone after twelve seconds and returns an estimated result',async()=>{
 const f=fixture();let result;const capture=createTempoCapture({...f.options,onResult:r=>result=r});assert.equal(capture.active,false);assert.equal(f.closed,0);
 await capture.start();for(let t=20;t<=12000;t+=20)f.step(t);assert.equal(capture.active,false);assert.equal(f.stopped,1);assert.equal(f.closed,1);assert.ok(f.cleared>0);assert.ok(Math.abs(result.bpm-120)<=1);
});
test('Cancelled microphone prompts dispose late streams, while permission failures reset listening state',async()=>{
 const f=fixture();let resolve;const acquired=new Promise(r=>resolve=r);const capture=createTempoCapture({...f.options,mediaDevices:{getUserMedia:()=>acquired}});const started=capture.start();capture.stop();resolve(f.stream);assert.equal(await started,false);assert.equal(f.stopped,1);assert.equal(capture.active,false);
 let error;const failed=createTempoCapture({...fixture().options,mediaDevices:{getUserMedia:async()=>{throw {name:'NotAllowedError'};}},onError:text=>error=text});assert.equal(await failed.start(),false);assert.equal(failed.active,false);assert.match(error,/Разрешите/);
});
test('Tuning confirmation uses the live capture context and the selected family without ending microphone capture',async()=>{
 const f=fixture(),audio=createTunerAudio({audioContextFactory:()=>f.ctx,mediaDevices:f.options.mediaDevices,getSound:()=>'shh'});assert.equal(audio.confirm(),false);await audio.start();assert.equal(audio.confirm(),true);assert.equal(audio.running,true);assert.ok(f.sources[0].started);assert.equal(f.sources[0].buffer.getChannelData(0).length,600);audio.stop();assert.equal(f.sources[0].stopped,true);assert.equal(f.stopped,1);
});
