import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeMetro,meterFor,tapTempo,createBeatClock,planBeats,flashOnBeat,createMetronomeEngine } from '../dist/modules/metronome-engine.js';
import { createTorch } from '../dist/modules/metronome-torch.js';

test('Audio timeline stays evenly spaced over a minute; accent occurs only on the first main beat',()=>{
  const settings=normalizeMetro({bpm:137,meter:'4/4',subdivision:4}),clock=createBeatClock(.04),events=[];
  for(let now=0;now<60;now+=.025)events.push(...planBeats(clock,now,settings));
  assert.ok(events.length>540);
  events.forEach((e,i)=>{assert.ok(Math.abs(e.time-(.04+i*60/137/4))<1e-9);assert.equal(e.accent,i%16===0);});
  const silentAccent=planBeats(createBeatClock(0),0,normalizeMetro({accent:false}));assert.equal(silentAccent[0].accent,false);
});
test('6/8 counts two dotted-quarter beats and six eighth-note subdivisions per bar',()=>{
  const s=normalizeMetro({bpm:120,meter:'6/8',subdivision:3}),clock=createBeatClock(0),events=[];
  for(let now=0;now<1.05;now+=.025)events.push(...planBeats(clock,now,s));
  assert.equal(meterFor('6/8').beats,2);assert.deepEqual(events.slice(0,6).map(e=>[e.beat,e.part]),[[0,0],[0,1],[0,2],[1,0],[1,1],[1,2]]);
  assert.equal(events[6].bar,2);assert.equal(events[6].beat,0);assert.ok(Math.abs(events[6].time-1)<1e-10);
});
test('Late scheduler does not play an overdue burst; tempo input and tap tempo are bounded',()=>{
  const events=planBeats(createBeatClock(.01),10,normalizeMetro({bpm:240,subdivision:4}));
  assert.ok(events.length<=2);assert.ok(events.every(e=>e.time>=10));
  assert.equal(normalizeMetro({bpm:500}).bpm,240);assert.equal(normalizeMetro({bpm:0}).bpm,20);
  assert.equal(tapTempo([0,500,1000,1500]),120);assert.equal(tapTempo([0,500,1010,1510,2010]),120);assert.equal(tapTempo([0,500]),null);
});
test('Flash follows main beats only, never subdivisions, and skips alternate beats above 150 BPM',()=>{
  const events=[];const clock=createBeatClock(0),s=normalizeMetro({bpm:240,meter:'4/4',subdivision:4});
  for(let now=0;now<2;now+=.025)events.push(...planBeats(clock,now,s));
  const flashes=events.filter(e=>flashOnBeat(e));
  assert.ok(flashes.every(e=>e.part===0));
  flashes.slice(1).forEach((e,i)=>assert.ok(e.time-flashes[i].time>=.499));
  assert.ok(events.filter(e=>flashOnBeat(e,true)).every(e=>e.beat===0&&e.part===0));
});
function fakeAudio() {
  const sources=[],buffers=[];let callback=null,cleared=false;
  const ctx={currentTime:0,state:'running',sampleRate:8000,destination:{},resume:async()=>{ctx.state='running';},createGain:()=>({connect(){},gain:{setValueAtTime(){},setTargetAtTime(){}}}),createBuffer:(channels,length)=>{const data=new Float32Array(length);const buffer={getChannelData:()=>data};buffers.push(buffer);return buffer;},createBufferSource:()=>{const source={connect(){},disconnect(){},start(time){source.startTime=time;},stop(){source.stopped=true;}};sources.push(source);return source;}};
  return {ctx,sources,buffers,setTimer(fn){callback=fn;return 1;},clearTimer(){cleared=true;},pump(){callback?.();},get cleared(){return cleared;}};
}
test('Engine schedules ahead on the audio clock, stop cancels queued sources, restart begins on beat one',async()=>{
  const fake=fakeAudio(),settings=normalizeMetro({bpm:120});
  const engine=createMetronomeEngine({getSettings:()=>settings,audioContextFactory:()=>fake.ctx,setTimer:fake.setTimer,clearTimer:fake.clearTimer});
  await engine.start();assert.equal(engine.running,true);assert.equal(fake.sources[0].startTime,.04);
  fake.ctx.currentTime=.45;fake.pump();assert.ok(Math.abs(fake.sources[1].startTime-.54)<1e-12);
  engine.stop();assert.ok(fake.sources.every(s=>s.stopped));assert.equal(engine.drain().length,0);assert.equal(fake.cleared,true);
  fake.ctx.currentTime=1;await engine.start();fake.ctx.currentTime=1.1;assert.equal(engine.drain()[0].beat,0);engine.stop();
  assert.ok(fake.buffers.every(b=>[...b.getChannelData(0)].every(sample=>Number.isFinite(sample)&&Math.abs(sample)<=1)));
});
test('A stopped pending audio start cannot restart itself after resume resolves',async()=>{
  const fake=fakeAudio();let resume;
  fake.ctx.state='suspended';fake.ctx.resume=()=>new Promise(resolve=>{resume=()=>{fake.ctx.state='running';resolve();};});
  const engine=createMetronomeEngine({getSettings:()=>normalizeMetro(),audioContextFactory:()=>fake.ctx,setTimer:fake.setTimer,clearTimer:fake.clearTimer});
  const pending=engine.start();engine.stop();resume();assert.equal(await pending,false);assert.equal(engine.running,false);assert.equal(fake.sources.length,0);
});
function fakeCamera(torchSupported=true) {
  const calls=[];const track={stopped:false,stop(){this.stopped=true;},getCapabilities:()=>({torch:torchSupported}),applyConstraints:async c=>{calls.push(c.advanced[0].torch);}};
  const stream={getTracks:()=>[track],getVideoTracks:()=>[track]};let requested=0,options;
  const mediaDevices={async getUserMedia(o){requested++;options=o;return stream;}};
  const video={setAttribute(){},play:async()=>{},pause(){},remove(){}};let off;
  const torch=createTorch({mediaDevices,makeVideo:()=>video,attachVideo(){},later(fn){off=fn;return 1;},cancelLater(){off=null;}});
  return {torch,track,calls,get requested(){return requested;},get options(){return options;},off(){off?.();}};
}
test('Torch requests camera only on connect, never microphone; stop releases tracks and late flash timers',async()=>{
  const fake=fakeCamera();assert.equal(fake.requested,0);await fake.torch.connect();assert.equal(fake.requested,1);assert.equal(fake.options.audio,false);
  fake.torch.pulse(1000);await Promise.resolve();assert.deepEqual(fake.calls,[false,true]);fake.off();await Promise.resolve();assert.deepEqual(fake.calls,[false,true,false]);
  fake.torch.release();assert.equal(fake.track.stopped,true);assert.equal(fake.torch.connected,false);fake.off();assert.deepEqual(fake.calls,[false,true,false]);
});
test('Unsupported torch and cancelled late camera connections leave no camera running',async()=>{
  const fake=fakeCamera(false);await assert.rejects(fake.torch.connect());assert.equal(fake.track.stopped,true);
  let deliver;const track={stopped:false,stop(){this.stopped=true;}};
  const torch=createTorch({mediaDevices:{getUserMedia:()=>new Promise(resolve=>{deliver=resolve;})}});
  const pending=torch.connect();torch.release();deliver({getTracks:()=>[track]});assert.equal(await pending,false);assert.equal(track.stopped,true);
});

test('Tap audition uses the selected timbre and volume without starting the scheduler',async()=>{
 const fake=fakeAudio(),settings=normalizeMetro({sound:'click',volume:75}),engine=createMetronomeEngine({getSettings:()=>settings,audioContextFactory:()=>fake.ctx,setTimer:fake.setTimer,clearTimer:fake.clearTimer});
 assert.equal(await engine.audition(),true);assert.equal(engine.running,false);assert.equal(fake.sources.length,1);assert.equal(fake.sources[0].buffer,fake.buffers[4]);
 settings.sound='wood';await engine.audition();assert.equal(fake.sources[1].buffer,fake.buffers[1]);engine.stop();assert.ok(fake.sources.every(s=>s.stopped));
});
