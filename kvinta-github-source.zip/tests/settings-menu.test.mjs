import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {SETTINGS_SECTIONS,mountSettingsMenu,readRehearsalPreferences,saveRehearsalPreferences} from '../dist/modules/settings-menu.js';
import {SETTINGS_KEY} from '../features/songs/src/song-settings.js';
function memory(initial={}){const map=new Map(Object.entries(initial));return {getItem:k=>map.get(k)??null,setItem:(k,v)=>map.set(k,v)};}
test('Settings changed from tools preserve saved song defaults, quick order and unknown future preferences',()=>{
 const storage=memory({[SETTINGS_KEY]:JSON.stringify({fontSize:20,quickActions:['torch','clicks'],future:{retained:true}}),'kvinta-song-current':JSON.stringify({rehearsal:{bpm:135,key:5,fontSize:16}})});
 assert.equal(readRehearsalPreferences(storage).fontSize,20);
 assert.equal(saveRehearsalPreferences({fontSize:24,clicks:true},storage),true);
 const saved=readRehearsalPreferences(storage);assert.equal(saved.bpm,135);assert.equal(saved.key,5);assert.equal(saved.fontSize,24);assert.deepEqual(saved.quickActions,['torch','clicks']);assert.deepEqual(saved.future,{retained:true});
 assert.equal(saveRehearsalPreferences({quickActions:['torch','clicks','countIn','screenBlink','highlightLines','highlightChords','fullStart','fullBeatDots']},storage),true);assert.equal(readRehearsalPreferences(storage).quickActions.length,7);
});
test('Unavailable settings storage fails safely without clearing existing data',()=>{const broken={getItem(){throw Error('blocked');},setItem(){throw Error('blocked');}};assert.deepEqual(readRehearsalPreferences(broken),{});assert.equal(saveRehearsalPreferences({fontSize:24},broken),false);});
function fixture(){
 const doc={activeElement:null};
 class Node{constructor(tag){this.tag=tag;this.ownerDocument=doc;this.children=[];this.dataset={};this.attrs={};this.className='';this.classList={add:c=>{this.className+=' '+c;}};this.hidden=false;}
 append(...nodes){for(const node of nodes){if(node.parent){node.parent.children=node.parent.children.filter(n=>n!==node);}this.children.push(node);node.parent=this;}}
 replaceChildren(...nodes){for(const node of this.children)node.parent=null;this.children=[];this.append(...nodes);}
 contains(node){return this===node||this.children.some(n=>n.contains(node));}
 setAttribute(k,v){this.attrs[k]=v;}focus(){doc.activeElement=this;}}
 doc.createElement=tag=>new Node(tag);doc.head=new Node('head');doc.querySelector=()=>doc.head.children.find(n=>n.tag==='link'&&n.dataset.kvSettings);return {doc,Node};
}
test('Common sections move original controls with their handlers intact and return keyboard focus to the chosen section',()=>{
 const {doc,Node}=fixture(),content=new Node('div'),heading=new Node('h2'),input=new Node('input'),footer=new Node('p');let changes=0;input.onchange=()=>changes++;content.append(heading,input,footer);
 const menu=mountSettingsMenu({content,heading,footer,groups:{sound:[input]}});
 assert.deepEqual(SETTINGS_SECTIONS.map(s=>s.label),['Звук и ритм','Экран и свет','Репетиция','Инструменты','Приложение']);assert.equal(content.children[0],heading);assert.equal(menu.sections.get('sound').children[0],input);
 const header=menu.shell.children[0],pages=menu.shell.children[1],home=pages.children[0],sound=home.children[0];sound.onclick();assert.equal(home.hidden,true);assert.equal(menu.sections.get('sound').hidden,false);assert.equal(menu.sections.get('tools').hidden,true);assert.equal(doc.activeElement,header.children[0]);input.onchange();assert.equal(changes,1);
 header.children[0].onclick();assert.equal(home.hidden,false);assert.equal(doc.activeElement,sound);assert.ok(menu.sections.get('sound').hidden);assert.equal(menu.shell.children.at(-1),footer);
});
test('Musical chord underline is hidden in uniform scroll and enabled for tempo or recording, including empty lyric lines',()=>{
 const source=fs.readFileSync(new URL('../dist/songs/song.js',import.meta.url),'utf8'),start=source.indexOf('  function paintChord(){'),end=source.indexOf('\n  function update()',start);assert.ok(start>=0&&end>start);
 for(const [mode,requested,expected]of [['uniform',false,'false'],['tempo',false,'true'],['uniform',true,'true']]){
  const phone={dataset:{}},sandbox={phone,state:{mode},window:{kvintaRecording:{requested}},lineNodes:[{querySelectorAll:()=>[]}],current:0,starts:()=>[0],lineBeats:()=>8,activeChordNode:null};
  vm.runInNewContext(source.slice(start,end)+'\npaintChord();',sandbox);assert.equal(phone.dataset.chordTiming,expected);
 }
 const css=fs.readFileSync(new URL('../dist/songs/library.css',import.meta.url),'utf8');assert.match(css,/data-chord-timing=false[^}]*opacity:0/);
});
