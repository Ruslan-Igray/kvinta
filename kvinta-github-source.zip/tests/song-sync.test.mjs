import test from 'node:test';
import assert from 'node:assert/strict';
import {createSongSync} from '../dist/songs/song-sync.js';
import {audibleAudioTime} from '../dist/modules/audio-clock.js';
import {flashOnBeat,createMetronomeEngine} from '../dist/modules/metronome-engine.js';
import {createCountIn} from '../features/songs/src/count-in.js';
import {createRecordingTransport} from '../features/songs/src/recording-transport.js';

function harness({bpm=120,meter='4/4',latency=.08,external}={}){
 const sources=[],settings={bpm,meter,clicks:true};let interval=null,interrupts=0;
 const context={currentTime:0,state:'running',baseLatency:.02,outputLatency:latency-.02,destination:{},createBufferSource(){const s={connect(){},disconnect(){},start(t){this.time=t;},stop(){this.stopped=true;}};sources.push(s);return s;}};
 const sync=createSongSync({getSettings:()=>settings,makeBuffer:()=>({}),now:()=>100000+context.currentTime*1000,setTimer:fn=>{interval=fn;return 1;},clearTimer:()=>{interval=null;},onInterrupted:()=>interrupts++});
 return {context,sources,settings,sync,start:position=>sync.start({context,position,external}),pump(t){context.currentTime=t;interval?.();},get interrupts(){return interrupts;}};
}

test('Output time uses a fresh device timestamp and falls back to declared processing/output latency',()=>{
 const ctx={currentTime:1,baseLatency:.02,outputLatency:.08};assert.ok(Math.abs(audibleAudioTime(ctx)-.9)<1e-10);
 ctx.getOutputTimestamp=()=>({contextTime:.8,performanceTime:900});assert.ok(Math.abs(audibleAudioTime(ctx,()=>950)-.85)<1e-10);
 ctx.getOutputTimestamp=()=>({contextTime:0,performanceTime:0});assert.ok(Math.abs(audibleAudioTime(ctx,()=>950)-.9)<1e-10);
 ctx.getOutputTimestamp=()=>({contextTime:.9,performanceTime:10});assert.ok(Math.abs(audibleAudioTime(ctx,()=>2000)-.9)<1e-10);
 assert.equal(audibleAudioTime({currentTime:.01,baseLatency:.1}),0);
});

test('Song clicks are queued before the frame and visuals wait for the same audible timestamp',()=>{
 const h=harness();h.start(0);assert.ok(Math.abs(h.sources[0].time-.06)<1e-10);
 h.pump(.07);assert.equal(h.sync.drain().length,0,'Render time is not audible time');
 h.pump(.141);const first=h.sync.drain();assert.equal(first.length,1);assert.equal(first[0].ordinal,0);assert.ok(Math.abs(first[0].performanceTime-100140)<.01);
 h.pump(.45);assert.ok(Math.abs(h.sources[1].time-.56)<1e-10);h.pump(.641);assert.equal(h.sync.drain()[0].ordinal,1);h.sync.stop();
});

test('Audio schedule and song clock stay on the same grid for ten minutes without animation frames',()=>{
 for(const bpm of [40,96,137,220]){
  const h=harness({bpm});h.start(0);for(let t=.025;t<600;t+=.025)h.pump(t);
  h.sources.forEach((s,i)=>assert.ok(Math.abs(s.time-(.06+i*60/bpm))<1e-7));
  assert.ok(Math.abs(h.sync.position()-(h.context.currentTime-.08-.06)*bpm/60)<1e-7);h.sync.stop();
 }
});

test('A late frame discards old flashes rather than replaying a backlog, while sound remains scheduled',()=>{
 const h=harness();h.start(0);for(let t=.025;t<=2.65;t+=.025)h.pump(t);
 const due=h.sync.drain();assert.equal(due.length,1);assert.equal(due[0].ordinal,5);
 assert.ok(h.sources.length>=6);h.sync.stop();assert.equal(h.sync.drain().length,0);assert.ok(h.sources.every(s=>s.stopped));
});

test('A delayed scheduler skips missed clicks instead of bursting, and stop removes every future source',()=>{
 const h=harness();h.start(0);h.pump(3);assert.ok(h.sources.slice(1).every(s=>s.time>=3));assert.ok(h.sources.length<=2);
 h.sync.stop();const count=h.sources.length;h.pump(5);assert.equal(h.sources.length,count);assert.equal(h.sync.running,false);
});

test('Pause and resume preserve a fractional beat, with no extra click at the resume point',()=>{
 const h=harness();h.start(0);h.pump(.8);const at=h.sync.position();assert.ok(Math.abs(at-1.32)<1e-10);h.sync.stop();
 h.context.currentTime=10;const before=h.sources.length;h.start(at);assert.equal(h.sources.length,before);h.pump(10.34);
 assert.ok(Math.abs(h.sources.at(-1).time-10.4)<1e-10);h.sync.stop();
});

test('Tempo and click changes cancel only future clicks and retain phase across output latency',()=>{
 const h=harness();h.start(0);h.pump(.45);const old=h.sources.at(-1),before=h.sync.position();
 h.settings.bpm=180;h.sync.refresh();assert.ok(old.stopped);assert.ok(Math.abs(h.sync.position()-before)<1e-10);
 h.pump(.7);assert.ok(Math.abs(h.sync.position()-1.29)<1e-9);
 h.settings.clicks=false;h.sync.refresh();const count=h.sources.length;h.pump(.9);h.pump(1.2);h.pump(1.31);assert.equal(h.sources.length,count);
 assert.ok(h.sync.drain().length);h.sync.stop();
});

test('Recording clock controls the rhythm independently of line entrance interpolation',()=>{
 let h;h=harness({external:()=>({beat:h.context.currentTime*2,rate:2})});h.start(0);
 for(let t=.025;t<=10;t+=.025)h.pump(t);
 for(const s of h.sources.slice(1))assert.ok(Math.abs((s.time+.08)*2-Math.round((s.time+.08)*2))<1e-7);
 assert.ok(Math.abs(h.sync.position()-h.context.currentTime*2)<1e-7);h.sync.stop();
});

test('Screen and torch choose the same main-beat ordinals for all supported tempos',()=>{
 for(const bpm of [40,96,120,137,150,151,180,220]){
  const beats=Array.from({length:32},(_,ordinal)=>({ordinal,part:0,beat:ordinal%4,bpm}));
  const selected=beats.filter(e=>flashOnBeat(e)).map(e=>e.ordinal);assert.deepEqual(selected,bpm<=150?beats.map(e=>e.ordinal):beats.filter(e=>e.ordinal%2===0).map(e=>e.ordinal));
 }
});

test('Interruption or an unavailable audio context never leaves a silent visual transport running',()=>{
 const h=harness();assert.equal(h.sync.start({context:null}),false);h.start(0);h.context.state='suspended';h.pump(.1);assert.equal(h.sync.running,false);assert.equal(h.interrupts,1);assert.ok(h.sources.every(s=>s.stopped));
});

test('Count-in audio is scheduled in advance; its downbeat shares the exact end timestamp and cancellation stops future sticks',()=>{
 let time=0,id=0;const jobs=new Map(),nodes=[],shown=[];let done=false,end=null;
 const setTimer=(fn,ms)=>{jobs.set(++id,{fn,at:time+ms});return id;},clearTimer=id=>jobs.delete(id);
 const advance=ms=>{const until=time+ms;for(;;){const job=[...jobs].filter(([,j])=>j.at<=until).sort((a,b)=>a[1].at-b[1].at)[0];if(!job)break;jobs.delete(job[0]);time=job[1].at;job[1].fn();}time=until;};
 const context={state:'running',get currentTime(){return time/1000;}};
 const count=createCountIn({setTimer,clearTimer});count.start({bpm:120,context,outputTime:()=>Math.max(0,context.currentTime-.08),onSchedule:at=>{const n={at,stop(){this.stopped=true;},disconnect(){}};nodes.push(n);return n;},onScheduleEnd:at=>end=at,onBeat:n=>shown.push([n,time]),onDone:()=>done=true});
 assert.deepEqual(nodes.map(n=>n.at),[.06,.56,1.06,1.56]);assert.equal(end,2.06);advance(130);assert.equal(shown.length,0);advance(1900);assert.equal(done,false);advance(130);assert.equal(done,true);assert.deepEqual(shown.map(n=>n[0]),[1,2,3,4]);
 count.start({bpm:120,context,onSchedule:at=>{const n={at,stop(){this.stopped=true;},disconnect(){}};nodes.push(n);return n;},onBeat(){},onDone(){throw Error('Cancelled');}});count.cancel();advance(5000);assert.ok(nodes.slice(-4).every(n=>n.stopped));
});

test('A planned count-in downbeat can start the song clock ahead of time without advancing the score early',()=>{
 const h=harness();assert.equal(h.sync.start({context:h.context,position:8,when:2.06}),true);
 h.pump(1);assert.equal(h.sources.length,0);assert.equal(h.sync.position(),8);h.pump(2);assert.equal(h.sources[0].time,2.06);h.pump(2.141);assert.equal(h.sync.drain()[0].ordinal,8);h.sync.stop();
});

test('Recording buffering cancels future ticks and resumes the next valid beat without a duplicate burst',()=>{
 let waiting=false,h;h=harness({external:()=>waiting?null:{beat:h.context.currentTime*2,rate:2}});h.start(0);h.pump(.35);h.pump(.4);const future=h.sources.at(-1);waiting=true;h.pump(.41);assert.ok(future.stopped);waiting=false;h.pump(.415);const rescheduled=h.sources.at(-1);assert.notEqual(rescheduled,future);assert.ok(Math.abs(rescheduled.time-.42)<1e-10);h.sync.stop();
});

test('Recording rhythm uses actual playback rate and pauses on waiting, seeking and stop; preview stays at 1x',async()=>{
 const handlers={},media={paused:true,currentTime:0,playbackRate:1,muted:false,load(){},pause(){this.paused=true;},async play(){this.paused=false;},addEventListener:(e,fn)=>handlers[e]=fn};
 let song={id:'record',rehearsal:{bpm:90},parts:[{lines:[{id:'l',text:'test',chords:[],beats:4}]}],recording:{localId:'file',duration:30,referenceBpm:120,enabled:true,times:[{lineId:'l',at:2}]}};
 const transport=createRecordingTransport({media,store:{put:async()=>{}},getSong:()=>song,onRecord:record=>song={...song,recording:record},makeUrl:()=>'',waitMetadata:async()=>30});await transport.attach({name:'test.wav',size:10});assert.equal(transport.rhythmClock(),null);await transport.play();media.currentTime=4;assert.deepEqual(transport.rhythmClock(),{beat:4,rate:1.5});handlers.waiting();assert.equal(transport.rhythmClock(),null);handlers.playing();media.seeking=true;assert.equal(transport.rhythmClock(),null);media.seeking=false;await transport.preview();assert.equal(transport.rhythmClock().rate,2);transport.pause();assert.equal(transport.rhythmClock(),null);transport.destroy();
});

test('The standalone metronome also drains only after device output, including browsers without output timestamps',async()=>{
 const h=harness();h.context.sampleRate=8000;h.context.createBuffer=(_,n)=>({getChannelData:()=>new Float32Array(n)});h.context.createGain=()=>({connect(){},gain:{setValueAtTime(){},setTargetAtTime(){}}});let pump;
 const engine=createMetronomeEngine({getSettings:()=>({bpm:120}),audioContextFactory:()=>h.context,setTimer:fn=>{pump=fn;return 1;},clearTimer(){}});await engine.start();assert.equal(h.sources[0].time,.04);h.context.currentTime=.05;assert.equal(engine.drain().length,0);h.context.currentTime=.121;const beat=engine.drain()[0];assert.equal(beat.ordinal,0);assert.ok(Number.isFinite(beat.performanceTime));engine.stop();
});
