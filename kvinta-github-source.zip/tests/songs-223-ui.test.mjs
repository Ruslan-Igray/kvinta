import test from 'node:test';
import assert from 'node:assert/strict';
import {readingInsets,lyricCursor,lyricPosition,readingScrollTarget,followReadingScroll} from '../features/songs/src/reading-geometry.js';
import {setupSwipeDelete,swipeIntent,swipeState,SONG_SWIPE_OPTIONS} from '../dist/modules/swipe-delete.js';

const score=heights=>{let top=40;return heights.map((height,i)=>{const line={top,height};top+=height+(i%3===2?48:0);return line;});};
test('The complete playing row remains below the header at every phase on compact and full screen readers',()=>{
 for(const viewportHeight of [140,230,420,650])for(const fontSize of [10,22,28]){
  const lines=score([42,70,120,200,55,350,80]),inset=readingInsets(viewportHeight,fontSize);
  for(let index=0;index<lines.length;index++)for(let phase=0;phase<=1;phase+=.05){
   const top=readingScrollTarget({lines,index,phase,viewportHeight,fontSize,maxScroll:5000}),line=lines[index];
   assert.ok(top>=0);
   if(line.height<=viewportHeight-inset.safety-inset.bottom){
    assert.ok(line.top-top>=inset.safety-.001);
    assert.ok(line.top+line.height-top<=viewportHeight-inset.bottom+.001);
   }else assert.ok(line.top+line.height>top&&line.top<top+viewportHeight,'A wrapped row must remain in the viewport while being read');
  }
 }
});
test('Part gaps and unequal wrapped rows never reverse the scroll target at a line boundary',()=>{
 for(const viewportHeight of [140,250,600]){
  const lines=score([44,180,55,420,70,120]);let previous=0;
  for(let index=0;index<lines.length;index++)for(let step=0;step<=100;step++){
   const target=readingScrollTarget({lines,index,phase:step/100,viewportHeight,maxScroll:5000});
   assert.ok(target>=previous-.001);previous=target;
  }
 }
});
test('Scroll follow damps line and fullscreen target changes without a one-frame jump or overshoot',()=>{
 const lines=score([65,220,55,75]),small={lines,index:1,phase:1,viewportHeight:170,maxScroll:5000};
 const before=readingScrollTarget(small),next=readingScrollTarget({...small,index:2,phase:0});
 let position=before;for(let frame=0;frame<60;frame++){const value=followReadingScroll(position,next,1/60);assert.ok(value>=position&&value<=next);if(frame===0)assert.ok(Math.abs(value-position)<Math.abs(next-before)*.2);position=value;}
 const expanded=readingScrollTarget({...small,index:2,phase:.2,viewportHeight:650,fontSize:28}),value=followReadingScroll(position,expanded,1/60);
 assert.ok(value>=Math.min(position,expanded)&&value<=Math.max(position,expanded));assert.notEqual(value,expanded);
 const once=followReadingScroll(0,100,.1);let six=0;for(let i=0;i<6;i++)six=followReadingScroll(six,100,1/60);assert.ok(Math.abs(once-six)<1e-10);
 assert.equal(followReadingScroll(10,100,0),10);
});
test('Logical lyric position survives wrapped geometry changes and advances independently of clamped visual scrolling',()=>{
 const a=score([60,80,60,90]),b=score([80,140,100,150]),read={index:1,phase:.7};
 assert.deepEqual(lyricCursor(lyricPosition(read,a),a),read);
 assert.deepEqual(lyricCursor(lyricPosition(read,b),b),read);
 const frozenVisual=readingScrollTarget({lines:a,index:1,phase:.95,viewportHeight:150,maxScroll:0});assert.equal(frozenVisual,0);
 assert.equal(lyricCursor(lyricPosition({index:2,phase:.1},a),a).index,2);
 assert.deepEqual(lyricCursor(1e6,a),{index:3,phase:1});
 assert.equal(readingScrollTarget({lines:a,index:3,phase:1,viewportHeight:150,maxScroll:200}),200);
});

function swipeHarness(){
 let deletes=0,shares=0;
 const element=()=>({style:{},children:[],events:{},append(...items){this.children.push(...items);},prepend(item){this.children.unshift(item);},setAttribute(){},addEventListener(type,fn){(this.events[type]??=[]).push(fn);},classList:{toggle(){}}});
 const row=element(),content=element();row.ownerDocument={createElement:element};row.getBoundingClientRect=()=>({width:328});row.setPointerCapture=()=>{};
 const controller=setupSwipeDelete({row,content,gestureOptions:SONG_SWIPE_OPTIONS,onDelete:()=>deletes++,onShare:()=>shares++});
 const fire=(type,x,y=0)=>{const event={button:0,pointerId:1,clientX:x,clientY:y,target:{closest:()=>null},preventDefault(){this.prevented=true;},stopImmediatePropagation(){this.suppressed=true;}};for(const fn of row.events[type]??[])fn(event);return event;};
 return {row,content,controller,fire,get deletes(){return deletes;},get shares(){return shares;}};
}
test('Song swipes require deliberate horizontal intent and preserve normal taps and vertical scrolling',()=>{
 assert.equal(swipeIntent(18,2,SONG_SWIPE_OPTIONS),'pending');assert.equal(swipeIntent(30,30,SONG_SWIPE_OPTIONS),'vertical');assert.equal(swipeIntent(40,10,SONG_SWIPE_OPTIONS),'horizontal');
 const h=swipeHarness();h.fire('pointerdown',300);assert.equal(h.fire('pointermove',283,2).prevented,undefined);h.fire('pointerup',283,2);assert.equal(h.content.style.transform,'translateX(0px)');assert.equal(h.fire('click',283).suppressed,undefined);
 h.fire('pointerdown',300);h.fire('pointermove',279,36);h.fire('pointermove',30,38);h.fire('pointerup',30,38);assert.equal(h.deletes,0);assert.equal(h.shares,0);
});
test('Song swipe has a soft dead zone, settles open, and only a long deliberate gesture deletes or shares',()=>{
 const h=swipeHarness();h.fire('pointerdown',300);h.fire('pointermove',275);assert.ok(parseFloat(h.content.style.transform.slice(11))>-25);h.fire('pointerup',275);assert.equal(h.content.style.transform,'translateX(0px)');
 h.fire('pointerdown',300);h.fire('pointermove',130);h.fire('pointerup',130);assert.equal(h.deletes,0);assert.equal(h.content.style.transform,'translateX(-92px)');assert.match(h.content.style.transition,/260ms/);
 h.controller.cancel();h.fire('pointerdown',310);h.fire('pointermove',30);h.fire('pointercancel',30);assert.equal(h.deletes,0);
 h.fire('pointerdown',310);h.fire('pointermove',30);h.fire('pointerup',30);assert.equal(h.deletes,1);
 h.fire('pointerdown',30);h.fire('pointermove',140);h.fire('pointerup',140);assert.equal(h.shares,0);
 h.fire('pointerdown',30);h.fire('pointermove',180);h.fire('pointerup',180);assert.equal(h.shares,1);
 assert.ok(swipeState(200,328).armed);assert.equal(swipeState(200,328,SONG_SWIPE_OPTIONS).armed,false,'Other screens retain their original thresholds');
});
