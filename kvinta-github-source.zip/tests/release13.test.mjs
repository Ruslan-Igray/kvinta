import { setAudioSession } from '../dist/modules/audio-session.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createPitchDetector,createPitchTracker,frequencyFor,centsBetween,normalizeTuner } from '../dist/modules/tuner-pitch.js';
import { tuningGuidance } from '../dist/modules/tuner-guidance.js';
import { referenceSamples } from '../dist/modules/reference-tone.js';
import { needsPortraitGuard } from '../dist/modules/portrait.js';
import { chordVisual } from '../dist/modules/rehearsal-visuals.js';

function wave(hz,rate,{amplitude=.0012,start=0,decay=0}={}){
  return Float32Array.from({length:8192},(_,i)=>{const t=start+i/rate;return amplitude*Math.exp(-t*decay)*(Math.sin(2*Math.PI*hz*t)+.55*Math.sin(4*Math.PI*hz*t)+.18*Math.sin(6*Math.PI*hz*t));});
}
test('Quiet guitar/bass/ukulele notes survive the lower gate in a low-latency input window',()=>{
  const detect=createPitchDetector();for(const rate of [44100,48000,96000])for(const midi of [21,26,28,40,45,50,55,59,64,69,83]){
    const wanted=frequencyFor(midi),found=detect(wave(wanted,rate),rate);assert.ok(found.frequency,`${midi}/${rate}: quiet note was rejected`);assert.ok(Math.abs(centsBetween(found.frequency,wanted))<3,`${midi}/${rate}: wrong pitch`);
  }
});
test('A decaying pluck stays measurable well after the initial attack',()=>{
  const detect=createPitchDetector(),hz=frequencyFor(40);let tail=0;
  for(let i=1;i<=15;i++){const time=i*.1,result=detect(wave(hz,48000,{amplitude:.04,start:time,decay:2.6}),48000);if(result.frequency&&time>=.5){tail++;assert.ok(Math.abs(centsBetween(result.frequency,hz))<3);}}
  assert.ok(tail>=9,'The sustained tail should remain measurable past one second');
  let seed=13;const noise=Float32Array.from({length:8192},()=>{seed=(1664525*seed+1013904223)>>>0;return (seed/2**32-.5)*.003;});assert.equal(detect(noise,48000).frequency,null);
});
test('Ambiguous automatic targets, wrong octaves and large errors never advise more tension',()=>{
  const tracker=createPitchTracker(),settings=normalizeTuner(),mid=Math.sqrt(frequencyFor(40)*frequencyFor(45));let model;
  for(let i=0;i<6;i++)model=tracker.update({frequency:mid,clarity:.99,rms:.01},i*40,settings);assert.equal(model.ambiguous,true);assert.equal(tuningGuidance(model).direction,'check');
  tracker.reset();for(let i=0;i<6;i++)model=tracker.update({frequency:frequencyFor(64),clarity:.99,rms:.01},i*40,normalizeTuner({string:6}));assert.equal(model.octave,true);assert.equal(tuningGuidance(model).direction,'check');
  for(const cents of [-600,-101,101,700])assert.equal(tuningGuidance({cents}).direction,'check');
  assert.equal(tuningGuidance({...model,stale:true}).direction,'waiting');
});
test('The richer reference keeps the exact requested pitch at the start and sustained tail',()=>{
  const detect=createPitchDetector();for(const rate of [44100,48000])for(const midi of [26,40,45,64,69]){
    const wanted=frequencyFor(midi,442),samples=referenceSamples(wanted,rate);assert.equal(samples[0],0);assert.equal(samples.at(-1),0);assert.ok(samples.every(n=>Number.isFinite(n)&&Math.abs(n)<.9));
    for(const time of [.2,2.2]){const offset=Math.floor(time*rate),result=detect(samples.slice(offset,offset+8192),rate);assert.ok(result.frequency);assert.ok(Math.abs(centsBetween(result.frequency,wanted))<3);}
  }
});
test('White pulses follow main beats and the fill climbs by complete beat portions',()=>{
  const f={chord:{beats:4},beatInChord:0,beatInBar:1,ordinal:1};assert.equal(chordVisual(f).fill,25);assert.equal(chordVisual({...f,beatInChord:3}).fill,100);assert.equal(chordVisual(f,'off').flash,false);assert.equal(chordVisual(f,'bar').flash,false);assert.equal(chordVisual({...f,beatInBar:0},'bar').flash,true);assert.equal(chordVisual(f,'beat',200).flash,false);assert.equal(chordVisual({...f,ordinal:2},'beat',200).flash,true);assert.deepEqual(chordVisual(null),{fill:0,flash:false});
});
test('Portrait guard blocks a rotated phone, but not a portrait keyboard or desktop',()=>{
  assert.equal(needsPortraitGuard(844,390,'landscape-primary'),true);assert.equal(needsPortraitGuard(390,844,'portrait-primary'),false);assert.equal(needsPortraitGuard(390,300,'portrait-primary'),false);assert.equal(needsPortraitGuard(1280,720,'landscape-primary'),false);
});


test('Audio routing declares capture/playback when supported and safely skips unsupported browsers',()=>{
  const nav={audioSession:{type:'auto'}};assert.equal(setAudioSession('play-and-record',nav),true);assert.equal(nav.audioSession.type,'play-and-record');assert.equal(setAudioSession('playback',nav),true);assert.equal(nav.audioSession.type,'playback');assert.equal(setAudioSession('playback',{}),false);assert.equal(setAudioSession('playback',{get audioSession(){throw new Error();}}),false);
});
