import test from 'node:test';
import assert from 'node:assert/strict';
import { GUITAR_STRINGS,frequencyFor,centsBetween,nearestNote,targetString,normalizeTuner,createPitchDetector,createPitchTracker } from '../dist/modules/tuner-pitch.js';
import { createTunerAudio } from '../dist/modules/tuner-audio.js';
import { TUNINGS,stringsFor } from '../dist/modules/tuner-tunings.js';
import { createTuningSequence } from '../dist/modules/tuner-sequence.js';

function signal(frequency,rate=48000,{harmonics=[.15],noise=0,dc=0,phase=.37}={}){
  let seed=7;
  return Float32Array.from({length:16384},(_,i)=>{
    seed=(seed*1664525+1013904223)>>>0;
    return dc+harmonics.reduce((v,a,h)=>v+a*Math.sin(2*Math.PI*frequency*(h+1)*i/rate+phase),0)+noise*(seed/2**32-.5);
  });
}
test('All six guitar strings and detuned variants are measured within 2 cents at 44.1/48/96 kHz',()=>{
  const detect=createPitchDetector();
  for(const rate of [44100,48000,96000])for(const string of GUITAR_STRINGS)for(const cents of [-45,-17,0,8,35]){
    const wanted=frequencyFor(string.midi)*2**(cents/1200),result=detect(signal(wanted,rate),rate);
    assert.ok(result.frequency,`${string.id} at ${rate}: no pitch`);
    assert.ok(Math.abs(centsBetween(result.frequency,wanted))<2,`${string.id} at ${rate}: ${result.frequency} vs ${wanted}`);
  }
});
test('Dominant second harmonic, decaying pluck, background noise and DC do not turn low E into an octave',()=>{
  const detect=createPitchDetector(),wanted=frequencyFor(40);
  for(const rate of [44100,48000]){
    const samples=signal(wanted,rate,{harmonics:[.04,.18,.08,.03],noise:.012,dc:.12});
    for(let i=0;i<samples.length;i++)samples[i]*=Math.exp(-i/rate*3);
    const found=detect(samples,rate);assert.ok(found.frequency);assert.ok(Math.abs(centsBetween(found.frequency,wanted))<3);
  }
});
test('Silence, constant offset and unpitched noise produce no valid pitch; clipping is flagged',()=>{
  const detect=createPitchDetector();
  for(const samples of [new Float32Array(4096),new Float32Array(4096).fill(.25),signal(0,48000,{harmonics:[],noise:.1})])assert.equal(detect(samples,48000).frequency,null);
  assert.equal(detect(signal(110,48000,{harmonics:[1.5]}),48000).clipped,true);
});
test('Targets, tuning reference and measured note respect octave; manual selection never folds an octave',()=>{
  assert.equal(targetString(110,normalizeTuner()).id,5);
  assert.equal(targetString(frequencyFor(64),normalizeTuner()).id,1);
  assert.equal(targetString(frequencyFor(64),normalizeTuner({string:6})).id,6);
  assert.equal(nearestNote(440).note,'A');assert.equal(nearestNote(440).octave,4);
  assert.ok(Math.abs(centsBetween(frequencyFor(40,432),frequencyFor(40,440))-1200*Math.log2(432/440))<1e-10);
  assert.equal(normalizeTuner({string:12,a4:999}).string,'auto');assert.equal(normalizeTuner({a4:999}).a4,450);
  assert.equal(normalizeTuner(null).a4,440);assert.equal(normalizeTuner(null).tuning,'guitar-standard');
});

test('Drop, bass and both ukulele tunings preserve physical order, pitches and octaves',()=>{
  const notes=id=>stringsFor(normalizeTuner({tuning:id})).map(s=>s.note+(Math.floor(s.midi/12)-1));
  assert.deepEqual(notes('guitar-drop-c'),['C2','G2','C3','F3','A3','D4']);
  assert.deepEqual(notes('guitar-drop-b'),['B1','F#2','B2','E3','G#3','C#4']);
  assert.deepEqual(notes('guitar-drop-a'),['A1','E2','A2','D3','F#3','B3']);
  assert.deepEqual(notes('bass-standard'),['E1','A1','D2','G2']);
  assert.deepEqual(notes('ukulele-high-g'),['G4','C4','E4','A4']);
  assert.deepEqual(notes('ukulele-low-g'),['G3','C4','E4','A4']);
  const uke=normalizeTuner({tuning:'ukulele-high-g'});assert.equal(targetString(frequencyFor(67),uke).id,4);assert.equal(targetString(frequencyFor(60),uke).id,3);
});
test('All preset pitches plus low custom bass notes and high custom notes are detected in the expanded range',()=>{
  const detect=createPitchDetector(),notes=[...new Set([...TUNINGS.flatMap(t=>t.midis),21,23,24,83])];
  for(const rate of [44100,48000,96000])for(const midi of notes){
    const expected=frequencyFor(midi),result=detect(signal(expected,rate),rate);
    assert.ok(result.frequency,`${midi} at ${rate}: no pitch`);
    assert.ok(Math.abs(centsBetween(result.frequency,expected))<3,`${midi} at ${rate}: ${centsBetween(result.frequency,expected)} cents`);
  }
});
test('Old preferences migrate; a 4-string tuning cannot retain a sixth string; custom order and repeated pitches survive',()=>{
  const old=normalizeTuner({string:6,a4:432});assert.equal(old.string,6);assert.equal(old.a4,432);assert.equal(old.autoAdvance,false);
  assert.equal(normalizeTuner({tuning:'bass-standard',string:6}).string,'auto');
  assert.equal(normalizeTuner({tuning:'bass-standard',string:'auto',autoAdvance:true}).string,4);
  const custom=normalizeTuner({tuning:'custom',custom:[67,60,64,64],string:1});
  assert.deepEqual(stringsFor(custom).map(s=>s.midi),[67,60,64,64]);assert.equal(custom.string,1);
  assert.deepEqual(normalizeTuner({tuning:'custom',custom:[0,90,35,40]}).custom,[21,83,35,40]);
});
function modelFor(string,{stable=true}={}){return {target:string,frequency:frequencyFor(string.midi),stable,tuned:true};}
function measureFor(midi){return {frequency:frequencyFor(midi),rms:.1,clarity:.99,clipped:false};}
test('Auto sequence waits for sustained tuning, then visits each of four strings once and completes',()=>{
  const strings=stringsFor({tuning:'bass-standard'}),flow=createTuningSequence();let now=0;
  for(let index=0;index<strings.length;index++){
    const s=strings[index];let event=null;
    for(let i=0;i<=22;i++){event=flow.update(modelFor(s),measureFor(s.midi),now,strings);now+=40;assert.equal(event,null);}
    event=flow.update(modelFor(s),measureFor(s.midi),now,strings);now+=40;
    assert.equal(event.completed,s.id);assert.equal(event.next,strings[index+1]?.id??null);
  }
  assert.equal(flow.completed.size,4);
  assert.equal(flow.update(modelFor(strings[3]),measureFor(strings[3].midi),now+1000,strings),null);
});
test('Auto sequence does not count jitter, a stalled UI or green hysteresis outside strict tolerance',()=>{
  const strings=stringsFor(),s=strings[0],flow=createTuningSequence();
  for(let now=0;now<=800;now+=40)assert.equal(flow.update(modelFor(s),measureFor(s.midi),now,strings),null);
  assert.equal(flow.update(modelFor(s,{stable:false}),measureFor(s.midi),840,strings),null);
  for(let now=880;now<=1600;now+=40)assert.equal(flow.update(modelFor(s),measureFor(s.midi),now,strings),null);
  assert.equal(flow.update(modelFor(s),measureFor(s.midi),3000,strings),null);
  assert.equal(flow.completed.size,0);
});
test('One held pitch cannot complete two equal custom strings; silence rearms the next pluck',()=>{
  const strings=stringsFor({tuning:'custom',custom:[60,60,64,69]}),flow=createTuningSequence({holdMs:200});let now=0,event;
  for(;now<=200;now+=40)event=flow.update(modelFor(strings[0]),measureFor(60),now,strings);
  assert.equal(event.next,3);assert.equal(flow.completed.size,1);
  for(;now<1600;now+=40)assert.equal(flow.update(modelFor(strings[1]),measureFor(60),now,strings),null);
  for(let i=0;i<6;i++,now+=40)flow.update(null,{frequency:null,rms:0},now,strings);
  for(let i=0;i<=5;i++,now+=40)event=flow.update(modelFor(strings[1]),measureFor(60),now,strings);
  assert.equal(event.next,2);assert.equal(flow.completed.size,2);
});
test('Tracker waits for stable frames, gives correct direction and removes tuned state on silence or a new note',()=>{
  const tracker=createPitchTracker(),settings=normalizeTuner({string:6});
  const input=cents=>({frequency:frequencyFor(40)*2**(cents/1200),clarity:.99,rms:.1,clipped:false});
  assert.equal(tracker.update(input(0),0,settings),null);assert.equal(tracker.update(input(0),40,settings),null);
  assert.equal(tracker.update(input(0),80,settings).tuned,true);
  assert.equal(tracker.update({frequency:null},120,settings),null);
  assert.equal(tracker.update(input(0),500,settings),null);
  tracker.reset();let result;for(let i=0;i<5;i++)result=tracker.update(input(-25),i*40,settings);assert.ok(result.cents<-24&&!result.tuned);
  tracker.reset();for(let i=0;i<5;i++)result=tracker.update(input(25),i*40,settings);assert.ok(result.cents>24&&!result.tuned);
  tracker.reset();for(let i=0;i<3;i++)result=tracker.update({frequency:frequencyFor(52),clarity:.99},i*40,settings);assert.ok(result.far&&result.cents>1199);
});

function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};}
test('A smoothing transition through the centre never reports a sharp or flat signal as tuned',()=>{
  const tracker=createPitchTracker(),settings=normalizeTuner({string:6});let now=0;
  const reading=cents=>({frequency:frequencyFor(40)*2**(cents/1200),clarity:.99});
  for(let i=0;i<5;i++)tracker.update(reading(-25),now+=40,settings);
  for(let i=0;i<8;i++)assert.equal(tracker.update(reading(25),now+=40,settings)?.tuned,false);
});
function fakeTrack(){const listeners=new Map();return {stopped:0,stop(){this.stopped++;},addEventListener(n,fn){listeners.set(n,fn);},removeEventListener(n){listeners.delete(n);},emit(n){listeners.get(n)?.();}};}
function fakeStream(){const track=fakeTrack();return {track,getTracks:()=>[track],getAudioTracks:()=>[track]};}
function fakeContext({resume}={}){
  const nodes=[],listeners=new Map();
  const node=()=>{const n={connections:[],disconnected:0,connect(to){this.connections.push(to);},disconnect(){this.disconnected++;}};nodes.push(n);return n;};
  const ctx={state:resume?'suspended':'running',sampleRate:48000,destination:{},nodes,closed:0,
    resume(){return resume.promise.then(()=>{this.state='running';});},
    close(){this.closed++;this.state='closed';return Promise.resolve();},
    createMediaStreamSource(){return node();},
    createAnalyser(){return Object.assign(node(),{getFloatTimeDomainData(samples){samples.set(signal(110).subarray(0,samples.length));}});},
    createGain(){return Object.assign(node(),{gain:{value:1}});},
    addEventListener(n,fn){listeners.set(n,fn);},removeEventListener(n){listeners.delete(n);},emit(n){listeners.get(n)?.();},
  };return ctx;
}
test('Microphone starts only on request, never requests video, is silent at output and releases all resources on Stop',async()=>{
  const ctx=fakeContext(),stream=fakeStream();let calls=0,constraints;
  const audio=createTunerAudio({audioContextFactory:()=>ctx,mediaDevices:{getUserMedia:async(c)=>{calls++;constraints=c;return stream;}}});
  assert.equal(calls,0);assert.equal(audio.running,false);await audio.start();
  assert.equal(calls,1);assert.equal(constraints.video,false);assert.equal(constraints.audio.echoCancellation,false);assert.equal(constraints.audio.autoGainControl,false);
  assert.equal(ctx.nodes[2].gain.value,0);assert.ok(Math.abs(audio.read().frequency-110)<.1);
  audio.stop();assert.equal(audio.running,false);assert.equal(audio.read(),null);assert.equal(stream.track.stopped,1);assert.equal(ctx.closed,1);assert.ok(ctx.nodes.every(n=>n.disconnected===1));
});
test('Cancelling a pending microphone prompt closes context and stops a stream arriving late',async()=>{
  const pending=deferred(),ctx=fakeContext(),stream=fakeStream();
  const audio=createTunerAudio({audioContextFactory:()=>ctx,mediaDevices:{getUserMedia:()=>pending.promise}});
  const started=audio.start();audio.stop();assert.equal(ctx.closed,1);pending.resolve(stream);
  assert.equal(await started,false);assert.equal(stream.track.stopped,1);assert.equal(audio.running,false);
});
test('Permission denial and interrupted microphone clean up; an older cancelled request cannot stop a newer one',async()=>{
  const old=deferred(),oldCtx=fakeContext(),newCtx=fakeContext(),newStream=fakeStream(),oldStream=fakeStream();let calls=0,interrupted=0;
  const audio=createTunerAudio({audioContextFactory:()=>calls===0?oldCtx:newCtx,mediaDevices:{getUserMedia:()=>++calls===1?old.promise:Promise.resolve(newStream)},onInterrupted:()=>interrupted++});
  const first=audio.start();audio.stop();assert.equal(await audio.start(),true);old.resolve(oldStream);assert.equal(await first,false);assert.equal(oldStream.track.stopped,1);assert.equal(audio.running,true);
  newStream.track.emit('ended');assert.equal(interrupted,1);assert.equal(audio.running,false);assert.equal(newCtx.closed,1);
  const deniedCtx=fakeContext();const denied=createTunerAudio({audioContextFactory:()=>deniedCtx,mediaDevices:{getUserMedia:async()=>{throw Object.assign(new Error('denied'),{name:'NotAllowedError'});}}});
  await assert.rejects(denied.start(),{name:'NotAllowedError'});assert.equal(deniedCtx.closed,1);assert.equal(denied.running,false);
});
test('Cancelled audio activation cannot resurrect capture; unsupported contexts never ask for microphone',async()=>{
  const resume=deferred(),ctx=fakeContext({resume}),stream=fakeStream();
  const audio=createTunerAudio({audioContextFactory:()=>ctx,mediaDevices:{getUserMedia:async()=>stream}});
  const started=audio.start();audio.stop();resume.resolve();assert.equal(await started,false);assert.equal(stream.track.stopped,1);assert.equal(audio.running,false);
  let calls=0;const unsupported=createTunerAudio({secure:false,audioContextFactory:()=>ctx,mediaDevices:{getUserMedia:()=>calls++}});
  assert.equal(unsupported.available,false);await assert.rejects(unsupported.start(),{name:'NotSupportedError'});assert.equal(calls,0);
});
