import test from 'node:test';
import assert from 'node:assert/strict';
import { KEYS,pitchClass,mod } from '../dist/modules/theory.js';
import { MAX_SET_CHORDS,SET_TYPES,newSet,defaultSetName,normalizeDraft,setChordName,transposeSet,shiftSet,changeSetMode,addSetChord,moveSetChord,replaceSetChord,removeSetChord,createCompositionStore } from '../dist/modules/composition-model.js';

const at=new Date(2026,10,1,9,7);
function progression(){let set=newSet({date:at});for(const [root,type,bass] of [['C','major'],['G','major'],['A','minor'],['F','major']])set=addSetChord(set,{root,type,bass});return set;}
function memory(){const data=new Map([['kvinta.preferences.v1','{"favorites":["major:0"]}']]);return {data,getItem:key=>data.get(key)??null,setItem:(key,value)=>data.set(key,value)};}
test('Default name contains only ten digits for local minutes, hours, day, month and year',()=>{
  assert.equal(defaultSetName(at),'0709011126');assert.equal(newSet({date:at}).name,'0709011126');assert.match(defaultSetName(at),/^\d{10}$/);
});
test('C G Am F transposes to D A Bm G and semitone buttons preserve each chord type',()=>{
  const original=progression(),moved=transposeSet(original,2);
  assert.deepEqual(moved.chords.map(c=>setChordName(c)),['D','A','Bm','G']);
  assert.deepEqual(original.chords.map(c=>setChordName(c)),['C','G','Am','F']);
  assert.deepEqual(shiftSet(original,1).chords.map(c=>setChordName(c)),['Db','Ab','Bbm','Gb']);
  assert.deepEqual(shiftSet(original,-1).chords.map(c=>setChordName(c)),['B','F#','G#m','E']);
  assert.deepEqual(transposeSet(moved,0).chords,original.chords);
});
test('Slash bass and altered chord qualities transpose with the same interval and diatonic spelling',()=>{
  let set=addSetChord(newSet({date:at}),{root:'C',type:'major',bass:'E'});
  set=addSetChord(set,{root:'G',type:'7',bass:'B'});set=addSetChord(set,{root:'F#',type:'5',bass:null});
  assert.deepEqual(transposeSet(set,2).chords.map(c=>setChordName(c)),['D/F#','A7/C#','G#5']);
  assert.deepEqual(transposeSet(set,7).chords.map(c=>setChordName(c)),['Db/F','Ab7/C','G5']);
});
test('All 24 source and target keys preserve root/bass intervals, occurrence identities and qualities',()=>{
  for(const mode of ['major','minor'])for(let from=0;from<12;from++){
    let set=newSet({keyIndex:from,mode,date:at});
    for(const type of SET_TYPES)set=addSetChord(set,{root:'C#',type:type.id,bass:'Bb'});
    for(const targetMode of ['major','minor'])for(let to=0;to<12;to++){
      const moved=transposeSet(set,to,targetMode),distance=mod(pitchClass(KEYS[to][targetMode])-pitchClass(KEYS[from][mode]));
      moved.chords.forEach((c,i)=>{assert.equal(pitchClass(c.root),mod(pitchClass(set.chords[i].root)+distance));assert.equal(pitchClass(c.bass),mod(pitchClass(set.chords[i].bass)+distance));assert.equal(c.id,set.chords[i].id);assert.equal(c.type,set.chords[i].type);});
    }
  }
});
test('Changing suggestion mode keeps the same tonic pitch and never converts existing chord qualities',()=>{
  const set=progression(),minor=changeSetMode(set,'minor');assert.equal(KEYS[minor.keyIndex].minor,'C');assert.deepEqual(minor.chords,set.chords);
  const back=changeSetMode(minor,'major');assert.deepEqual(back.chords,set.chords);assert.equal(back.keyIndex,0);
});
test('Repeated chords remain distinct; reordering, replacement and removal affect only the chosen occurrence',()=>{
  let set=addSetChord(newSet({date:at}),{root:'C',type:'major'});set=addSetChord(set,{root:'C',type:'major'});
  const [first,second]=set.chords;assert.notEqual(first.id,second.id);
  const moved=moveSetChord(set,second.id,-1);assert.equal(moved.chords[0].id,second.id);
  const edited=replaceSetChord(moved,second.id,{root:'D',type:'m7',bass:'F#'});assert.equal(setChordName(edited.chords[0]),'Dm7/F#');assert.equal(setChordName(edited.chords[1]),'C');
  assert.equal(removeSetChord(edited,first.id).chords.length,1);assert.equal(set.chords.length,2);
});
test('Invalid notes and types are rejected, duplicate occurrence IDs are repaired and the sequence limit is enforced',()=>{
  assert.equal(addSetChord(newSet({date:at}),{root:'<b>',type:'major'}),null);
  assert.equal(addSetChord(newSet({date:at}),{root:'C',type:'unknown'}),null);
  let set=newSet({date:at});for(let i=0;i<MAX_SET_CHORDS;i++)set=addSetChord(set,{root:'C',type:'major'});assert.equal(addSetChord(set,{root:'C',type:'major'}),null);
  const normalized=normalizeDraft({...set,chords:[set.chords[0],set.chords[0]]});assert.notEqual(normalized.chords[0].id,normalized.chords[1].id);
});
test('Draft autosave leaves a saved favorite unchanged until explicit Save; editing retains its identity',()=>{
  const storage=memory();let time=1000,uid=0;const store=createCompositionStore({storage,now:()=>++time,idFactory:()=>`set-${++uid}`});
  const created=store.save(progression());assert.equal(created.ok,true);assert.equal(store.list().length,1);
  const draft=addSetChord({...created.draft,name:'Куплет'}, {root:'E',type:'7'});assert.equal(store.saveDraft(draft),true);
  assert.equal(store.find(created.record.id).chords.length,4);assert.equal(store.draft.chords.length,5);
  const edited=store.save(draft);assert.equal(edited.record.id,created.record.id);assert.equal(store.list().length,1);assert.equal(store.find(created.record.id).name,'Куплет');
  assert.equal(storage.getItem('kvinta.preferences.v1'),'{"favorites":["major:0"]}');
});
test('Save as new preserves the source and allows equal names without merging records',()=>{
  let uid=0;const store=createCompositionStore({storage:memory(),now:()=>5000,idFactory:()=>`set-${++uid}`}),first=store.save(progression());
  const second=store.save(transposeSet(first.draft,2),{asNew:true});assert.equal(second.ok,true);assert.notEqual(second.record.id,first.record.id);assert.equal(second.record.name,first.record.name);assert.equal(store.list().length,2);
  assert.equal(setChordName(store.find(first.record.id).chords[0]),'C');assert.equal(setChordName(store.find(second.record.id).chords[0]),'D');
});
test('Deletion is restorable after reload and does not destroy the current chord draft',()=>{
  const storage=memory(),store=createCompositionStore({storage,now:()=>10000,idFactory:()=> 'song-a'}),saved=store.save(progression());
  assert.equal(store.remove(saved.record.id),true);assert.equal(store.list().length,0);assert.equal(store.draft.editingId,null);assert.equal(store.draft.chords.length,4);
  const reloaded=createCompositionStore({storage});assert.equal(reloaded.lastDeleted().id,'song-a');assert.equal(reloaded.restore('song-a'),true);assert.equal(reloaded.list().length,1);assert.equal(reloaded.list()[0].chords.length,4);
});
test('Storage errors never report success or mutate an existing favorite',()=>{
  const storage=memory();let blocked=false;const setter=storage.setItem;storage.setItem=(key,value)=>{if(blocked)throw new Error('quota');setter(key,value);};
  const store=createCompositionStore({storage,now:()=>5000,idFactory:()=> 'song-a'}),saved=store.save(progression());blocked=true;
  assert.equal(store.save({...saved.draft,name:'Не записано'}).ok,false);assert.equal(store.find('song-a').name,saved.record.name);assert.equal(store.remove('song-a'),false);assert.equal(store.list().length,1);assert.equal(store.saveDraft({...saved.draft,name:'Черновик'}),false);
});
test('Unreadable or future storage is preserved instead of being overwritten with an empty collection',()=>{
  for(const raw of ['broken JSON','{"schema":2,"sets":[]}']){
    const storage=memory();storage.data.set('kvinta.compositions.v1',raw);const store=createCompositionStore({storage});assert.equal(store.readError,true);assert.equal(store.save(progression()).ok,false);assert.equal(storage.getItem('kvinta.compositions.v1'),raw);
  }
});
