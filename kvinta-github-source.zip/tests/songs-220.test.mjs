import test from 'node:test';
import assert from 'node:assert/strict';
import {SONG_METERS,songMeter,normalizeSong,normalizeRehearsal,snapshot} from '../features/songs/src/score-model.js';
import {sharedSongSettings} from '../features/songs/src/song-settings.js';
import {METERS} from '../dist/modules/metronome-engine.js';
import {recordingBeat,recordingTime,recordingPoints,markRecordingLine,MAX_AUDIO_BYTES} from '../features/songs/src/recording-model.js';
import {createRecordingTransport} from '../features/songs/src/recording-transport.js';
import {songApiRequest} from '../worker/song-api.js';
const score=()=>normalizeSong({schema:2,id:'test-song',title:'Проверка',rehearsal:{bpm:120,meter:'3/4'},parts:[{id:'part',name:'Куплет',lines:[0,1,2].map(i=>({id:'line-'+i,text:'Строка '+i,chords:[{id:'chord-'+i,column:0,symbol:'Am',beats:4}]}))}],recording:{localId:'my-audio',name:'test.wav',duration:30,referenceBpm:120,enabled:true,times:[{lineId:'line-0',at:2},{lineId:'line-1',at:6},{lineId:'line-2',at:12}]}});

test('Song meters match Instruments including compound pulse units',()=>{
 assert.deepEqual(SONG_METERS,METERS.map(({id,beats,unit})=>({id,beats,unit})));assert.equal(songMeter('3/4').beats,3);assert.equal(songMeter('6/8').beats,2);assert.equal(songMeter('bad').id,'4/4');
});
test('Meter is saved with a song and cannot leak through common song preferences',()=>{
 assert.equal(normalizeRehearsal({}).meter,'4/4');assert.equal(sharedSongSettings({meter:'7/8'}).meter,undefined);const saved=snapshot(score(),{meter:'6/8'});assert.equal(saved.rehearsal.meter,'6/8');assert.deepEqual(saved.parts,score().parts);
});
test('Audio position interpolates marked lines and is invertible without accumulating clock drift',()=>{
 const song=score();assert.equal(recordingBeat(song,1),0);assert.equal(recordingBeat(song,2),0);assert.equal(recordingBeat(song,4),2);assert.equal(recordingBeat(song,9),6);assert.equal(recordingBeat(song,13),10);
 for(const beat of [0,1,2,4,5,7,8,9,11,12])assert.ok(Math.abs(recordingBeat(song,recordingTime(song,beat))-beat)<1e-7);
 for(let i=0;i<10000;i++)assert.equal(recordingBeat(song,9),6);
});
test('Sparse anchors extrapolate by reference tempo without compressing text to a short file',()=>{
 const song=score();song.recording.times=[{lineId:'line-0',at:0}];song.recording.duration=3;assert.equal(recordingPoints(song).at(-1).at,6);assert.equal(recordingBeat(song,2),4);
 song.recording.times=[{lineId:'line-2',at:0}];assert.equal(recordingBeat(song,0),8);assert.equal(recordingTime(song,0),0);
});
test('Taps preserve monotonic line entrances and reject crossing or equal marks',()=>{
 const song=score();assert.equal(markRecordingLine(song,'line-1',7.1234).times[1].at,7.123);assert.throws(()=>markRecordingLine(song,'line-1',1));assert.throws(()=>markRecordingLine(song,'line-1',12));assert.throws(()=>markRecordingLine(song,'unknown',7));assert.throws(()=>markRecordingLine(song,'line-1',NaN));
});
test('Recording metadata cannot introduce remote URLs, invalid times or unbounded names',()=>{
 const original=score(),song=normalizeSong({...original,recording:{...original.recording,localId:'https://private.test',url:'https://private.test',name:'x'.repeat(300),times:[{lineId:'unknown',at:2},{lineId:'line-0',at:5},{lineId:'line-1',at:4},{lineId:'line-2',at:31}]}});
 assert.equal(song.recording.localId,null);assert.equal(song.recording.url,undefined);assert.equal(song.recording.name.length,180);assert.deepEqual(song.recording.times,[{lineId:'line-0',at:5}]);
});
function harness({rejectStore=false}={}){
 let song=score(),deferred=null;const files=new Map(),revoked=[];
 const media={duration:30,currentTime:0,muted:false,paused:true,playbackRate:1,src:'',pause(){this.paused=true;},async play(){if(deferred)await deferred;this.paused=false;},load(){},removeAttribute(){this.src='';}};
 const store={get:async id=>files.get(id),put:async(id,file)=>{if(rejectStore)throw Error('quota');files.set(id,file);}};
 const transport=createRecordingTransport({media,store,getSong:()=>song,onRecord:value=>song={...song,recording:value},makeUrl:()=>`blob:local-${files.size}`,revokeUrl:url=>revoked.push(url),waitMetadata:async()=>media.duration});
 return {transport,media,files,revoked,get song(){return song;},setSong:next=>song=next,deferPlay(){let done;deferred=new Promise(r=>done=r);return ()=>{deferred=null;done();};}};
}
test('Local audio attaches, persists and restores from the device store',async()=>{
 const h=harness(),file={size:100,name:'guitar.mp3'};assert.equal(await h.transport.attach(file),true);assert.equal(h.files.get('my-audio'),file);assert.equal(h.song.recording.name,'guitar.mp3');assert.equal(h.transport.ready,true);assert.equal(await h.transport.restore(),true);assert.ok(h.revoked.length);h.transport.destroy();assert.equal(h.media.paused,true);
});
test('Restored recording starts at the saved line rather than disagreeing with visible text',async()=>{
 const h=harness();await h.transport.attach({size:10,name:'test.wav'});h.setSong({...h.song,rehearsal:{...h.song.rehearsal,line:1}});assert.equal(await h.transport.restore(),true);assert.equal(h.media.currentTime,6);
});
test('A late restore cannot replace a newly chosen recording',async()=>{
 let finish;const old=new Promise(r=>finish=r),h=harness(),media=h.media;let song=score(),urls=0;
 const transport=createRecordingTransport({media,getSong:()=>song,onRecord:r=>song={...song,recording:r},store:{get:()=>old,put:async()=>{}},makeUrl:()=>`blob:${++urls}`,revokeUrl(){},waitMetadata:async()=>30});
 const restore=transport.restore();await transport.attach({size:10,name:'new.wav'});finish({size:10,name:'old.wav'});assert.equal(await restore,false);assert.equal(song.recording.name,'new.wav');assert.equal(media.src,'blob:1');
});
test('Oversized audio and failed storage never claim a saved ready file',async()=>{
 const h=harness();await assert.rejects(()=>h.transport.attach({size:MAX_AUDIO_BYTES+1}),/80/);assert.equal(h.files.size,0);
 const failed=harness({rejectStore:true});await assert.rejects(()=>failed.transport.attach({size:10,name:'a.mp3'}));assert.equal(failed.transport.ready,false);assert.equal(failed.song.recording.name,'test.wav');
});
test('Recording transport follows media time, pauses and seeks to marked line entrances',async()=>{
 const h=harness();await h.transport.attach({size:10,name:'test.wav'});await h.transport.play();h.media.currentTime=9;assert.equal(h.transport.beat(),6);h.transport.seekLine(1);assert.equal(h.media.currentTime,6);h.transport.pause();assert.equal(h.transport.beat(),null);h.transport.seekBeat(8);assert.equal(h.media.currentTime,12);h.transport.restart();assert.equal(h.media.currentTime,0);
});
test('Recording metronome stays regular during an intro and does not inherit lyric timing errors',async()=>{
 const h=harness();await h.transport.attach({size:10,name:'test.wav'});h.setSong({...h.song,recording:{...h.song.recording,times:[{lineId:'line-0',at:10},{lineId:'line-1',at:20}]}});h.media.currentTime=0;assert.equal(h.transport.pulse(),-20);h.media.currentTime=.5;assert.equal(h.transport.pulse(),-19);h.media.currentTime=10;assert.equal(h.transport.pulse(),0);h.media.currentTime=12;assert.equal(h.transport.pulse(),4);
});
test('Audio unlock is muted, preserves position and cannot restart after cancellation',async()=>{
 const h=harness();await h.transport.attach({size:10,name:'test.wav'});h.media.currentTime=5;assert.equal(await h.transport.prepare(),true);assert.equal(h.media.currentTime,5);assert.equal(h.media.paused,true);assert.equal(h.media.muted,false);
 const finish=h.deferPlay(),pending=h.transport.prepare();h.transport.pause();finish();assert.equal(await pending,false);assert.equal(h.media.paused,true);
});
test('Rehearsal tempo changes playback speed while preserving pitch; unsupported rates are rejected',async()=>{
 const h=harness();await h.transport.attach({size:10,name:'test.wav'});assert.equal(h.transport.setTempo(150),true);assert.equal(h.media.playbackRate,1.25);assert.equal(h.media.preservesPitch,true);assert.equal(h.transport.setTempo(10),false);assert.equal(h.media.playbackRate,1.25);
});
test('Shared song retains meter and entrances but omits the device audio identity and file',async()=>{
 const objects=new Map(),env={BUCKET:{put:async(k,v)=>objects.set(k,v),get:async k=>objects.has(k)?{text:async()=>objects.get(k)}:null}};
 const response=await songApiRequest(new Request('https://trial.test/api/song-shares',{method:'POST',headers:{origin:'https://trial.test','content-type':'application/json'},body:JSON.stringify({song:score()})}),env,{limit:async()=>true});assert.equal(response.status,201);const link=await response.json();const opened=await songApiRequest(new Request('https://trial.test/api/song-shares/'+link.id),env);const data=await opened.json();assert.equal(data.song.rehearsal.meter,'3/4');assert.equal(data.song.recording.localId,null);assert.equal(data.song.recording.enabled,false);assert.deepEqual(data.song.recording.times,score().recording.times);assert.equal(data.song.recording.name,'Запись песни');
});
