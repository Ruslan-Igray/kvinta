import test from 'node:test';import assert from 'node:assert/strict';
import {createTunerPresentation,tunerHistoryPath} from '../dist/modules/tuner-presentation.js';
import {createPitchTracker,frequencyFor,normalizeTuner} from '../dist/modules/tuner-pitch.js';
const target={id:6,midi:40,note:'E'},model=(cents=0)=>({target,cents,frequency:frequencyFor(40)*2**(cents/1200),note:{note:'E',midi:40},tuned:Math.abs(cents)<=8,stable:true,uncertain:false,ambiguous:false}),measure=cents=>({frequency:frequencyFor(40)*2**(cents/1200),clarity:.99,rms:.02,clipped:false});
test('The last trustworthy pluck stays readable for four seconds and never remains a live confirmation',()=>{
 const view=createTunerPresentation();view.update(model(2),1000);let frame=view.update(null,1700);assert.equal(frame.phase,'last');assert.equal(frame.model.note.note,'E');assert.equal(frame.model.resultTuned,true);assert.equal(frame.model.tuned,false);assert.equal(frame.model.stable,false);assert.equal(frame.model.remembered,true);assert.equal(view.update(null,4999).phase,'last');assert.equal(view.update(null,5000).model,null);
});
test('Unclear noise, ambiguous targets and remembered frames cannot refresh a stale success indefinitely',()=>{
 const view=createTunerPresentation();view.update(model(),0);for(let t=200;t<4000;t+=100){const frame=view.update({...model(49),uncertain:true},t);assert.equal(frame.model.cents,0);assert.equal(frame.phase,'last');}assert.equal(view.update({...model(),stale:true},4001).model,null);assert.equal(view.update({...model(),ambiguous:true},4100).model,null);
});
test('Real detuning is not hidden; a confirmed next string clears the old history and resets the indicator',()=>{
 const view=createTunerPresentation();view.update(model(),0);let frame=view.update(model(32),40);assert.equal(frame.model.cents,32);assert.ok(frame.position>0&&frame.position<32);assert.equal(frame.model.tuned,false);frame=view.update({...model(-18),target:{id:5,midi:45,note:'A'},note:{note:'A',midi:45}},80);assert.equal(frame.points.length,1);assert.equal(frame.position,-18);assert.equal(frame.model.note.note,'A');view.reset();assert.equal(view.update(null,90).model,null);
});
test('The pitch trace has bounded size and explicit breaks across missing measurements instead of invented sound',()=>{
 const view=createTunerPresentation();let frame;for(let t=0;t<12000;t+=40)frame=view.update(model(Math.sin(t/100)),t);assert.ok(frame.points.length<=101);const path=tunerHistoryPath([{at:0,cents:-500},{at:40,cents:500},{at:800,cents:0}],800);assert.equal((path.match(/M/g)||[]).length,2);assert.ok(path.includes('2.00'));assert.ok(path.includes('98.00'));assert.equal(tunerHistoryPath([{at:0,cents:0}],5000),'');
});
test('Isolated edge and octave errors do not reset a settled pitch in either accuracy mode',()=>{
 for(const response of ['normal','precise']){const tracker=createPitchTracker(),settings=normalizeTuner({string:6,response});let current;for(let t=0;t<=600;t+=40)current=tracker.update(measure(0),t,settings);assert.ok(current.tuned);for(const [offset,cents] of [[40,110],[120,-140],[200,1200]]){assert.equal(tracker.update(measure(cents),600+offset,settings),null);current=tracker.update(measure(0),600+offset+40,settings);assert.ok(current);assert.ok(Math.abs(current.cents)<1);}}
});
test('Sustained pitch changes and a gradual tuning movement still reach their real values promptly',()=>{
 for(const response of ['normal','precise']){const tracker=createPitchTracker(),settings=normalizeTuner({string:6,response});let current;for(let t=0;t<=600;t+=40)current=tracker.update(measure(0),t,settings);for(let t=640;t<=1040;t+=40)current=tracker.update(measure(85),t,settings);assert.ok(current);assert.ok(Math.abs(current.cents-85)<1);assert.equal(current.tuned,false);for(let i=0;i<50;i++)current=tracker.update(measure(85-i*2),1080+i*40,settings);for(let i=0;i<20;i++)current=tracker.update(measure(-13),3080+i*40,settings);assert.ok(Math.abs(current.cents+13)<2);assert.equal(current.tuned,false);}
});
