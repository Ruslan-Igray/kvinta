import test from 'node:test';
import assert from 'node:assert/strict';
import {createPlaybackAudio,playbackAudio,observeAudioState} from '../dist/modules/playback-audio.js';
import {createClickFeedback} from '../dist/modules/feedback.js';
import {createChordPlayer} from '../dist/modules/chord-player.js';
import {createReferenceTone} from '../dist/modules/reference-tone.js';
import {createMetronomeEngine,normalizeMetro} from '../dist/modules/metronome-engine.js';
import {APP_SOUNDS,soundSamples} from '../dist/modules/ui-sounds.js';
import {createHoldRepeat,repeatDelay} from '../dist/modules/hold-stepper.js';
import {spectrumLevels} from '../dist/modules/tempo-visual.js';
import {createTempoCapture} from '../dist/modules/tempo-capture.js';
import {createTipSession} from '../dist/modules/tip-session.js';
import {createTipRotation,FACT_CARDS} from '../dist/modules/tip-rotation.js';
import {MUSIC_PHRASES} from '../dist/modules/music-phrases.js';
import {portraitFrame,setupPortrait} from '../dist/modules/portrait.js';

function audio(state='running'){
 const sources=[],events=[],listeners=new Set();
 const node=()=>({connect(){},disconnect(){}});
 const ctx={state,sampleRate:8000,currentTime:10,destination:{},events,sources,
  resume(){events.push('resume');this.state='running';return Promise.resolve();},close(){events.push('close');this.state='closed';listeners.forEach(f=>f());return Promise.resolve();},
  createGain(){return {...node(),gain:{value:1,setValueAtTime(){},setTargetAtTime(){}}};},
  createBuffer(c,n){const samples=new Float32Array(n);return {getChannelData:()=>samples};},
  createBufferSource(){const s={...node(),start(time){this.time=time;events.push('start');},stop(){this.stopped=true;}};sources.push(s);return s;},
  addEventListener(n,f){listeners.add(f);},removeEventListener(n,f){listeners.delete(f);},emit(){listeners.forEach(f=>f());},
  createMediaStreamSource:node,createAnalyser(){return {...node(),frequencyBinCount:128,getFloatFrequencyData(a){a.fill(-85);}};}
 };return ctx;
}
test('Playback unlock resumes and primes within the original gesture; recovery recreates a shared destination',async()=>{
 const contexts=[],route=[],nav={audioSession:{get type(){return route.at(-1)||'auto';},set type(t){route.push(t);}}};
 const manager=createPlaybackAudio({navigator:nav,contextFactory:()=>{const ctx=audio('suspended');contexts.push(ctx);return ctx;}});
 assert.equal(contexts.length,0);const ready=manager.unlock();assert.deepEqual(contexts[0].events,['resume','start']);assert.deepEqual(route,['auto','playback']);await ready;
 await manager.unlock();assert.equal(contexts.length,1);assert.equal(contexts[0].sources.length,1);
 contexts[0].state='interrupted';manager.markInterrupted();await manager.unlock();assert.equal(contexts[0].state,'running');assert.equal(route.at(-1),'playback');
 await manager.restore();assert.equal(contexts[0].state,'closed');assert.equal(contexts.length,2);assert.ok(manager.owns(contexts[1]));
});
test('All default playback tools use one context and do not overwrite each other’s state listeners',async()=>{
 const original=globalThis.AudioContext;const contexts=[];globalThis.AudioContext=class{constructor(){const ctx=audio();contexts.push(ctx);return ctx;}};
 try{
  const feedback=createClickFeedback(),metro=createMetronomeEngine({getSettings:()=>({}),setTimer:()=>1,clearTimer(){}}),chord=createChordPlayer(),reference=createReferenceTone();
  await feedback.play();await metro.audition();await chord.play([40,47,52,56,59,64]);await reference.play(440);assert.equal(contexts.length,1);assert.ok(contexts[0].sources.length>=9);
  contexts[0].state='interrupted';contexts[0].emit();assert.equal(chord.active,false);assert.equal(reference.active,false);
  metro.stop();await contexts[0].close();
 }finally{globalThis.AudioContext=original;}
});
test('Returning from the background swaps a still-running destination on the first sound action',async()=>{
 const original=globalThis.AudioContext,contexts=[];
 globalThis.AudioContext=class{constructor(){const ctx=audio();contexts.push(ctx);return ctx;}};
 try{
  const feedback=createClickFeedback(),metro=createMetronomeEngine({getSettings:()=>({}),setTimer:()=>1,clearTimer(){}}),chord=createChordPlayer(),reference=createReferenceTone();
  await feedback.play();await metro.audition();
  const old=contexts[0];
  old.close=()=>new Promise(()=>{});
  playbackAudio.markBackgrounded();
  assert.equal(contexts.length,1);
  assert.equal(await metro.start(),true);
  assert.equal(contexts.length,2);
  assert.ok(contexts[1].sources.length>=2);
  assert.equal(await feedback.play(),true);
  assert.equal(await chord.play([40,47,52,56,59,64]),true);
  assert.equal(await reference.play(440),true);
  assert.equal(contexts.length,2);
  metro.stop();chord.stop();reference.stop();await contexts[1].close();
 }finally{globalThis.AudioContext=original;}
});
test('Closed output contexts are recreated; a fresh clock does not suppress all subsequent clicks',async()=>{
 const first=audio(),second=audio();second.currentTime=0;let calls=0;const feedback=createClickFeedback({contextFactory:()=>++calls===1?first:second});
 await feedback.play();first.state='closed';assert.equal(await feedback.play(),true);assert.equal(second.sources.length,1);
 const a=audio(),b=audio();let count=0;const engine=createMetronomeEngine({getSettings:()=>({sound:'bell'}),audioContextFactory:()=>++count===1?a:b,setTimer:()=>1,clearTimer(){}});
 await engine.audition();a.state='closed';await engine.audition();assert.equal(count,2);assert.equal(b.sources.length,1);engine.stop();
});
test('Shared state observers are independent and removable',()=>{
 const ctx=audio();let a=0,b=0;const remove=observeAudioState(ctx,()=>a++);observeAudioState(ctx,()=>b++);ctx.emit();remove();ctx.emit();assert.equal(a,1);assert.equal(b,2);
});
test('Bell and triangle provide bounded distinct samples and persist through normalization',()=>{
 assert.equal(APP_SOUNDS.length,5);
 for(const rate of [8000,44100,48000,96000])for(const sound of ['bell','triangle'])for(const kind of ['beat','accent','sub']){const samples=soundSamples(rate,sound,kind);assert.ok(samples.every(n=>Number.isFinite(n)&&Math.abs(n)<=1));assert.equal(samples[0],0);assert.ok(Math.abs(samples.at(-1))<.0001);assert.ok(samples.some(n=>Math.abs(n)>.05));}
 assert.notDeepEqual(soundSamples(48000,'bell'),soundSamples(48000,'triangle'));assert.equal(normalizeMetro({sound:'bell'}).sound,'bell');assert.equal(normalizeMetro({sound:'triangle'}).sound,'triangle');
});
test('Hold repeat starts once, accelerates with duration and stops without a trailing step',()=>{
 let now=0,scheduled,delay,steps=0;const repeat=createHoldRepeat({clock:()=>now,onStep:()=>{steps++;},setTimer:(f,d)=>{scheduled=f;delay=d;return 1;},clearTimer(){scheduled=null;}});
 repeat.start();assert.equal(steps,1);assert.equal(delay,360);const counts=[];
 for(let second=1;second<=6;second++){const before=steps;while(now+delay<=second*1000){now+=delay;scheduled();}counts.push(steps-before);}
 assert.ok(counts.at(-1)>counts[0]*3);const last=scheduled;repeat.stop();const stopped=steps;last();assert.equal(steps,stopped);assert.equal(repeat.active,false);assert.ok(repeatDelay(5000)<repeatDelay(900));
});
test('Holding at a tempo boundary cancels further scheduled updates',()=>{
 let value=239,scheduled;const repeat=createHoldRepeat({onStep:()=>{if(value>=240)return false;value++;return true;},setTimer:f=>{scheduled=f;return 1;},clearTimer(){}});repeat.start();scheduled();assert.equal(value,240);assert.equal(repeat.active,false);
});
test('Audio-reactive levels are flat for silence, finite for missing bins and respond to actual spectrum',()=>{
 assert.deepEqual(spectrumLevels(new Float32Array(128).fill(-Infinity)),Array(24).fill(0));const quiet=spectrumLevels(new Float32Array(128).fill(-80)),loud=spectrumLevels(new Float32Array(128).fill(-20));assert.ok(loud.every((v,i)=>v>quiet[i]));assert.ok(loud.every(v=>v>=0&&v<=1));
});
test('Capture emits reactive levels and a live tempo before the final result, then releases microphone',async()=>{
 const ctx=audio();let now=0,tick,stopped=0,final,previews=[];
 ctx.createAnalyser=()=>({connect(){},disconnect(){},frequencyBinCount:128,getFloatFrequencyData(a){a.fill(now%500<40?-20:-85);}});
 const track={stop(){stopped++;},addEventListener(){},removeEventListener(){}};
 const capture=createTempoCapture({contextFactory:()=>ctx,mediaDevices:{getUserMedia:async()=>({getTracks:()=>[track]})},clock:()=>now,setTimer:f=>{tick=f;return 1;},clearTimer(){},onProgress:(p,live)=>previews.push({p,...live}),onResult:r=>final=r});
 await capture.start();for(now=20;now<=12000;now+=20)tick();assert.ok(previews.some(v=>v.elapsed<12000&&Math.abs(v.bpm-120)<=1));assert.ok(previews.some(v=>v.levels.some(n=>n>.5)));assert.ok(previews.some(v=>v.levels.every(n=>n===0)));assert.ok(Math.abs(final.bpm-120)<=1);assert.equal(stopped,1);assert.equal(capture.active,false);
});
test('Seven-card sessions alternate fact, real help and supplied humour without consuming an eighth',()=>{
 const map=new Map(),storage={getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,v)},facts=[['f1','b1'],['f2','b2'],['f3','b3']],guides=[['g1','h1'],['g2','h2']];
 const rotation=createTipRotation({facts,guides,phrases:['j1','j2'],storage,random:()=>.4}),session=createTipSession({next:i=>rotation.next(i)}),cards=Array.from({length:7},()=>session.next());
 assert.deepEqual(cards.map(c=>c.kind),['Факт','Из справки','Фраза','Факт','Из справки','Фраза','Факт']);assert.equal(session.next(),null);assert.equal(session.done,true);assert.equal(new Set(cards.filter(c=>c.kind==='Факт').map(c=>c.card[0])).size,3);
 const continued=createTipRotation({facts,guides,phrases:['j1','j2'],storage,random:()=>.4});assert.notDeepEqual(continued.next(0).card,cards.at(-1).card);assert.equal(MUSIC_PHRASES.length,69);assert.equal(new Set(MUSIC_PHRASES).size,69);assert.ok(FACT_CARDS.length>=180);
});
test('Portrait framing preserves logical dimensions and scales without a media stop callback',()=>{
 const frame=portraitFrame(844,390,{width:390,height:763},90);assert.deepEqual(frame,{width:390,height:763,scale:1,angle:90});assert.equal(portraitFrame(844,390,{width:390,height:763},270).angle,-90);assert.ok(portraitFrame(740,340,{width:390,height:763},90).scale<1);
});
test('Orientation changes preserve logical size without an asynchronous lock or a layout attribute toggle',()=>{
 const styles=new Map(),events=new Map(),root={dataset:{},style:{setProperty:(k,v)=>styles.set(k,v)}},view={innerWidth:390,innerHeight:763,addEventListener:(n,f)=>events.set(n,f)};
 let locks=0;const orientation={type:'portrait-primary',angle:0,lock(){locks++;},addEventListener:(n,f)=>events.set('screen-'+n,f)};
 setupPortrait({root,view,orientation,supportsTypedArithmetic:true});assert.equal(root.dataset.portraitCanvas,'true');assert.equal(styles.get('--portrait-height'),'763px');
 view.innerWidth=844;view.innerHeight=390;orientation.type='landscape-primary';orientation.angle=90;events.get('resize')();assert.equal(styles.get('--portrait-width'),'390px');assert.equal(styles.get('--portrait-height'),'763px');assert.equal(root.dataset.portraitFrame,undefined);
 orientation.angle=270;events.get('screen-change')();assert.equal(styles.get('--portrait-angle'),'-90deg');assert.equal(locks,0);
 view.innerWidth=390;view.innerHeight=400;orientation.type='portrait-primary';events.get('resize')();assert.equal(styles.get('--portrait-height'),'763px');
});
