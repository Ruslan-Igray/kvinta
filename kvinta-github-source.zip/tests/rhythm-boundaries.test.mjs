import test from 'node:test';
import assert from 'node:assert/strict';
import {GAME_METERS,gamePlan,scoreGame} from '../dist/modules/rhythm-game-model.js';

// One physical tap per requested musical beat, including the guided beats.
function events(p,{exit=-.022,jitter=.022}={}){
 return Array.from({length:p.total},(_,i)=>{const time=i*p.period,part=p.silences.find(a=>time>=a.from-1e-8&&time<a.to-1e-8);
  if(part?.task==='return')return null;
  const boundary=p.silences.some(a=>Math.abs(time-a.to)<1e-8);
  return {beat:i,time:time+(boundary?exit:part?(i%2?jitter:-jitter):0)};
 }).filter(Boolean);
}
const input={bpm:100,meter:'4/4',duration:15,pauses:2,bars:1,task:'keep',level:'normal'};
test('Reported 8/8, 22 ms case has zero phantom extras and scores 100%',()=>{
 const p=gamePlan(input),taps=events(p),r=scoreGame(p,taps.map(a=>a.time));
 assert.equal(taps.length,p.total);assert.equal(new Set(taps.map(a=>a.beat)).size,p.total);
 assert.deepEqual([r.hits,r.expected,r.meanErrorMs,r.extra,r.missed,r.score],[8,8,22,0,0,100]);
});
test('One millisecond either side of the first guided beat never becomes an extra silent tap',()=>{
 for(const task of ['keep','return','mix'])for(const exit of [-.001,0,.001,-.022,.022,-.08,.08]){
  const p=gamePlan({...input,task,bpm:100}),r=scoreGame(p,events(p,{exit,jitter:0}).map(a=>a.time));
  assert.equal(r.extra,0,JSON.stringify({task,exit,r}));assert.equal(r.missed,0);
 }
});
test('Pause entries, exits and compound meters keep single taps single across levels and tempos',()=>{
 let checked=0;
 for(const bpm of [40,60,90,100,120,150,180,240])for(const meter of GAME_METERS)for(const task of ['keep','return','mix'])for(const level of ['normal','hard','master'])for(const duration of [15,90])for(const bars of [1,4])for(const exit of [-.02,.02]){
  const p=gamePlan({bpm,meter,task,level,duration,bars,pauses:task==='mix'?2:1}),r=scoreGame(p,events(p,{exit,jitter:.02}).map(a=>a.time));
  assert.equal(r.extra,0,JSON.stringify({bpm,meter,task,level,duration,bars,exit,r}));
  assert.equal(r.missed,0);assert.equal(r.score,100);checked++;
 }
 assert.equal(checked,6336);
});
test('Both early and late taps on each requested boundary stay within the displayed tolerance',()=>{
 for(const task of ['keep','return','mix'])for(const level of ['normal','hard','master'])for(const sign of [-1,1]){
  const p=gamePlan({...input,task,level}),limit=scoreGame(p,[]).toleranceMs/1000,taps=events(p,{exit:sign*limit,jitter:0});
  for(const tap of taps)if(p.expected.some(a=>Math.abs(a.time-tap.beat*p.period)<1e-8))tap.time=tap.beat*p.period+sign*limit;
  const r=scoreGame(p,taps.map(a=>a.time));assert.equal(r.score,100,JSON.stringify({task,level,sign,r}));assert.equal(r.extra,0);
 }
});
test('Real repeated taps are still penalized in all three modes',()=>{
 for(const task of ['keep','return','mix']){
  const p=gamePlan({...input,task}),taps=events(p,{exit:0,jitter:0}).map(a=>a.time),duplicates=p.expected.filter((a,i,all)=>all.findIndex(b=>b.task===a.task)===i);
  const r=scoreGame(p,[...taps,...duplicates.map(a=>a.time+.09)]);
  assert.equal(r.extra,duplicates.length);assert.equal(r.missed,0);assert.ok(r.score<100);
 }
});
test('A forbidden tap inside a return pause remains an extra, including its first silent beat',()=>{
 const p=gamePlan({...input,task:'return'}),taps=events(p,{exit:0,jitter:0}).map(a=>a.time);
 for(const delta of [-.001,0,.001,.15]){const r=scoreGame(p,[...taps,p.silences[0].from+delta]);assert.equal(r.extra,1);assert.ok(r.score<100);}
});
test('Missing a requested tap remains a miss; an out-of-tolerance tap stays a mistimed tap',()=>{
 for(const task of ['keep','return','mix']){
  const p=gamePlan({...input,task}),taps=events(p,{exit:0,jitter:0}).map(a=>a.time),at=p.expected[0].time,without=taps.filter(t=>Math.abs(t-at)>1e-8),missing=scoreGame(p,without),late=scoreGame(p,[...without,at+.121]);
  assert.equal(missing.missed,1);assert.equal(missing.extra,0);assert.equal(late.missed,0);assert.equal(late.extra,0);assert.equal(late.hits,late.expected-1);
 }
});
test('Constant calibrated device offset does not reintroduce boundary extras',()=>{
 for(const offset of [-.06,.06])for(const task of ['keep','return','mix']){
  const p=gamePlan({...input,task,duration:30}),r=scoreGame(p,events(p).map(a=>a.time+offset));
  assert.equal(r.calibrationMs,offset*1000);assert.equal(r.extra,0);assert.equal(r.missed,0);assert.equal(r.score,100);
 }
});
