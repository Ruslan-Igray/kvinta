import './theory.test.mjs';
import './guitar.test.mjs';
import './metronome.test.mjs';
import './tuner.test.mjs';
import './compositions.test.mjs';
import './composition-drag.test.mjs';
import './rehearsal.test.mjs';
import './interface-v14.test.mjs';
import './sharing-audio.test.mjs';
import './readability.test.mjs';
import './release13.test.mjs';

import './sections.test.mjs';

import './release14.test.mjs';
import './release15.test.mjs';
import './release16.test.mjs';
import './release17.test.mjs';
import './release18.test.mjs';
import './release19.test.mjs';
import './release110.test.mjs';
import './release111.test.mjs';
import './release111-sharing.test.mjs';
import './release112.test.mjs';
import './telemetry.test.mjs';
