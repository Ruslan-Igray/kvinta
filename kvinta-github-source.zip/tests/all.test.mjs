import './theory.test.mjs';
import './guitar.test.mjs';
import './metronome.test.mjs';
import './tuner.test.mjs';
import './compositions.test.mjs';
import './composition-drag.test.mjs';
import './rehearsal.test.mjs';
import './interface-v14.test.mjs';
import './sharing-audio.test.mjs';
import './readability.test.mjs';
import './release13.test.mjs';

import './sections.test.mjs';
