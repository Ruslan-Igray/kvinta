import './theory.test.mjs';
import './guitar.test.mjs';
import './metronome.test.mjs';
import './tuner.test.mjs';
import './compositions.test.mjs';
import './composition-drag.test.mjs';
import './rehearsal.test.mjs';
import './interface-v14.test.mjs';
import './sharing-audio.test.mjs';
import './readability.test.mjs';
import './release13.test.mjs';

import './sections.test.mjs';

import './release14.test.mjs';
import './release15.test.mjs';
import './release16.test.mjs';
import './release17.test.mjs';
import './release18.test.mjs';
import './release19.test.mjs';
import './release110.test.mjs';
import './release111.test.mjs';
import './release111-sharing.test.mjs';
import './release112.test.mjs';
import './telemetry.test.mjs';

import './tuner-presentation.test.mjs';

import './tuner-live.test.mjs';

import './release20.test.mjs';

import './guide.test.mjs';

import './share-message.test.mjs';

import '../features/songs/tests/songs.test.mjs';
import '../features/songs/tests/editor.test.mjs';
import './install-guide.test.mjs';
import './songs-integration.test.mjs';

import './songs-fixes.test.mjs';
import './songs-212.test.mjs';
import './songs-214.test.mjs';
import './songs-215.test.mjs';
import './songs-220.test.mjs';
import './torch-221.test.mjs';
import './songs-223-ui.test.mjs';
import './recording-tap-tempo.test.mjs';
import './song-sync.test.mjs';
import './release-notice.test.mjs';
import './visual-rhythm.test.mjs';
import './live-updates.test.mjs';
import './startup-state.test.mjs';
import './settings-menu.test.mjs';
import './safety-247.test.mjs';
import './chord-timing.test.mjs';
import './backup.test.mjs';
import './audio-replacement.test.mjs';
import './workspace-260.test.mjs';
