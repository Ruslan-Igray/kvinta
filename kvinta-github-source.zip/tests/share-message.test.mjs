import test from 'node:test';
import assert from 'node:assert/strict';
import {setShareMessage,showSetShare} from '../dist/modules/composition-sharing.js';
import {newSet,addSetChord} from '../dist/modules/composition-model.js';
import {createSetLink,readSetLink} from '../dist/modules/composition-link.js';
import {createShareActions} from '../dist/modules/share-actions.js';
import {showAppShare,appShareMessage,APP_SHARE_URL,APP_SHARE_DESCRIPTION} from '../dist/modules/application-sharing.js';

const example=()=>addSetChord({...newSet({}),name:'Проба',rehearsal:{bpm:96,meter:'4/4',loop:true}},{root:'C',type:'major',beats:4});
function fixture(nav){
  const nodes=new Map(),node=selector=>{if(!nodes.has(selector))nodes.set(selector,{hidden:true,classList:{add(){}},handlers:{},addEventListener(event,fn){this.handlers[event]=fn;},focus(){this.focused=true;},select(){this.selected=true;}});return nodes.get(selector);};
  let html='',heading='';showSetShare({set:example(),base:'https://example.test/kvinta/',doc:{querySelector:node},nav,openSheet(title,body){heading=title;html=body;}});
  return {node,html,heading};
}
test('A shared message identifies a chord set and keeps the exact self-contained link once',()=>{
  const set=example(),before=JSON.stringify(set),url=createSetLink(set,'https://example.test/kvinta/'),message=setShareMessage(set,url);
  assert.match(message.title,/Набор аккордов «Проба»/);assert.match(message.text,/96 BPM · 4\/4/);
  assert.equal(message.clipboard.split(url).length,2);assert.equal(message.clipboard.endsWith(url),true);assert.equal(message.text.includes(url),false);
  assert.equal(readSetLink(new URL(url).hash).chords[0].beats,4);assert.equal(JSON.stringify(set),before);
});
test('Copying a message, copying only its URL and native sharing send the intended content',async()=>{
  const writes=[],shares=[],f=fixture({clipboard:{writeText:async value=>writes.push(value)},share:async value=>shares.push(value)});
  await f.node('#set-copy-link').handlers.click();assert.equal(f.node('#set-copy-link').textContent,'Скопировано');
  assert.match(writes[0],/^Набор аккордов «Проба»\n96 BPM · 4\/4\n/);assert.match(f.node('#set-share-status').textContent,/Сообщение/);
  await f.node('#set-copy-url').handlers.click();assert.equal(writes[1],f.node('#set-share-link').value);assert.ok(writes[1].startsWith('https://'));
  await f.node('#set-send-link').handlers.click();assert.equal(shares.length,1);assert.match(shares[0].title,/Набор аккордов/);assert.match(shares[0].text,/96 BPM/);assert.equal(shares[0].url,writes[1]);assert.equal(f.node('#set-send-link').hidden,false);
});
test('An unavailable clipboard offers a selected link without pretending the message was copied',async()=>{
  const f=fixture({});f.node('#set-copy-link').handlers.click();await Promise.resolve();
  assert.equal(f.node('.share-details').open,true);assert.equal(f.node('#set-share-link').focused,true);assert.equal(f.node('#set-share-link').selected,true);
  assert.match(f.node('#set-share-status').textContent,/Не удалось скопировать/);assert.equal(f.node('#set-send-link').hidden,true);
});

test('Native sharing records the attempt synchronously before the native call, without blocking user activation or counting delivery',async()=>{
  const events=[];let finish,calls=0;
  const actions=createShareActions({nav:{share:payload=>{calls++;assert.equal(payload.url,'https://example.test/');assert.deepEqual(events,['share_attempt']);return new Promise(resolve=>finish=resolve);}},analytics:{track:type=>events.push(type)}});
  const pending=actions.send({url:'https://example.test/'});
  assert.equal(calls,1);assert.deepEqual(events,['share_attempt']);
  assert.equal((await actions.send({url:'https://example.test/'})).status,'pending');assert.equal(calls,1);
  finish();assert.equal((await pending).status,'completed');assert.deepEqual(events,['share_attempt','share_send']);
});

test('Cancelled, failed and unsupported native sharing are separate from completion; failed copies do not count',async()=>{
  for(const [name,outcome,event] of [['AbortError','cancelled','cancel'],['NotAllowedError','failed','error']]){
    const events=[],actions=createShareActions({nav:{share:()=>{throw Object.assign(new Error(),{name});},clipboard:{writeText:async()=>{throw Error('denied');}}},analytics:{track:type=>events.push(type)},scope:'app'});
    assert.equal((await actions.send({})).status,outcome);assert.deepEqual(events,['app_share_attempt','app_share_'+event]);
    assert.equal(await actions.copy('text'),false);assert.equal(events.length,2);
  }
  const events=[],actions=createShareActions({nav:{},analytics:{track:type=>events.push(type)}});
  assert.equal((await actions.send({})).status,'unavailable');assert.deepEqual(events,[]);
});

function appFixture(nav){
  const nodes=new Map(),events=[],node=selector=>{if(!nodes.has(selector))nodes.set(selector,{hidden:true,handlers:{},addEventListener(event,fn){this.handlers[event]=fn;},focus(){this.focused=true;},select(){this.selected=true;}});return nodes.get(selector);};
  let title;showAppShare({openSheet:heading=>title=heading,doc:{querySelector:node},nav,analytics:{track:type=>events.push(type)}});return {node,events,title};
}

test('App sharing uses the approved description and canonical application link without any private set hash',async()=>{
  const writes=[],shares=[],f=appFixture({clipboard:{writeText:async text=>writes.push(text)},share:async payload=>shares.push(payload)}),message=appShareMessage();
  assert.equal(f.title,'Поделиться приложением');assert.equal(message.url,APP_SHARE_URL);assert.equal(message.text,APP_SHARE_DESCRIPTION);
  await f.node('#app-share-copy').handlers.click();await f.node('#app-share-send').handlers.click();
  assert.equal(writes[0],APP_SHARE_DESCRIPTION+'\n'+APP_SHARE_URL);assert.equal(writes[0].split(APP_SHARE_URL).length,2);
  assert.deepEqual(shares,[{title:'Квинта.',text:APP_SHARE_DESCRIPTION,url:APP_SHARE_URL}]);assert.deepEqual(f.events,['app_share_copy','app_share_attempt','app_share_send']);
  assert.match(f.node('#app-share-status').textContent,/Доставку.*проверьте/);
});

test('App sharing keeps manual copying available without a native share API or working clipboard',async()=>{
  const f=appFixture({});assert.equal(f.node('#app-share-send').hidden,true);await f.node('#app-share-copy').handlers.click();
  assert.equal(f.node('#app-share-link').value,APP_SHARE_URL);assert.equal(f.node('#app-share-link').selected,true);assert.equal(f.node('#app-share-link').focused,true);assert.deepEqual(f.events,[]);
});
