import test from 'node:test';
import assert from 'node:assert/strict';
import {setShareMessage,showSetShare} from '../dist/modules/composition-sharing.js';
import {newSet,addSetChord} from '../dist/modules/composition-model.js';
import {createSetLink,readSetLink} from '../dist/modules/composition-link.js';

const example=()=>addSetChord({...newSet({}),name:'Проба',rehearsal:{bpm:96,meter:'4/4',loop:true}},{root:'C',type:'major',beats:4});
function fixture(nav){
  const nodes=new Map(),node=selector=>{if(!nodes.has(selector))nodes.set(selector,{hidden:true,classList:{add(){}},handlers:{},addEventListener(event,fn){this.handlers[event]=fn;},focus(){this.focused=true;},select(){this.selected=true;}});return nodes.get(selector);};
  let html='',heading='';showSetShare({set:example(),base:'https://example.test/kvinta/',doc:{querySelector:node},nav,openSheet(title,body){heading=title;html=body;}});
  return {node,html,heading};
}
test('A shared message identifies a chord set and keeps the exact self-contained link once',()=>{
  const set=example(),before=JSON.stringify(set),url=createSetLink(set,'https://example.test/kvinta/'),message=setShareMessage(set,url);
  assert.match(message.title,/Набор аккордов «Проба»/);assert.match(message.text,/96 BPM · 4\/4/);
  assert.equal(message.clipboard.split(url).length,2);assert.equal(message.clipboard.endsWith(url),true);assert.equal(message.text.includes(url),false);
  assert.equal(readSetLink(new URL(url).hash).chords[0].beats,4);assert.equal(JSON.stringify(set),before);
});
test('Copying a message, copying only its URL and native sharing send the intended content',async()=>{
  const writes=[],shares=[],f=fixture({clipboard:{writeText:async value=>writes.push(value)},share:async value=>shares.push(value)});
  await f.node('#set-copy-link').handlers.click();assert.equal(f.node('#set-copy-link').textContent,'Скопировано');
  assert.match(writes[0],/^Набор аккордов «Проба»\n96 BPM · 4\/4\n/);assert.match(f.node('#set-share-status').textContent,/Сообщение/);
  await f.node('#set-copy-url').handlers.click();assert.equal(writes[1],f.node('#set-share-link').value);assert.ok(writes[1].startsWith('https://'));
  await f.node('#set-send-link').handlers.click();assert.equal(shares.length,1);assert.match(shares[0].title,/Набор аккордов/);assert.match(shares[0].text,/96 BPM/);assert.equal(shares[0].url,writes[1]);assert.equal(f.node('#set-send-link').hidden,false);
});
test('An unavailable clipboard offers a selected link without pretending the message was copied',async()=>{
  const f=fixture({});f.node('#set-copy-link').handlers.click();await Promise.resolve();
  assert.equal(f.node('.share-details').open,true);assert.equal(f.node('#set-share-link').focused,true);assert.equal(f.node('#set-share-link').selected,true);
  assert.match(f.node('#set-share-status').textContent,/Не удалось скопировать/);assert.equal(f.node('#set-send-link').hidden,true);
});
