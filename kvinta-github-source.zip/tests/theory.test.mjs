import test from 'node:test';
import assert from 'node:assert/strict';
import { KEYS, scaleFor, chordsFor, pitchClass, formatNote, closestRotation, signedAngleDelta, mod, wheelRoot } from '../dist/modules/theory.js';

test('Every key has seven distinctly spelled notes and the requested interval pattern', () => {
  for (let index = 0; index < 12; index++) for (const mode of ['major', 'minor']) {
    const scale = scaleFor(index, mode), root = pitchClass(KEYS[index][mode]);
    assert.equal(new Set(scale.map(note => note[0])).size, 7);
    assert.deepEqual(scale.map(note => mod(pitchClass(note) - root)), mode === 'major' ? [0,2,4,5,7,9,11] : [0,2,3,5,7,8,10]);
    for (const chord of chordsFor(index, mode)) {
      const intervals = chord.notes.map(note => mod(pitchClass(note) - pitchClass(chord.root)));
      assert.deepEqual(intervals, chord.quality === 'm' ? [0,3,7] : chord.quality === 'dim' ? [0,3,6] : [0,4,7]);
    }
  }
});
test('C major and A natural minor produce expected chords, keeping minor v', () => {
  assert.deepEqual(chordsFor(0).map(c => c.root + c.quality), ['C','Dm','Em','F','G','Am','Bdim']);
  assert.deepEqual(chordsFor(0, 'minor').map(c => c.root + c.quality), ['Am','Bdim','C','Dm','Em','F','G']);
  assert.deepEqual(scaleFor(6), ['F#','G#','A#','B','C#','D#','E#']);
  assert.deepEqual(scaleFor(7), ['Db','Eb','F','Gb','Ab','Bb','C']);
});
test('Frame windows contain exactly the six non-diminished diatonic chords in all 24 keys', () => {
  for (let index = 0; index < 12; index++) {
    const framed = [index - 1, index, index + 1].flatMap(i => [wheelRoot(mod(i), 'major', index), wheelRoot(mod(i), 'minor', index) + 'm']).sort();
    for (const mode of ['major', 'minor']) {
      const actual = chordsFor(index, mode).filter(c => c.quality !== 'dim').map(c => c.root + c.quality).sort();
      assert.deepEqual(actual, framed);
    }
  }
});
test('Notation preserves accidentals and separates international B from German H/B', () => {
  assert.equal(formatNote('B'), 'B'); assert.equal(formatNote('Bb'), 'B♭');
  assert.equal(formatNote('B', 'letters', true), 'H'); assert.equal(formatNote('Bb', 'letters', true), 'B');
  assert.equal(formatNote('B#', 'letters', true), 'H♯'); assert.equal(formatNote('F#', 'solfege'), 'Фа♯');
});
test('Rotation takes the short path through zero and preserves multiple turns', () => {
  assert.equal(closestRotation(330, 0), 360); assert.equal(closestRotation(0, 11), -30);
  assert.equal(closestRotation(1080, 1), 1110); assert.equal(signedAngleDelta(-179, 179), 2);
  assert.equal(signedAngleDelta(179, -179), -2);
});
