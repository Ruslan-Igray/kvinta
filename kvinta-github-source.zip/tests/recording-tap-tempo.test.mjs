import test from 'node:test';
import assert from 'node:assert/strict';
import {createRecordingTapEstimator,createRecordingTempoTap} from '../features/songs/src/recording-tap-tempo.js';
import {createRecordingTransport} from '../features/songs/src/recording-transport.js';
import {normalizeSong,normalizeRecording} from '../features/songs/src/score-model.js';

const feed=(estimator,values)=>{for(const value of values)estimator.tap(value);return estimator.state();};
const score=()=>normalizeSong({schema:2,id:'tap-song',title:'Проверка',rehearsal:{bpm:150,meter:'4/4'},parts:[{id:'verse',name:'Куплет',lines:[{id:'line-one',text:'Первая',chords:[]},{id:'line-two',text:'Вторая',chords:[]}]}],recording:{localId:'local-audio',name:'song.mp3',duration:40,referenceBpm:120,enabled:true,times:[{lineId:'line-one',at:1},{lineId:'line-two',at:12}]}});

test('Tap estimate waits for four taps and tolerates ordinary timing jitter',()=>{
 const estimator=createRecordingTapEstimator();feed(estimator,[0,.624,1.251]);assert.equal(estimator.state().bpm,null);
 const state=estimator.tap(1.875);assert.equal(state.bpm,96);assert.equal(state.stable,true);assert.equal(state.inRange,true);assert.equal(state.taps,4);
});

test('An accidental double tap and a missed beat do not double or halve the saved estimate',()=>{
 const estimator=createRecordingTapEstimator();feed(estimator,[0,.5,.56,1,1.5]);assert.equal(estimator.state().bpm,120);assert.equal(estimator.state().taps,4);
 feed(estimator,[2.5,3]);assert.equal(estimator.state().bpm,120);assert.equal(estimator.state().usableIntervals,4);
});

test('Seeking backwards and a long break start a new tap sequence',()=>{
 const estimator=createRecordingTapEstimator();feed(estimator,[0,.5,1,1.5]);assert.equal(estimator.state().bpm,120);
 let state=estimator.tap(5);assert.equal(state.bpm,null);assert.equal(state.taps,1);
 feed(estimator,[5.6,6.2,6.8]);assert.equal(estimator.state().bpm,100);
 state=estimator.tap(1);assert.equal(state.bpm,null);assert.equal(state.taps,1);assert.equal(estimator.tap(NaN).taps,1);
});

test('Irregular initial taps do not become an applicable BPM',()=>{
 const estimator=createRecordingTapEstimator(),state=feed(estimator,[0,.4,1,1.8]);assert.equal(state.bpm,null);assert.equal(state.stable,false);assert.equal(state.inRange,false);
});

test('The estimate follows the recent pulse instead of retaining the whole listening session',()=>{
 const estimator=createRecordingTapEstimator();feed(estimator,Array.from({length:12},(_,i)=>i*.5));assert.equal(estimator.state().bpm,120);
 let at=5.5;for(let i=0;i<12;i++){at+=.6;estimator.tap(at);}assert.equal(estimator.state().bpm,100);assert.equal(estimator.state().taps,10);
});

test('Half/double controls resolve pulse ambiguity within the supported recording range',()=>{
 const fast=createRecordingTapEstimator();feed(fast,[0,.2,.4,.6]);assert.equal(fast.state().bpm,300);assert.equal(fast.state().inRange,false);assert.equal(fast.state().canHalve,true);assert.equal(fast.adjust(.5).bpm,150);assert.equal(fast.state().inRange,true);
 const slow=createRecordingTapEstimator();feed(slow,[0,2,4,6]);assert.equal(slow.state().bpm,30);assert.equal(slow.state().canDouble,true);assert.equal(slow.adjust(2).bpm,60);assert.equal(slow.adjust(9).bpm,60);
});

function harness(){
 let song=score(),writes=0;
 const media={duration:40,currentTime:0,muted:false,paused:true,playbackRate:1,src:'',pause(){this.paused=true;},async play(){this.paused=false;},load(){},removeAttribute(){this.src='';}};
 const persist=record=>{writes++;song={...song,recording:normalizeRecording(record,song.parts)};};
 const transport=createRecordingTransport({media,getSong:()=>song,onRecord:persist,store:{get:async()=>({size:100}),put:async()=>{}},makeUrl:()=> 'blob:local',revokeUrl(){},waitMetadata:async()=>40});
 const tap=createRecordingTempoTap({getSong:()=>song,getTime:()=>media.currentTime,isPlaying:()=>!media.paused,getRate:()=>media.playbackRate,onRecord:record=>{persist(record);transport.setTempo(song.rehearsal.bpm);}});
 return {media,transport,tap,get song(){return song;},get writes(){return writes;},setSong:next=>song=next};
}
function mediaTaps(h,values){for(const value of values){h.media.currentTime=value;h.tap.tap();}}

test('Tap controller ignores paused or time-stretched playback and never saves intermediate readings',()=>{
 const h=harness();mediaTaps(h,[0,.5,1,1.5]);assert.equal(h.tap.state().taps,0);assert.equal(h.writes,0);
 h.media.paused=false;h.media.playbackRate=1.25;mediaTaps(h,[2,2.5,3,3.5]);assert.equal(h.tap.state().taps,0);assert.equal(h.writes,0);
 h.media.playbackRate=1;mediaTaps(h,[4,4.5,5]);assert.equal(h.tap.apply(),null);assert.equal(h.writes,0);assert.equal(h.song.recording.referenceBpm,120);
});

test('Explicit apply persists only reference BPM and preserves the latest line marks and rehearsal tempo',async()=>{
 const h=harness();await h.transport.attach({size:100,name:'song.mp3'});await h.transport.preview();const baselineWrites=h.writes;
 mediaTaps(h,[0,.6,1.2,1.8]);const current={...h.song.recording,times:[{lineId:'line-one',at:2},{lineId:'line-two',at:15}]};h.setSong({...h.song,recording:current});
 assert.equal(h.writes,baselineWrites);assert.equal(h.tap.apply(),100);assert.equal(h.writes,baselineWrites+1);assert.deepEqual(h.song.recording,{...current,referenceBpm:100,tempoVerified:true});assert.equal(h.song.rehearsal.bpm,150);assert.equal(h.media.playbackRate,1);
 const restored=normalizeSong(JSON.parse(JSON.stringify(h.song)));assert.equal(restored.recording.referenceBpm,100);assert.deepEqual(restored.recording.times,current.times);assert.equal(restored.recording.localId,current.localId);
});

test('Preview remains at original speed during apply, pause and player refresh; rehearsal resumes its requested rate',async()=>{
 const h=harness();await h.transport.attach({size:100,name:'song.mp3'});await h.transport.play();assert.equal(h.media.playbackRate,1.25);
 await h.transport.preview();assert.equal(h.transport.previewing,true);assert.equal(h.media.playbackRate,1);assert.equal(h.transport.setTempo(180),true);assert.equal(h.media.playbackRate,1);
 mediaTaps(h,[0,.625,1.25,1.875]);h.transport.pause();assert.equal(h.tap.state().canTap,false);assert.equal(h.tap.state().canApply,true);assert.equal(h.tap.apply(),96);assert.equal(h.media.paused,true);assert.equal(h.media.playbackRate,1);
 await h.transport.play();assert.equal(h.transport.previewing,false);assert.equal(h.media.playbackRate,150/96);
});

test('A draft measured for one song or file cannot be applied to another',()=>{
 const h=harness();h.media.paused=false;mediaTaps(h,[0,.6,1.2,1.8]);assert.equal(h.tap.state().canApply,true);
 h.setSong({...h.song,id:'another-song'});assert.equal(h.tap.apply(),null);assert.equal(h.tap.state().taps,0);assert.equal(h.writes,0);
 mediaTaps(h,[2,2.6,3.2,3.8]);h.setSong({...h.song,recording:{...h.song.recording,name:'other.mp3',duration:35}});assert.equal(h.tap.apply(),null);assert.equal(h.song.recording.referenceBpm,120);
});
