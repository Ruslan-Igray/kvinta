import test from 'node:test';
import assert from 'node:assert/strict';
import { MAX_SET_CHORDS,newSet,normalizeDraft,addSetChord,dropSetChord,createCompositionStore } from '../dist/modules/composition-model.js';
import { loadState,saveState } from '../dist/modules/storage.js';
import { MUSIC_TIPS,pickMusicTip } from '../dist/modules/music-tips.js';
import { createDrumPicker,drumIndex } from '../dist/modules/drum-picker.js';

test('Compact capacity rejects additions but never truncates a legacy favorite or draft',()=>{
  const legacy=normalizeDraft({...newSet(),chords:Array.from({length:128},(_,i)=>({id:'old-'+i,root:'C',type:'major',beats:i%32+1}))});
  assert.equal(MAX_SET_CHORDS,16);assert.equal(legacy.chords.length,128);assert.equal(addSetChord(legacy,{root:'G',type:'major'}),null);
  const replaced=dropSetChord(legacy,{chord:{root:'G',type:'major'}},{kind:'replace',index:127});assert.equal(replaced.set.chords.length,128);assert.equal(replaced.set.chords[127].beats,32);
  const data=new Map(),storage={getItem:k=>data.get(k),setItem:(k,v)=>data.set(k,v)},store=createCompositionStore({storage});
  assert.equal(store.save(legacy).ok,true);assert.equal(createCompositionStore({storage}).list()[0].chords.length,128);assert.equal(createCompositionStore({storage}).draft.chords.length,128);
});
test('Startup tips default on, persist opt-out, and fall back safely after broken preferences',()=>{
  const before=globalThis.localStorage;let raw=null;globalThis.localStorage={getItem:()=>raw,setItem:(k,v)=>{raw=v;}};
  try{assert.equal(loadState().startupTips,true);saveState({...loadState(),startupTips:false});assert.equal(loadState().startupTips,false);raw='broken';assert.equal(loadState().startupTips,true);}finally{if(before===undefined)delete globalThis.localStorage;else globalThis.localStorage=before;}
  assert.equal(pickMusicTip(()=>0),MUSIC_TIPS[0]);assert.equal(pickMusicTip(()=>.999),MUSIC_TIPS.at(-1));assert.equal(new Set(MUSIC_TIPS.map(t=>t[0])).size,MUSIC_TIPS.length);
});
function fixture(){
  const timers=new Map();let tid=0;
  class Element{
    constructor(){this.children=[];this.attrs={};this.events={};this.style={};this.scrollTop=0;this.classList={toggle:()=>{}};this.ownerDocument=doc;}
    append(el){this.children.push(el);}setAttribute(k,v){this.attrs[k]=v;}setPointerCapture(){}
    addEventListener(k,fn){(this.events[k]??=[]).push(fn);}fire(k,e={}){for(const fn of this.events[k]||[])fn(e);}
  }
  const win={events:{},addEventListener(k,fn){(this.events[k]??=[]).push(fn);},setTimeout(fn){timers.set(++tid,fn);return tid;},clearTimeout(id){timers.delete(id);},fire(k){for(const fn of this.events[k]||[])fn();}};
  const doc={defaultView:win,createElement:()=>new Element()},mount=new Element();let clicks=0,unlocks=0;const changes=[];
  const picker=createDrumPicker({mount,values:[20,21,22,23],label:'Tempo',onChange:v=>changes.push(v),feedback:{play:()=>{clicks++;},unlock:()=>{unlocks++;}}});
  return {picker,mount,rail:mount.children[0],win,changes,get clicks(){return clicks;},get unlocks(){return unlocks;},flush(){const pending=[...timers.values()];timers.clear();pending.forEach(fn=>fn());}};
}
test('Drums are silent on render, click on user steps, and commit a full drag once',()=>{
  const f=fixture();f.picker.set(21);assert.equal(f.rail.scrollTop,36);assert.equal(f.clicks,0);
  f.rail.fire('pointerdown',{pointerType:'mouse',clientY:100,pointerId:1});f.rail.fire('pointermove',{clientY:60});f.rail.fire('pointermove',{clientY:27});assert.equal(f.changes.length,0);assert.equal(f.clicks,2);
  f.win.fire('pointerup');f.flush();assert.deepEqual(f.changes,[23]);assert.equal(f.mount.attrs['aria-valuetext'],'23');
  f.rail.children[1].fire('click');f.flush();assert.deepEqual(f.changes,[23]); // suppress the release click
  f.picker.set(20);assert.equal(f.clicks,2);
});
test('Drum cancellation and disabled controls do not save a preview; keyboard respects bounds',()=>{
  const f=fixture();f.picker.set(21);f.rail.fire('pointerdown',{pointerType:'touch'});f.rail.scrollTop=108;f.rail.fire('scroll');f.picker.cancel();f.flush();assert.deepEqual(f.changes,[]);assert.equal(f.rail.scrollTop,36);
  f.picker.set(22,true);f.mount.fire('keydown',{key:'End',preventDefault(){}});assert.deepEqual(f.changes,[]);
  f.picker.set(22);f.mount.fire('keydown',{key:'End',preventDefault(){}});assert.deepEqual(f.changes,[23]);f.mount.fire('keydown',{key:'ArrowDown',preventDefault(){}});assert.deepEqual(f.changes,[23]);
  assert.equal(drumIndex(-100,221),0);assert.equal(drumIndex(1e6,221),220);assert.equal(drumIndex(53,221),1);assert.equal(drumIndex(54,221),2);
});
test('Saving during wheel inertia can flush the latest preview before the settle timer',()=>{
  const f=fixture();f.picker.set(20);f.rail.fire('wheel');f.rail.scrollTop=72;f.rail.fire('scroll');assert.deepEqual(f.changes,[]);
  f.picker.flush();assert.deepEqual(f.changes,[22]);f.flush();assert.deepEqual(f.changes,[22]);
});


test('Native touch scrolling keeps drum feedback after the browser cancels pointer ownership',()=>{
  const f=fixture();f.picker.set(20);f.rail.fire('pointerdown',{pointerType:'touch',clientY:100,pointerId:1});f.win.fire('pointercancel');
  f.rail.scrollTop=72;f.rail.fire('scroll');f.flush();assert.deepEqual(f.changes,[22]);assert.equal(f.clicks,1);assert.equal(f.rail.scrollTop,72);
});
