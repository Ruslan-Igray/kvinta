import test from 'node:test';import assert from 'node:assert/strict';
import {createTunerPresentation,tunerHistoryPath} from '../dist/modules/tuner-presentation.js';
import {createTipSession} from '../dist/modules/tip-session.js';
import {createStartupTipHandoff} from '../dist/modules/startup-tip-handoff.js';
const target={id:6,midi:40},model=cents=>({target,note:{midi:40,note:'E'},cents,frequency:82.4*2**(cents/1200),tuned:false,stable:false});
test('Ribbon smooths only the view, settles to real detuning, and resets at a different string',()=>{
 const p=createTunerPresentation();p.update(model(-20),0);let view;
 for(let t=40;t<=800;t+=40){const cents=-20+(t%80===0?3:-3);view=p.update(model(cents),t);assert.equal(view.model.cents,cents);}
 assert.ok(Math.abs(view.position+20)<1);assert.equal(view.model.tuned,false);
 for(let t=840;t<=3000;t+=40)view=p.update(model(25),t);
 assert.ok(Math.abs(view.position-25)<.5);assert.equal(view.model.frequency,model(25).frequency);
 view=p.update({...model(-12),target:{id:5,midi:45},note:{midi:45,note:'A'}},3040);
 assert.equal(view.points.length,1);assert.equal(view.position,-12);
});
test('Ribbon has curved joins, keeps gaps and never adds sound samples on silence',()=>{
 const p=createTunerPresentation();p.update(model(-10),0);p.update(model(2),40);p.update(model(10),80);const view=p.update(null,300);
 assert.equal(view.points.length,3);assert.equal(view.model.remembered,true);
 const d=tunerHistoryPath(view.points,view.traceAt);assert.match(d,/Q/);assert.ok(!d.includes('NaN'));
 assert.equal((tunerHistoryPath([{at:0,cents:0},{at:400,cents:2}],400).match(/M/g)||[]).length,2);
 assert.equal(p.update(null,4080).points.length,0);
});
const card=i=>({kind:'Факт',card:['Заголовок '+i,'Текст карточки '+i]});
function memory(){const map=new Map();return {getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,v),removeItem:k=>map.delete(k)};}
test('Release reload preserves the exact visible tip, position and seven-card allowance without drawing a replacement',()=>{
 let draws=0;const session=createTipSession({next:i=>{draws++;return card(i);}});session.next();session.next();session.previous();
 const store=memory(),transfer=createStartupTipHandoff({storage:store,now:()=>1000});assert.equal(transfer.save(session.snapshot(),true),true);
 const saved=transfer.take();assert.equal(saved.visible,true);assert.equal(transfer.take(),null);
 const restored=createTipSession({next:i=>{draws++;return card(i);},restore:saved.session});assert.deepEqual(restored.current,card(0));assert.equal(draws,2);
 assert.deepEqual(restored.next(),card(1));assert.equal(draws,2);while(restored.canNext)restored.next();assert.equal(draws,7);assert.equal(restored.next(),null);
});
test('Dismissed tip stays dismissed across an update; expired or malformed handoffs and blocked storage fail safely',()=>{
 const session=createTipSession({next:card});session.next();const storage=memory();
 const first=createStartupTipHandoff({storage,now:()=>1000});first.save(session.snapshot(),false);assert.equal(first.take().visible,false);
 first.save(session.snapshot(),true);assert.equal(createStartupTipHandoff({storage,now:()=>122000}).take(),null);
 storage.setItem('kvinta.tip-update.v1','broken');assert.equal(first.take(),null);
 assert.equal(first.save({cards:[{card:['bad']}],position:0},true),false);
 const blocked=createStartupTipHandoff({storage:{getItem(){throw Error();},setItem(){throw Error();}}});assert.equal(blocked.take(),null);assert.equal(blocked.save(session.snapshot(),true),false);
});
