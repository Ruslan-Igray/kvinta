import test from 'node:test';
import assert from 'node:assert/strict';
import { newSet,normalizeDraft,addSetChord,setChordDuration,transposeSet,dropSetChord,createCompositionStore,draftSignature } from '../dist/modules/composition-model.js';
import { normalizeDuration,normalizeRehearsal,makeRehearsalPlan,rehearsalFrame } from '../dist/modules/rehearsal-model.js';
import { createRehearsalTransport } from '../dist/modules/rehearsal-transport.js';
import { createMetronomeEngine,meterFor } from '../dist/modules/metronome-engine.js';

function song(durations=[2,3,1]){let set=newSet();for(const [i,beats] of durations.entries())set=addSetChord(set,{root:['C','G','A'][i%3],type:i%3===2?'minor':'major',beats});return set;}
test('Legacy sets gain four-beat durations and independent 96 BPM 4/4 rehearsal settings',()=>{
  const old={name:'Куплет',keyIndex:2,mode:'minor',chords:[{id:'old-c',root:'C',type:'major',bass:null}]};const set=normalizeDraft(old);
  assert.equal(set.name,'Куплет');assert.equal(set.chords[0].id,'old-c');assert.equal(set.chords[0].beats,4);assert.deepEqual(set.rehearsal,{bpm:96,meter:'4/4',loop:true});assert.equal(old.chords[0].beats,undefined);
  assert.equal(normalizeDuration(-8),1);assert.equal(normalizeDuration(100),32);assert.equal(normalizeDuration(null),4);assert.equal(normalizeDuration('8'),8);assert.equal(normalizeDuration(Infinity),4);
  assert.deepEqual(normalizeRehearsal({bpm:300,meter:'unknown',loop:false}),{bpm:240,meter:'4/4',loop:false});
});
test('Duration belongs to an occurrence; transposition, replacement, swapping and moving preserve it',()=>{
  const set=song(),edited=setChordDuration(set,set.chords[1].id,8);assert.deepEqual(edited.chords.map(c=>c.beats),[2,8,1]);assert.deepEqual(set.chords.map(c=>c.beats),[2,3,1]);
  assert.deepEqual(transposeSet(edited,2).chords.map(c=>c.beats),[2,8,1]);
  assert.equal(dropSetChord(edited,{chord:{root:'D',type:'7'}},{kind:'replace',index:1}).set.chords[1].beats,8);
  assert.deepEqual(dropSetChord(edited,{id:edited.chords[0].id},{kind:'replace',index:1}).set.chords.map(c=>c.beats),[8,2,1]);
  assert.deepEqual(setChordDuration(edited,null,6,{all:true}).chords.map(c=>c.beats),[6,6,6]);assert.notEqual(draftSignature(set),draftSignature(edited));
});
test('Tempo, meter, loop and durations survive save/reload/copy; autosave does not overwrite the favorite',()=>{
  const data=new Map(),storage={getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v)};let uid=0;
  const store=createCompositionStore({storage,idFactory:()=>`song-${++uid}`}),saved=store.save(song());
  const changed={...setChordDuration(saved.draft,saved.draft.chords[0].id,8),rehearsal:{bpm:132,meter:'6/8',loop:false}};assert.notEqual(draftSignature(changed),draftSignature(saved.record));store.saveDraft(changed);
  assert.equal(store.find(saved.record.id).rehearsal.bpm,96);assert.equal(store.draft.rehearsal.bpm,132);assert.equal(store.save(changed).ok,true);
  const reloaded=createCompositionStore({storage}),record=reloaded.find(saved.record.id);assert.deepEqual(record.rehearsal,changed.rehearsal);assert.equal(record.chords[0].beats,8);
  const copy=reloaded.save({...record,editingId:record.id},{asNew:true});assert.equal(copy.ok,true);assert.notEqual(copy.record.id,record.id);assert.deepEqual(copy.record.rehearsal,record.rehearsal);
});
test('Unequal durations transition on exact pulses and loop from the beginning without losing a beat',()=>{
  const plan=makeRehearsalPlan(song());assert.equal(plan.total,6);
  assert.deepEqual(Array.from({length:13},(_,i)=>rehearsalFrame(plan,i).index),[0,0,1,1,1,2,0,0,1,1,1,2,0]);
  assert.equal(rehearsalFrame(plan,5).beatInChord,0);assert.equal(rehearsalFrame(plan,6).cycle,2);assert.equal(rehearsalFrame(plan,6).beatInBar,2);assert.equal(rehearsalFrame(plan,6).bar,2);
});
test('One-shot finishes only after the full final duration; empty plan ends immediately',()=>{
  const set=song();set.rehearsal.loop=false;const plan=makeRehearsalPlan(set);
  assert.equal(rehearsalFrame(plan,5).ended,false);assert.equal(rehearsalFrame(plan,5).next,null);assert.equal(rehearsalFrame(plan,6).ended,true);assert.equal(rehearsalFrame(plan,100).ended,true);assert.equal(rehearsalFrame(makeRehearsalPlan(newSet()),0).ended,true);
});
test('Compound and odd meters count their actual metronome pulse; plan is a frozen snapshot',()=>{
  const set=song([4]);set.rehearsal.meter='6/8';const plan=makeRehearsalPlan(set);assert.equal(meterFor(plan.settings.meter).beats,2);
  assert.deepEqual([0,1,2,3].map(n=>rehearsalFrame(plan,n).beatInBar),[0,1,0,1]);assert.equal(rehearsalFrame(plan,3).bar,2);
  set.chords[0].beats=1;set.rehearsal.meter='7/8';assert.equal(plan.total,4);assert.equal(plan.settings.meter,'6/8');assert.equal(rehearsalFrame(plan,3).beatInChord,3);
});
function harness(set=song(),options={}){
  let settings,scheduled,time=0,due=[],starts=0,stops=0;const frames=[],states=[];
  const engine={async start(){starts++;return true;},stop(){stops++;due=[];},drain(){const events=due;due=[];return events;}};
  const transport=createRehearsalTransport({getSet:()=>set,engineFactory:c=>{settings=c;return engine;},requestFrame:fn=>{scheduled=fn;return 1;},cancelFrame:()=>{scheduled=null;},now:()=>time,onFrame:f=>frames.push(f),onState:(state,message)=>states.push({state,message}),...options});
  return {transport,engine,frames,states,get settings(){return settings;},get starts(){return starts;},get stops(){return stops;},pump(ms=16,ordinals=[]){time+=ms;due=ordinals.map(ordinal=>({ordinal,part:0}));const fn=scheduled;scheduled=null;fn?.();}};
}
test('Transport paints the latest audible beat, repeats, and never starts empty playback',async()=>{
  const h=harness();assert.equal(await h.transport.start(),true);h.pump(16,[0]);assert.equal(h.frames.at(-1).index,0);h.pump(16,[1,2]);assert.equal(h.frames.at(-1).index,1);h.pump(16,[6]);assert.equal(h.frames.at(-1).cycle,2);assert.equal(h.transport.active,true);
  assert.equal(await h.transport.start(),false);assert.equal(h.starts,1);h.transport.stop();assert.equal(h.frames.at(-1),null);assert.equal(h.transport.active,false);
  const empty=harness(newSet());assert.equal(await empty.transport.start(),false);assert.equal(empty.starts,0);
});
test('One-shot disallows the terminal click and stops at the precise end boundary',async()=>{
  const set=song();set.rehearsal.loop=false;const h=harness(set);await h.transport.start();assert.equal(h.settings.shouldSound({ordinal:5}),true);assert.equal(h.settings.shouldSound({ordinal:6}),false);
  h.pump(16,[5]);assert.equal(h.transport.active,true);h.pump(16,[6]);assert.equal(h.transport.active,false);assert.match(h.states.at(-1).message,/сыгран/);
});
test('Stop cancels a pending audio activation and prevents a late start from reviving playback',async()=>{
  const h=harness();let resume;h.engine.start=()=>new Promise(resolve=>{resume=resolve;});const pending=h.transport.start();assert.equal(h.transport.starting,true);h.transport.stop();resume(true);assert.equal(await pending,false);assert.equal(h.transport.active,false);assert.ok(!h.states.some(s=>s.state==='playing'));
});
test('Audio failure, interruption and a stalled foreground frame stop cleanly',async()=>{
  const failed=harness();failed.engine.start=async()=>{throw new Error('blocked');};assert.equal(await failed.transport.start(),false);assert.equal(failed.transport.active,false);assert.match(failed.states.at(-1).message,/звук/);
  const interrupted=harness();await interrupted.transport.start();interrupted.settings.onInterrupted();assert.equal(interrupted.transport.active,false);
  const stalled=harness();await stalled.transport.start();stalled.pump(700,[0,1,2]);assert.equal(stalled.transport.active,false);assert.match(stalled.states.at(-1).message,/паузы/);
});
test('A wake lock arriving after Stop is released instead of keeping the screen awake',async()=>{
  let resolve,releases=0;const h=harness(song(),{requestWakeLock:()=>new Promise(done=>{resolve=done;})});await h.transport.start();await Promise.resolve();h.transport.stop();resolve({release(){releases++;}});await Promise.resolve();await Promise.resolve();assert.equal(releases,1);assert.equal(h.transport.active,false);
});
test('Audio engine keeps the end timestamp for the visual transport without scheduling an extra click',async()=>{
  const sources=[];let pump;const ctx={currentTime:0,state:'running',sampleRate:8000,destination:{},createGain:()=>({connect(){},gain:{setValueAtTime(){},setTargetAtTime(){}}}),createBuffer:(c,n)=>({getChannelData:()=>new Float32Array(n)}),createBufferSource:()=>{const s={connect(){},disconnect(){},start(t){this.time=t;},stop(){this.stopped=true;}};sources.push(s);return s;}};
  const engine=createMetronomeEngine({getSettings:()=>({bpm:240,meter:'4/4'}),shouldSound:e=>e.ordinal<2,audioContextFactory:()=>ctx,setTimer:fn=>{pump=fn;return 1;},clearTimer(){}});
  await engine.start();ctx.currentTime=.2;pump();ctx.currentTime=.45;pump();ctx.currentTime=.55;
  assert.equal(sources.length,2);assert.ok(engine.drain().some(e=>e.ordinal===2));engine.stop();assert.ok(sources.every(s=>s.stopped));
});
