import test from 'node:test';
import assert from 'node:assert/strict';
import {matchesGuideSearch} from '../dist/modules/guide-search.js';
import {guideEntries} from '../dist/modules/help-content.js';

test('Guide search does not mistake internet availability for a missing sound',()=>{
  assert.equal(matchesGuideSearch('Работает без интернета. Звук аккорда.', 'нет звука'),false);
  assert.equal(matchesGuideSearch('Нет звука? Нажмите «Восстановить звук».','НЕТ ЗВУКА'),true);
  const matches=guideEntries('2.02').filter(([title,body])=>matchesGuideSearch(title+' '+body.replace(/<[^>]+>/g,' '),'нет звука'));
  assert.ok(matches.some(([title])=>title.includes('восстановление звука')));
  assert.ok(matches.every(([title])=>!title.includes('Поделиться')&&!title.includes('С чего начать')));
});
test('Guide search accepts musical symbols, punctuation, ё and word prefixes while requiring all terms',()=>{
  assert.equal(matchesGuideSearch('Отсчёт: четыре удара палочками','отсчет палоч'),true);
  assert.equal(matchesGuideSearch('Строй: F♯ и B♭','F# Bb'),true);
  assert.equal(matchesGuideSearch('Строй: F♯ и B♭','F# ми'),false);
  assert.equal(matchesGuideSearch('Сохранить набор.','сохрани'),true);
  assert.equal(matchesGuideSearch('Микрофон слышит струну.','ми'),false);
  assert.equal(matchesGuideSearch('Любая тема',''),true);
});
