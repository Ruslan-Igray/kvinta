import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {songApiRequest} from './worker/song-api.js';
const objects=new Map(),env={BUCKET:{async put(k,v){objects.set(k,v);},async get(k){return objects.has(k)?{text:async()=>objects.get(k)}:null;}}},port=Number(process.env.KVINTA_PORT)||4173;
const root = fileURLToPath(new URL('./dist/', import.meta.url));
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer(async (request, response) => {
  try {
    if(request.url.startsWith('/api/')){
      const chunks=[];let size=0;for await(const chunk of request){size+=chunk.length;if(size>400000){response.writeHead(413).end();return;}chunks.push(chunk);}
      const api=await songApiRequest(new Request('http://localhost:'+port+request.url,{method:request.method,headers:request.headers,...(!['GET','HEAD'].includes(request.method)?{body:Buffer.concat(chunks)}:{})}),env);
      if(api){response.writeHead(api.status,Object.fromEntries(api.headers));response.end(Buffer.from(await api.arrayBuffer()));return;}
    }
    let pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
    if (pathname.endsWith('/')) pathname += 'index.html';
    const filename = path.resolve(root, '.' + pathname);
    if (!filename.startsWith(path.resolve(root) + path.sep)) { response.writeHead(403).end(); return; }
    const data = await readFile(filename);
    response.writeHead(200, { 'Content-Type': types[path.extname(filename)] || 'application/octet-stream', 'Cache-Control': 'no-cache' }); response.end(data);
  } catch { response.writeHead(404).end('Not found'); }
});
server.listen(port, '127.0.0.1', () => console.log('Local: http://localhost:'+port));
