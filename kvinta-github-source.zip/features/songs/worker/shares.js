import {normalizeSong} from '../src/score-model.js';
import {songOriginAllowed} from '../../../worker/song-api.js';
const SHARE_ID=/^[a-zA-Z0-9_-]{22}$/;
const shareJson=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export async function sharesRequest(request,env){
 const url=new URL(request.url);if(!url.pathname.startsWith('/api/song-shares'))return null;
 if(!env.BUCKET)return shareJson({error:'Обмен пока недоступен. Сохраните композицию и попробуйте позже.'},503);
 try{
  if(url.pathname==='/api/song-shares'&&request.method==='POST'){
   if(!songOriginAllowed(request.headers.get('origin'),url))return shareJson({error:'Не удалось проверить запрос.'},403);
   if(!request.headers.get('content-type')?.startsWith('application/json'))return shareJson({error:'Неверный формат.'},415);
   if(Number(request.headers.get('content-length'))>350000)return shareJson({error:'Композиция слишком большая для ссылки.'},413);
   const reader=request.body?.getReader();if(!reader)return shareJson({error:'Нет композиции.'},400);
   let size=0;const chunks=[];while(true){const {value,done}=await reader.read();if(done)break;size+=value.length;if(size>350000){await reader.cancel();return shareJson({error:'Композиция слишком большая для ссылки.'},413);}chunks.push(value);}
   const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}
   let data;try{data=JSON.parse(new TextDecoder().decode(bytes));}catch{return shareJson({error:'Неверный формат композиции.'},400);}
   const song=normalizeSong(data.song),random=crypto.getRandomValues(new Uint8Array(16)),id=btoa(String.fromCharCode(...random)).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');
   const payload={version:1,song,createdAt:Date.now()};
   await env.BUCKET.put('song-shares/'+id+'.json',JSON.stringify(payload),{httpMetadata:{contentType:'application/json'}});
   const base=['localhost','127.0.0.1','trial.test'].includes(url.hostname)?url.origin:'https://ruslan-igray.github.io/kvinta';
   return shareJson({id,url:base+'/songs/#song='+id},201);
  }
  const match=url.pathname.match(/^\/api\/song-shares\/([a-zA-Z0-9_-]+)$/);
  if(request.method==='GET'&&match&&SHARE_ID.test(match[1])){
   const file=await env.BUCKET.get('song-shares/'+match[1]+'.json');if(!file)return shareJson({error:'Эта версия композиции не найдена. Попросите новую ссылку.'},404);
   const data=JSON.parse(await file.text());return shareJson({song:normalizeSong(data.song),createdAt:data.createdAt});
  }
  return shareJson({error:'Ссылка не найдена.'},404);
 }catch(e){return shareJson({error:e.message?.startsWith('Не удалось')||e.message?.startsWith('Неверный')||e.message?.startsWith('В композиции')?e.message:'Не удалось подготовить композицию для обмена. Попробуйте ещё раз.'},422);}
}
