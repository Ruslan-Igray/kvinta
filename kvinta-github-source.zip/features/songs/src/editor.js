import {CUE_PRESETS,COLORS,linesOf,findLine,findChord,moveChord,addChord,setPartBeats,partBeats,splitPart,createHistory} from './score-model.js';
const copy=value=>JSON.parse(JSON.stringify(value));
const number=value=>String(Number(value.toFixed(2))).replace('.',',');
const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function mountEditor({phone,getSong,onChange,onSave,onShare,toDisplay=s=>s,toStored=s=>s}){
 let editing=false,dirty=false,history=createHistory(getSong()),selected=null,pointer=null,hold=null,drag=null,swallowUntil=0,scrollFrame=0,lastFrame=0;
 const reader=phone.querySelector('.qs-reader');
 const bar=document.createElement('div');bar.className='ke-editbar';
 bar.innerHTML='<div class="ke-edit-switch" role="group" aria-label="Работа с песней"><button class="ke-view" aria-pressed="true">Репетиция</button><button class="ke-edit" aria-pressed="false">Редактор</button></div><button class="ke-undo qs-icon" aria-label="Отменить правку" disabled><i data-lucide="undo-2" aria-hidden="true"></i></button><button class="ke-save" type="button">Сохранить</button><button class="ke-share qs-icon" aria-label="Поделиться композицией"><i data-lucide="share-2" aria-hidden="true"></i></button>';
 phone.querySelector('.qs-song-heading').after(bar);
 const editTools=document.createElement('div');editTools.className='ke-addbar';editTools.hidden=true;
 editTools.innerHTML='<button class="ke-add-chord">+ Аккорд</button><button class="ke-add-cue">Пометка</button><button class="ke-part">Блок</button><span class="ke-dirty" role="status" aria-live="polite"></span>';
 bar.after(editTools);
 editTools.append(bar.querySelector('.ke-undo'));
 const overlay=document.createElement('div');overlay.className='ke-overlay';overlay.hidden=true;
 overlay.innerHTML='<section class="ke-dialog" role="dialog" aria-modal="true" aria-label="Редактирование"><header><h2></h2><button class="qs-icon ke-modal-close" aria-label="Закрыть редактирование"><i data-lucide="x" aria-hidden="true"></i></button></header><div class="ke-dialog-body"></div><div class="ke-dialog-actions"></div></section>';
 phone.append(overlay);
 const ghost=document.createElement('div');ghost.className='ke-drag-ghost';ghost.hidden=true;ghost.setAttribute('aria-hidden','true');
 const caret=document.createElement('div');caret.className='ke-drop-caret';caret.hidden=true;caret.setAttribute('aria-hidden','true');phone.append(ghost,caret);
 const $=s=>phone.querySelector(s),$$=s=>[...phone.querySelectorAll(s)];
 let previousFocus=null,inertBefore=[];
 function icons(){globalThis.lucide?.createIcons();}
 function show(title,body,actions){window.kvintaPlayer.stop();previousFocus=document.activeElement;overlay.querySelector('h2').textContent=title;$('.ke-dialog-body').innerHTML=body;$('.ke-dialog-actions').innerHTML=actions;inertBefore=[...phone.children].filter(el=>el!==overlay).map(el=>[el,el.inert]);for(const [el]of inertBefore)el.inert=true;overlay.hidden=false;icons();$('.ke-modal-close').focus();}
 function close(){overlay.hidden=true;for(const [el,value]of inertBefore)el.inert=value;inertBefore=[];if(previousFocus?.isConnected)previousFocus.focus?.();else $(editing?'.ke-edit':'.ke-view').focus();}
 $('.ke-modal-close').onclick=close;overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
 function updateBar(){
  phone.dataset.editing=String(editing);window.kvintaEditing=editing;editTools.hidden=!editing;
  $('.ke-view').setAttribute('aria-pressed',String(!editing));$('.ke-edit').setAttribute('aria-pressed',String(editing));
  $('.ke-undo').disabled=!history.canUndo;$('.ke-dirty').textContent=dirty?'Есть правки':'';
  $('.ke-save').classList.toggle('is-dirty',dirty);
 }
 function setEditing(value){if(editing===value)return;window.kvintaPlayer.stop();editing=!!value;window.kvintaEditing=editing;window.kvintaPlayer.refresh();updateBar();}
 function mutate(fn){const next=copy(getSong());fn(next);next.updatedAt=Date.now();history.commit(next);dirty=true;onChange(next);updateBar();}
 function decorate(){
  const song=getSong();$$('.qs-part').forEach((el,i)=>{const part=song.parts[i],h=el.querySelector('h2');el.dataset.partId=part.id;h.replaceChildren();const button=document.createElement('button');button.type='button';button.className='ke-part-title';button.textContent=part.name;button.setAttribute('aria-label','Настроить блок '+part.name);button.disabled=!editing;button.onclick=()=>openPart(part.id);h.append(button);});
  $$('.qs-line').forEach((el,i)=>{el.dataset.lineId=linesOf(song)[i].id;});icons();
 }
 window.addEventListener('kvinta:score-rendered',decorate);
 function context(){const song=getSong();return selected?.lineId&&findLine(song,selected.lineId)?selected:{lineId:linesOf(song)[Math.min(window.kvintaPlayer.getState().line,linesOf(song).length-1)].id,column:0};}
 $('.ke-edit').onclick=()=>setEditing(true);$('.ke-view').onclick=()=>setEditing(false);
 $('.ke-undo').onclick=()=>{const next=history.undo();dirty=true;onChange(next);updateBar();};
 $('.ke-save').onclick=()=>{if(onSave()){dirty=false;updateBar();}};
 $('.ke-share').onclick=()=>{window.kvintaPlayer.stop();onShare();};
 $('.ke-add-chord').onclick=()=>{const c=context();openChord(null,c.lineId,c.column);};
 $('.ke-add-cue').onclick=()=>{const c=context();openCue(c.lineId);};
 $('.ke-part').onclick=()=>{const c=context(),p=getSong().parts.find(p=>p.lines.some(l=>l.id===c.lineId));openPart(p.id);};
 window.addEventListener('kvinta:finish-edit',()=>{if(editing)setEditing(false);});
 window.addEventListener('kvinta:edit-block',e=>{const line=linesOf(getSong())[e.detail.line],part=getSong().parts.find(p=>p.lines.includes(line));if(part)openPart(part.id);});
 function beatControl(value,max=128,min=.5){return '<div class="ke-beats"><button type="button" data-beat-step="-0.5" aria-label="Уменьшить доли">−</button><input class="ke-beat-value" type="number" inputmode="decimal" min="'+min+'" max="'+max+'" step="0.5" value="'+value+'" aria-label="Количество долей"><button type="button" data-beat-step="0.5" aria-label="Увеличить доли">+</button></div><input class="ke-beat-range" aria-label="Доли прокруткой" type="range" min="'+min+'" max="'+max+'" step="0.5" value="'+value+'">';}
 function bindBeats(){
  const input=$('.ke-beat-value'),range=$('.ke-beat-range'),min=Number(input.min),max=Number(input.max);
  const value=n=>{n=Math.max(min,Math.min(max,Math.round(n*2)/2));input.value=range.value=n;};
  input.oninput=()=>{if(Number.isFinite(input.valueAsNumber))range.value=input.valueAsNumber;};input.onchange=()=>value(input.valueAsNumber||min);
  range.oninput=()=>value(range.valueAsNumber);$$('[data-beat-step]').forEach(b=>b.onclick=()=>value((input.valueAsNumber||min)+Number(b.dataset.beatStep)));
  return ()=>Math.max(min,Math.min(max,Math.round((input.valueAsNumber||min)*2)/2));
 }
 function chordFields(symbol){
  const match=symbol.match(/^([A-H][#b♯♭]*)(.*)$/),root=match?.[1]||'Am',quality=match?.[2]||'';
  const notes=['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'];if(!notes.includes(root))notes.push(root);
  const types=[['','Мажор'],['m','Минор'],['7','7'],['maj7','maj7'],['m7','m7'],['sus2','sus2'],['sus4','sus4'],['5','5'],['dim','dim'],['aug','aug'],['add9','add9'],['9','9'],['m7b5','m7b5']];if(!types.some(x=>x[0]===quality))types.push([quality,quality]);
  return '<div class="ke-chord-fields"><label>Основной тон<select class="ke-root">'+notes.map(n=>'<option '+(n===root?'selected':'')+'>'+esc(n)+'</option>').join('')+'</select></label><label>Тип аккорда<select class="ke-quality">'+types.map(([v,label])=>'<option value="'+esc(v)+'" '+(v===quality?'selected':'')+'>'+esc(label)+'</option>').join('')+'</select></label></div><output class="ke-chord-preview">'+esc(symbol)+'</output>';
 }
 function openChord(chordId,lineId,column=0){
  const found=chordId?findChord(getSong(),chordId):null,line=found?.line||findLine(getSong(),lineId);if(!line)return;
  const chord=found?.chord||{symbol:'Am',beats:4,column};selected={lineId:line.id,column:chord.column};
  show(chordId?'Аккорд':'Добавить аккорд',chordFields(chordId?toDisplay(chord.symbol):'Am')+'<label class="ke-field-title">Доли</label>'+beatControl(chord.beats,Math.max(128,chord.beats))+'<label class="ke-position-label">Место в строке <output>'+chord.column+'</output><input class="ke-column" type="range" min="0" max="'+Math.max(line.text.length,32)+'" value="'+chord.column+'" aria-label="Место аккорда в тексте"></label>',(chordId?'<button class="ke-delete">Удалить</button>':'')+'<button class="ke-apply kl-primary">Готово</button>');
  const readBeats=bindBeats(),readSymbol=()=>$('.ke-root').value+$('.ke-quality').value;
  for(const name of ['.ke-root','.ke-quality'])$(name).onchange=()=>$('.ke-chord-preview').textContent=readSymbol();
  $('.ke-column').oninput=e=>$('.ke-position-label output').textContent=e.target.value;
  $('.ke-apply').onclick=()=>{const symbol=toStored(readSymbol()),beats=readBeats(),col=Number($('.ke-column').value);mutate(song=>{if(chordId){const f=findChord(song,chordId);if(!f)return;f.chord.symbol=symbol;f.chord.beats=beats;moveChord(song,chordId,line.id,col);}else addChord(song,line.id,col,symbol,beats);});close();};
  if(chordId)$('.ke-delete').onclick=()=>{mutate(song=>{const f=findChord(song,chordId);f.line.chords=f.line.chords.filter(c=>c.id!==chordId);});close();};
 }
 function colors(current){return '<div class="ke-colors" role="group" aria-label="Цвет пометки">'+COLORS.map((c,i)=>'<button type="button" class="ke-color" data-color="'+c+'" aria-label="'+['Янтарный','Бирюзовый','Синий','Фиолетовый','Розовый','Красный'][i]+'" aria-pressed="'+String(c===current)+'"><span></span></button>').join('')+'</div>';}
 function openCue(lineId,cueId=null,type='cue'){
  const line=findLine(getSong(),lineId);if(!line)return;const cue=line.cues.find(c=>c.id===cueId)||{preset:'pedal-on',label:'Педаль вкл.',color:'amber',type};
  let color=cue.color;
  show(cue.type==='line'?'Цветная линия':'Пометка для игры',(cue.type==='cue'?'<label class="ke-field-title">Действие<select class="ke-cue-preset">'+CUE_PRESETS.map(p=>'<option value="'+p.id+'" '+(p.id===cue.preset?'selected':'')+'>'+p.label+'</option>').join('')+'</select></label><label class="ke-field-title">Подпись<input class="ke-cue-label" maxlength="50" value="'+esc(cue.label)+'" placeholder="Например: Delay вкл."></label>':'')+'<label class="ke-field-title">Цвет</label>'+colors(color),(cueId?'<button class="ke-delete">Удалить</button>':'')+'<button class="ke-apply kl-primary">Готово</button>');
  if(cue.type==='cue')$('.ke-cue-preset').onchange=e=>{$('.ke-cue-label').value=CUE_PRESETS.find(p=>p.id===e.target.value).label;};
  $$('.ke-color').forEach(b=>b.onclick=()=>{color=b.dataset.color;$$('.ke-color').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));});
  $('.ke-apply').onclick=()=>{const preset=cue.type==='cue'?$('.ke-cue-preset').value:'custom',label=cue.type==='cue'?$('.ke-cue-label').value.trim():'';mutate(song=>{const target=findLine(song,lineId),next={id:cueId||crypto.randomUUID(),type:cue.type,preset,label,color};const i=target.cues.findIndex(c=>c.id===cueId);if(i<0)target.cues.push(next);else target.cues[i]=next;});close();};
  if(cueId)$('.ke-delete').onclick=()=>{mutate(song=>{const target=findLine(song,lineId);target.cues=target.cues.filter(c=>c.id!==cueId);});close();};
 }
 function openPart(partId){
  const part=getSong().parts.find(p=>p.id===partId);if(!part)return;const minimum=part.lines.reduce((n,l)=>n+Math.max(1,l.chords.length),0)/2,total=partBeats(part);
  show('Настройка блока','<label class="ke-field-title">Название<input class="ke-part-name" maxlength="80" value="'+esc(part.name)+'"></label><div class="ke-part-presets"><button data-part-name="Куплет">Куплет</button><button data-part-name="Припев">Припев</button><button data-part-name="Проигрыш">Проигрыш</button></div><label class="ke-field-title">Доли всего блока</label>'+beatControl(total,Math.max(128,total*2,minimum),minimum)+'<p class="ke-small">Доли распределятся между аккордами с сохранением пропорций.</p>','<button class="ke-apply kl-primary">Сохранить блок</button>');
  const readBeats=bindBeats();$$('[data-part-name]').forEach(b=>b.onclick=()=>$('.ke-part-name').value=b.dataset.partName);
  $('.ke-apply').onclick=()=>{const name=$('.ke-part-name').value.trim()||part.name,total=readBeats();mutate(song=>{const p=song.parts.find(p=>p.id===partId);p.name=name;setPartBeats(p,total);});close();};
 }
 function openPosition(lineId,column){
  selected={lineId,column};
  show('В этом месте','<div class="ke-position-actions"><button data-add="chord"><i data-lucide="music-2" aria-hidden="true"></i>Аккорд</button><button data-add="cue"><i data-lucide="flag" aria-hidden="true"></i>Пометка для игры</button><button data-add="line"><i data-lucide="minus" aria-hidden="true"></i>Цветная линия</button><button data-add="block"><i data-lucide="list-music" aria-hidden="true"></i>Начать новый блок</button></div>','');icons();
  $$('[data-add]').forEach(b=>b.onclick=()=>{close();if(b.dataset.add==='chord')openChord(null,lineId,column);else if(b.dataset.add==='block'){show('Новый блок','<div class="ke-position-actions"><button data-split="Куплет">Куплет</button><button data-split="Припев">Припев</button><button data-split="Проигрыш">Проигрыш</button></div>','');$$('[data-split]').forEach(x=>x.onclick=()=>{mutate(song=>splitPart(song,lineId,x.dataset.split));close();});}else openCue(lineId,null,b.dataset.add==='line'?'line':'cue');});
 }
 function locate(x,y){
  const node=document.elementFromPoint(x,y),line=node?.closest('.qs-line');if(!line||!reader.contains(line))return null;
  const model=findLine(getSong(),line.dataset.lineId);if(!model)return null;
  let textNode=null,offset=0;const pos=document.caretPositionFromPoint?.(x,y);if(pos){textNode=pos.offsetNode;offset=pos.offset;}else{const range=document.caretRangeFromPoint?.(x,y);if(range){textNode=range.startContainer;offset=range.startOffset;}}
  let word=textNode?.parentElement?.closest('.qs-words');
  if(!word||!line.contains(word)){const words=[...line.querySelectorAll('.qs-words')];word=words.reduce((best,w)=>{const r=w.getBoundingClientRect(),distance=Math.abs(y-(r.top+r.height/2))+Math.max(r.left-x,0,x-r.right);return !best||distance<best.d?{w,d:distance}:best;},null)?.w;if(word){const r=word.getBoundingClientRect(),char=r.width/Math.max(1,word.textContent.length);offset=Math.round((x-r.left)/Math.max(1,char));}}
  const start=Number(word?.dataset.start)||0,column=Math.max(0,Math.min(model.text.length,start+Math.max(0,offset)));
  let rect=word?.getBoundingClientRect()||line.getBoundingClientRect(),left=rect.left;
  if(word?.firstChild){try{const range=document.createRange();range.setStart(word.firstChild,Math.min(word.textContent.length,Math.max(0,column-start)));range.collapse(true);const r=range.getBoundingClientRect();if(r.height){rect=r;left=r.left;}}catch{}}
  return {lineId:model.id,column,line,x:left,y:rect.top,height:Math.max(20,rect.height)};
 }
 function positionDrag(){
  if(!drag)return;const box=phone.getBoundingClientRect(),target=locate(drag.x,drag.y);drag.target=target;
  ghost.style.transform='translate('+Math.max(0,Math.min(box.width-70,drag.x-box.left-26))+'px,'+Math.max(0,drag.y-box.top-55)+'px)';
  $$('.ke-drop-target').forEach(el=>el.classList.remove('ke-drop-target'));
  caret.hidden=!target;ghost.classList.toggle('invalid',!target);
  if(target){target.line.classList.add('ke-drop-target');caret.style.left=(target.x-box.left)+'px';caret.style.top=(target.y-box.top-24)+'px';caret.style.height=(target.height+24)+'px';}
 }
 function autoScroll(now){
  if(!drag)return;const dt=Math.min(.04,(now-lastFrame)/1000||0);lastFrame=now;const rect=reader.getBoundingClientRect();let velocity=0;if(drag.y<rect.top+55)velocity=-Math.min(160,(rect.top+55-drag.y)*4);if(drag.y>rect.bottom-55)velocity=Math.min(160,(drag.y-(rect.bottom-55))*4);if(velocity){reader.scrollTop+=velocity*dt;positionDrag();}scrollFrame=requestAnimationFrame(autoScroll);
 }
 function take(){
  if(hold)clearTimeout(hold);hold=null;if(!pointer||drag)return;const el=pointer.element;drag={...pointer,x:pointer.x,y:pointer.y,target:null};ghost.textContent=el.textContent.trim()||'Линия';ghost.hidden=false;el.classList.add('ke-picked');phone.setPointerCapture(pointer.id);positionDrag();lastFrame=performance.now();scrollFrame=requestAnimationFrame(autoScroll);
 }
 function cancel(){if(hold)clearTimeout(hold);hold=null;cancelAnimationFrame(scrollFrame);scrollFrame=0;ghost.hidden=true;caret.hidden=true;$$('.ke-picked,.ke-drop-target').forEach(el=>el.classList.remove('ke-picked','ke-drop-target'));if(pointer&&phone.hasPointerCapture(pointer.id))phone.releasePointerCapture(pointer.id);pointer=null;drag=null;}
 phone.addEventListener('pointerdown',e=>{
  if(!editing||!overlay.hidden||e.button!==0||e.isPrimary===false)return;
  const element=e.target.closest('.qs-chord,.ke-cue,.ke-divider'),line=e.target.closest('.qs-line');if(!line)return;
  pointer={id:e.pointerId,type:e.pointerType,x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,element,lineId:line.dataset.lineId,top:reader.scrollTop,pan:false};
  if(element)hold=setTimeout(take,420);
 },true);
 phone.addEventListener('pointermove',e=>{
  if(!pointer||e.pointerId!==pointer.id)return;
  pointer.x=e.clientX;pointer.y=e.clientY;
  if(drag){e.preventDefault();drag.x=e.clientX;drag.y=e.clientY;positionDrag();return;}
  if(Math.hypot(e.clientX-pointer.startX,e.clientY-pointer.startY)>8){if(pointer.element&&pointer.type==='mouse'){e.preventDefault();take();positionDrag();return;}if(hold)clearTimeout(hold);hold=null;pointer.pan=true;if(pointer.element){e.preventDefault();reader.scrollTop=pointer.top-(e.clientY-pointer.startY);}}
 },{capture:true,passive:false});
 phone.addEventListener('pointerup',e=>{
  if(!pointer||pointer.id!==e.pointerId)return;
  if(drag){e.preventDefault();e.stopPropagation();const d=drag,target=d.target;
   if(target){if(d.element.dataset.chordId)mutate(song=>moveChord(song,d.element.dataset.chordId,target.lineId,target.column));else if(d.element.dataset.cueId)mutate(song=>{const from=findLine(song,d.lineId),to=findLine(song,target.lineId),cue=from.cues.find(c=>c.id===d.element.dataset.cueId);from.cues=from.cues.filter(c=>c.id!==cue.id);to.cues.push(cue);});}
   swallowUntil=performance.now()+450;cancel();return;
  }
  if(hold)clearTimeout(hold);hold=null;
  if(!pointer.pan&&!pointer.element){const target=locate(e.clientX,e.clientY);if(target){e.preventDefault();e.stopPropagation();swallowUntil=performance.now()+450;openPosition(target.lineId,target.column);}}
  else if(pointer.pan)swallowUntil=performance.now()+450;
  pointer=null;
 },true);
 phone.addEventListener('pointercancel',cancel,true);
 phone.addEventListener('contextmenu',e=>{if(editing&&e.target.closest('.qs-chord,.ke-cue,.ke-divider'))e.preventDefault();});
 phone.addEventListener('click',e=>{
  if(!editing||!overlay.hidden)return;
  if(performance.now()<swallowUntil){if(e.target.closest('.qs-reader')){e.preventDefault();e.stopImmediatePropagation();}return;}
  const chord=e.target.closest('[data-chord-id]'),cue=e.target.closest('[data-cue-id]');
  if(chord){e.preventDefault();e.stopPropagation();openChord(chord.dataset.chordId);}
  if(cue){e.preventDefault();e.stopPropagation();openCue(cue.closest('.qs-line').dataset.lineId,cue.dataset.cueId);}
 },true);
 document.addEventListener('keydown',e=>{
  if(!overlay.hidden){if(e.key==='Escape'){e.preventDefault();close();}if(e.key==='Tab'){const elements=[...overlay.querySelectorAll('button,input,select')].filter(e=>!e.disabled),first=elements[0],last=elements.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}return;}
  if(editing&&(e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'&&!e.target.closest('input,textarea')){e.preventDefault();if(history.canUndo)$('.ke-undo').click();}
 });
 decorate();updateBar();icons();
 return {setEditing,openPart,markSaved(){dirty=false;updateBar();},get editing(){return editing;}};
}
