import {recordingBeat,recordingTime,MAX_AUDIO_BYTES,hasRecordingMarks,recordingRhythmOrigin} from './recording-model.js';
import {linesOf,lineBeats} from './score-model.js';

export function createRecordingTransport({media,store,getSong,onRecord,onError=()=>{},makeUrl=file=>URL.createObjectURL(file),revokeUrl=url=>URL.revokeObjectURL(url),waitMetadata}={}){
 let ready=false,url=null,loading=0,playGeneration=0,priming=false,ownPause=false,previewMode=false,buffering=false;
 for(const event of ['waiting','stalled'])media.addEventListener?.(event,()=>buffering=true);
 for(const event of ['playing','seeked'])media.addEventListener?.(event,()=>buffering=false);
 const metadata=waitMetadata||(()=>new Promise((resolve,reject)=>{
  const clean=()=>{clearTimeout(timer);media.removeEventListener('loadedmetadata',done);media.removeEventListener('error',failed);};
  const done=()=>{clean();resolve(media.duration);},failed=()=>{clean();reject(Error('Телефон не смог прочитать этот аудиофайл. Попробуйте MP3, M4A или WAV.'));};
  const timer=setTimeout(failed,15000);media.addEventListener('loadedmetadata',done,{once:true});media.addEventListener('error',failed,{once:true});
 }));
 function pause(){playGeneration++;ownPause=true;media.pause();queueMicrotask(()=>ownPause=false);}
 async function source(file){
  const generation=++loading,newUrl=makeUrl(file),oldUrl=url;ready=false;pause();previewMode=false;buffering=false;url=newUrl;
  const reading=metadata();media.src=newUrl;media.load?.();let duration;
  try{duration=await reading;if(!Number.isFinite(duration)||duration<.1||duration>14400)throw Error('Выберите запись длительностью до четырёх часов.');if(generation!==loading){revokeUrl(newUrl);return null;}ready=true;if(oldUrl)revokeUrl(oldUrl);return duration;}
  catch(error){if(generation===loading){revokeUrl(newUrl);url=oldUrl;if(oldUrl){media.src=oldUrl;media.load?.();ready=true;}else media.removeAttribute?.('src');}throw error;}
 }
 async function restore(){const record=getSong().recording,generation=loading;if(!record?.localId)return false;try{const file=await store.get(record.localId);if(!file||generation!==loading)return false;const duration=await source(file);if(duration===null)return false;const lines=linesOf(getSong()),index=getSong().rehearsal.line||0,beat=lines.slice(0,index).reduce((n,l)=>n+lineBeats(l),0),time=recordingTime(getSong(),beat);if(time!==null)media.currentTime=time;return true;}catch(error){onError(error.message);return false;}}
 async function attach(file){
  if(!file||file.size===0||file.size>MAX_AUDIO_BYTES)throw Error('Выберите аудиофайл размером до 80 МБ.');
  const old=getSong().recording,duration=await source(file);if(duration===null)return false;
  if(old?.times.some(t=>t.at>=duration)||old?.chordTimes?.some(t=>t.endAt>duration)){pause();ready=false;throw Error('Эта запись короче вашей разметки. Выберите прежний файл или сначала исправьте поздние отметки.');}
  const id=old?.localId||crypto.randomUUID();try{await store.put(id,file);}catch(error){ready=false;throw error;}
  onRecord({...old,localId:id,name:file.name||'Запись',duration,referenceBpm:old?.referenceBpm||getSong().rehearsal.bpm||120,enabled:old?.enabled===true,times:old?.times||[]});return true;
 }
 function setTempo(bpm){const record=getSong().recording;if(!record?.enabled)return true;const rate=bpm/record.referenceBpm;if(!Number.isFinite(rate)||rate<.25||rate>4)return false;try{media.playbackRate=previewMode?1:rate;media.preservesPitch=true;if('webkitPreservesPitch'in media)media.webkitPreservesPitch=true;return true;}catch{return false;}}
 async function prepare(){
  if(!ready||!hasRecordingMarks(getSong().recording))return false;previewMode=false;const token=playGeneration;priming=true;const muted=media.muted,at=media.currentTime;media.muted=true;
  try{await media.play();media.pause();return token===playGeneration;}finally{media.pause();media.currentTime=at;media.muted=muted;priming=false;}
 }
 async function play(){previewMode=false;if(!ready||!setTempo(getSong().rehearsal.bpm))throw Error('Не удалось включить запись.');await media.play();}
 async function preview(){pause();previewMode=true;media.playbackRate=1;await media.play();}
 function seek(time){if(ready&&Number.isFinite(time))media.currentTime=Math.max(0,Math.min(getSong().recording.duration,time));}
 function seekBeat(beat){if(getSong().recording?.enabled)seek(recordingTime(getSong(),beat));}
 function seekLine(index){const lines=linesOf(getSong());seekBeat(lines.slice(0,index).reduce((n,l)=>n+lineBeats(l),0));}
 function destroy(){loading++;pause();ready=false;previewMode=false;media.removeAttribute?.('src');media.load?.();if(url)revokeUrl(url);url=null;}
 function rhythmClock(){const record=getSong().recording;if(!ready||!record||media.paused||media.seeking||buffering)return null;return {beat:(media.currentTime-recordingRhythmOrigin(getSong()))*record.referenceBpm/60,rate:record.referenceBpm*(media.playbackRate||1)/60};}
 return {rhythmClock,restore,attach,pause,prepare,play,preview,setTempo,seek,seekBeat,seekLine,restart(){seek(0);},beat(){return ready&&!media.paused?recordingBeat(getSong(),media.currentTime):null;},pulse(){const record=getSong().recording;return ready&&record?(media.currentTime-recordingRhythmOrigin(getSong()))*record.referenceBpm/60:null;},destroy,get ready(){return ready;},get markingReady(){return ready&&!media.paused&&!media.seeking&&!buffering;},get requested(){return getSong().recording?.enabled===true;},get ownPause(){return ownPause||priming;},get previewing(){return previewMode;}};
}
