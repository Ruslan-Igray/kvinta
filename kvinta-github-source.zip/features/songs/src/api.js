export const SERVICE_ORIGIN='https://kvinta-guitar-circle.sappy-mule-8607.chatgpt.site';
export function apiUrl(path,loc=globalThis.location){return (loc?.hostname==='ruslan-igray.github.io'?SERVICE_ORIGIN:'')+path;}
export function isKvintaSongUrl(url,loc=globalThis.location){return url.origin===loc.origin||url.origin===SERVICE_ORIGIN||url.origin==='https://ruslan-igray.github.io';}
