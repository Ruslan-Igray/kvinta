export function dragScrollVelocity(y,top,bottom,direction=0){
 const zone=Math.min(110,(bottom-top)*.3);if(zone<=0)return 0;
 if(y>bottom-zone&&direction>=0)return Math.min(430,Math.max(0,(y-(bottom-zone))/zone)*430);
 if(y<top+zone&&direction<=0)return -Math.min(430,Math.max(0,(top+zone-y)/zone)*430);return 0;
}
export function visibleEditorLine(elements,top,bottom,selectedId){
 const visible=elements.filter(e=>e.bottom>top+8&&e.top<bottom-8);if(!visible.length)return elements[0]?.id||null;
 const selected=visible.find(e=>e.id===selectedId&&e.bottom>top+40&&e.top<bottom-40);return selected?.id||visible.reduce((a,b)=>Math.abs(a.top-(top+24))<Math.abs(b.top-(top+24))?a:b).id;
}
