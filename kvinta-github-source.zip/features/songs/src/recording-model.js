import {linesOf,lineBeats} from './score-model.js';
export const MAX_AUDIO_BYTES=80*1024*1024;
export function recordingPoints(song){
 const record=song.recording,lines=linesOf(song);if(!record?.times?.length||!lines.length)return [];
 const offsets=[];let total=0;for(const line of lines){offsets.push(total);total+=lineBeats(line);}
 const points=record.times.flatMap(t=>{const i=lines.findIndex(l=>l.id===t.lineId);return i<0?[]:[{beat:offsets[i],at:t.at}];}).sort((a,b)=>a.beat-b.beat);
 if(!points.length)return [];
 const period=60/record.referenceBpm,first=points[0],last=points.at(-1);
 if(first.beat>0&&first.at>0)points.unshift({beat:0,at:Math.max(0,first.at-first.beat*period)});
 points.push({beat:total,at:Math.max(last.at+.001,last.at+(total-last.beat)*period)});
 return points;
}
export function recordingBeat(song,time){
 const points=recordingPoints(song);if(!points.length)return null;if(time<=points[0].at)return points[0].beat;
 for(let i=1;i<points.length;i++)if(time<points[i].at){const a=points[i-1],b=points[i];return a.beat+(b.beat-a.beat)*Math.max(0,Math.min(1,(time-a.at)/Math.max(.001,b.at-a.at)));}
 return points.at(-1).beat;
}
export function recordingTime(song,beat){
 const points=recordingPoints(song);if(!points.length)return null;if(beat<=points[0].beat)return points[0].at;
 for(let i=1;i<points.length;i++)if(beat<points[i].beat){const a=points[i-1],b=points[i];return a.at+(b.at-a.at)*(beat-a.beat)/Math.max(.001,b.beat-a.beat);}
 return points.at(-1).at;
}
export function markRecordingLine(song,lineId,at){
 at=Math.round(at*1000)/1000;
 const record=song.recording,lines=linesOf(song),index=lines.findIndex(l=>l.id===lineId);if(!record||index<0||!Number.isFinite(at)||at<0||at>=record.duration)throw Error('Не удалось отметить вступление строки.');
 const times=new Map(record.times.map(t=>[t.lineId,t.at]));for(let i=0;i<lines.length;i++){const time=times.get(lines[i].id);if(time===undefined||i===index)continue;if(i<index&&time>=at||i>index&&time<=at)throw Error('Вступления строк должны идти по порядку. Сначала поправьте соседнюю отметку.');}
 times.set(lineId,Math.round(at*1000)/1000);return {...record,times:lines.filter(l=>times.has(l.id)).map(l=>({lineId:l.id,at:times.get(l.id)}))};
}
export const formatAudioTime=seconds=>{const n=Math.max(0,Number(seconds)||0);return Math.floor(n/60)+':'+String(Math.floor(n%60)).padStart(2,'0');};
