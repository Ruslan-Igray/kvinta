import {createTorch,torchFailureMessage} from '../modules/metronome-torch.js';
export function createSongTorch({torchFactory=createTorch,onStatus=()=>{},onFailure=()=>{}}={}){
 let generation=0,connecting=false;
 const torch=torchFactory({onError:error=>{connecting=false;const message=torchFailureMessage(error);onStatus(message);onFailure(message);}});
 async function connect(){const token=++generation;connecting=true;onStatus('Подключаем заднюю камеру и проверяем светодиод…');try{const ok=await torch.connect();if(token!==generation)return false;connecting=false;onStatus(ok?'Вспышка подключена.':'Подключение отменено.');return ok;}catch(error){if(token!==generation)return false;connecting=false;onStatus(torchFailureMessage(error));return false;}}
 function stop(){generation++;connecting=false;torch.release();}
 async function test(){const token=generation;onStatus('Проверка: три коротких импульса…');const ok=await torch.test();if(token!==generation)return false;onStatus(ok?'Проверка завершена. Можно нажать «Старт».':'Не удалось проверить вспышку. Подключите камеру заново.');return ok;}
 return {connect,stop,test,pulse:(time,event)=>torch.pulse(time,event),get connected(){return torch.connected;},get testing(){return torch.testing;},get connecting(){return connecting;},get available(){return torch.available;}};
}
export function mountSongTorch({phone,player,notify}){
 const status=text=>{const output=phone.querySelector('.ks-camera-status');if(output)output.textContent=text;sync();};
 const control=createSongTorch({onStatus:status,onFailure:message=>notify(message)});
 function sync(){const button=phone.querySelector('.ks-camera-connect');if(!button)return;button.disabled=control.connecting||control.testing||!control.available;button.textContent=control.connecting?'Подключаем…':control.connected?'Отключить камеру':'Подключить вспышку';const test=phone.querySelector('.ks-camera-test');if(test)test.disabled=!control.connected||control.testing;}
 function open(){player.stop();player.openModal('Фотовспышка','<p>Нужен доступ к задней камере. Видео не записывается и не отправляется. При подключении будет пробный импульс.</p><div class="ks-camera-actions"><button class="ks-camera-connect" type="button">Подключить вспышку</button><button class="ks-camera-test" type="button" disabled>Проверить вспышку</button></div><p class="ks-camera-status" role="status">Поддержка проверяется пробным включением, а не только доступом к камере.</p>');sync();phone.querySelector('.ks-camera-connect').onclick=async()=>{if(control.connected){control.stop();status('Камера отключена.');return;}await control.connect();sync();};phone.querySelector('.ks-camera-test').onclick=async()=>{const pending=control.test();sync();await pending;sync();};}
 return {open,pulse:(time,event)=>{if(player.getState().torch)control.pulse(time,event);},stop:()=>{control.stop();sync();},async prepare(){if(!player.getState().torch||control.connected)return true;const ok=await control.connect();if(!ok)notify('Фотовспышка недоступна. Проверьте её подключение в настройках.');return ok;},get connected(){return control.connected;}};
}
