import {createTorch} from '../modules/metronome-torch.js';
export function createSongTorch({torchFactory=createTorch,onStatus=()=>{}}={}){
 let generation=0,connecting=false;
 const torch=torchFactory({onError:()=>{connecting=false;onStatus('Вспышка прервана. Проверьте подключение камеры.');}});
 async function connect(){const token=++generation;connecting=true;onStatus('Подключаем заднюю камеру…');try{const ok=await torch.connect();if(token!==generation)return false;connecting=false;onStatus(ok?'Вспышка подключена.':'Подключение отменено.');return ok;}catch(error){if(token!==generation)return false;connecting=false;onStatus(error?.message==='torch-unavailable'?'Браузер не разрешил фотовспышку. Можно включить мерцание экрана.':'Не удалось подключить камеру. Проверьте разрешение для Квинты.');return false;}}
 function stop(){generation++;connecting=false;torch.release();}
 return {connect,stop,pulse:time=>torch.pulse(time),get connected(){return torch.connected;},get connecting(){return connecting;},get available(){return torch.available;}};
}
export function mountSongTorch({phone,player,notify}){
 const status=text=>{const output=phone.querySelector('.ks-camera-status');if(output)output.textContent=text;sync();};
 const control=createSongTorch({onStatus:status});
 function sync(){const button=phone.querySelector('.ks-camera-connect');if(!button)return;button.disabled=control.connecting||!control.available;button.textContent=control.connecting?'Подключаем…':control.connected?'Отключить камеру':'Подключить вспышку';}
 function open(){player.stop();player.openModal('Фотовспышка','<p>Нужен доступ к задней камере. Видео не записывается и не отправляется.</p><button class="ks-camera-connect kl-primary" type="button">Подключить вспышку</button><p class="ks-camera-status" role="status">Поддержка вспышки проверяется после подключения.</p>');sync();phone.querySelector('.ks-camera-connect').onclick=async()=>{if(control.connected){control.stop();status('Камера отключена.');return;}await control.connect();sync();};}
 return {open,pulse:time=>{if(player.getState().torch)control.pulse(time);},stop:()=>{control.stop();sync();},async prepare(){if(!player.getState().torch||control.connected)return true;const ok=await control.connect();if(!ok)notify('Фотовспышка недоступна. Проверьте её подключение в настройках.');return ok;},get connected(){return control.connected;}};
}
