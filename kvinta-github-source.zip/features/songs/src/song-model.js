export {isChord} from '../worker/songs.js';
