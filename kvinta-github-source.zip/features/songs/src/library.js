import './integration.js';
import {apiUrl,isKvintaSongUrl} from './api.js';
import {parseText} from './song-model.js';
import {normalizeSong,normalizeRehearsal,linesOf,lineBeats,CUE_PRESETS,snapshot} from './score-model.js';
import {mountEditor} from './editor.js';
import {readSharedSong,showSongShare} from './sharing.js';
const get=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback;}catch{return fallback;}};
const put=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value));return true;}catch{return false;}};
const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const example={schema:1,id:'teaching',title:'Тихий вечер',artist:'Учебный пример',source:null,parts:parseText('[Куплет 1]\nAm           F\nТихий вечер гасит окна,\nC             G\nГород медленно молчит.\nAm             Fmaj7\nЯ возьму гитару с полки —\nDm             E7\nПусть знакомый строй звучит.\n[Припев]\nF           G\nМы сыграем эту песню,\nC           Am\nНе торопимся никуда.\nDm             E7\nПусть сегодня будет слышно:\nAm                  Am\nМузыка с тобою навсегда.')};
function migrate(raw){const legacyId=raw.id||raw.source?.url||'teaching',prefs=get('kvinta-song-prefs:'+legacyId,{}),old=prefs.privateContent?.screens?.bottom||prefs.modelContent?.screens?.bottom||{};return normalizeSong({...raw,rehearsal:raw.schema===2?raw.rehearsal:{...old,...raw.rehearsal}});}
function savedSongs(){const values=get('kvinta-song-saved',[]);if(!Array.isArray(values))return [];return values.flatMap(raw=>{try{return [migrate(raw)];}catch{return [];}});}
let song,wasExample=false;try{song=migrate(get('kvinta-song-current',example));}catch{song=migrate(example);wasExample=true;}
if(song.id==='teaching')wasExample=true;
let shared=false,sharedError='';const shareId=new URLSearchParams(location.hash.slice(1)).get('song');
window.addEventListener('hashchange',()=>{if(new URLSearchParams(location.hash.slice(1)).get('song')!==shareId)location.reload();});
if(shareId){try{song=await readSharedSong(shareId);song.id=crypto.randomUUID();shared=true;}catch(e){sharedError=e.message;}}
else{put('kvinta-song-current',song);const saved=savedSongs();if(saved.length)put('kvinta-song-saved',saved);}
const savedKey=()=> 'kvinta-song-prefs:'+song.id;
const noteNames=['A','B♭','B','C','C♯','D','E♭','E','F','F♯','G','G♯'],semitone={C:0,D:2,E:4,F:5,G:7,A:9,B:11,H:11};
const pitch=note=>{const m=note.match(/^([A-H])([#b♭♯]*)/);if(!m)return null;return ((semitone[m[1]]+[...m[2]].reduce((n,c)=>n+('#♯'.includes(c)?1:-1),0))%12+12)%12;};
const initialKey=Math.max(0,noteNames.findIndex(n=>pitch(n)===pitch(song.baseChord))),minor=/^[A-H][#b♯♭]*m(?!aj)/.test(song.baseChord),flat=/[b♭]/.test(song.baseChord);
function shift(symbol,delta){
 delta=((delta%12)+12)%12;if(!delta||!symbol)return symbol;
 const names=flat?['C','D♭','D','E♭','E','F','G♭','G','A♭','A','B♭','B']:['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
 return symbol.replace(/(^|\/)([A-H][#b♭♯]*)/g,(_,prefix,note)=>prefix+names[(pitch(note)+delta)%12]);
}
function transpose(symbol,key){return shift(symbol,key-initialKey);}
let scoreLines=linesOf(song);
function previewParts(){return song.parts.map(p=>({name:p.name,lines:p.lines.map(l=>l.chords.length?l.chords.map(c=>[c.symbol,l.text]):[['',l.text]])}));}
window.kvintaSongPreview={title:song.title,subtitle:(song.artist||song.source?.name||'Своя песня')+' · 4/4',initialKey,keyNames:noteNames.map(n=>n+(minor?'m':'')),parts:previewParts(),transpose,lineBeats:index=>lineBeats(scoreLines[index]),chordBeats:index=>scoreLines[index].chords.map(c=>c.beats)};
window.kvintaSongPreview.renderLine=(line,index)=>{
 const entry=scoreLines[index];line.dataset.lineId=entry.id;
 const marks=document.createElement('div');marks.className='ke-cues';
 for(const cue of entry.cues){
  const mark=document.createElement(window.kvintaEditing?'button':'span');if(window.kvintaEditing)mark.type='button';mark.dataset.cueId=cue.id;mark.dataset.color=cue.color;
  if(cue.type==='line'){mark.className='ke-divider';mark.setAttribute('aria-label','Цветная линия');line.append(mark);}
  else{mark.className='ke-cue';const preset=CUE_PRESETS.find(p=>p.id===cue.preset),icon=document.createElement('i'),label=document.createElement('span');icon.dataset.lucide=preset.icon;icon.setAttribute('aria-hidden','true');label.textContent=cue.label||preset.label;mark.append(icon,label);marks.append(mark);}
 }
 if(marks.childNodes.length)line.append(marks);
 const chords=entry.chords,end=Math.max(entry.text.length,...chords.map(c=>c.column+c.symbol.length)),text=entry.text.padEnd(end,' '),words=[...text.matchAll(/\S+\s*|\s+/g)];
 const ends=[],lanes=new Map(),rowHeight=window.kvintaEditing?44:29;for(const c of chords){let lane=ends.findIndex(end=>end<=c.column);if(lane<0)lane=ends.length;ends[lane]=c.column+c.symbol.length+1;lanes.set(c.id,lane);}
 const padding=Math.max(1,ends.length)*rowHeight;
 if(!words.length)words.push({0:' ',index:0});
 for(let i=0;i<words.length;i++){
  const word=words[i],next=words[i+1]?.index??Infinity,span=document.createElement('span');span.className='qs-fragment';span.style.paddingTop=padding+'px';
  const label=document.createElement('span');label.className='qs-words';label.dataset.start=word.index;label.textContent=word[0];span.append(label);
  for(const chord of chords.filter(c=>c.column>=word.index&&c.column<next)){
   const mark=document.createElement(window.kvintaEditing?'button':'span');if(window.kvintaEditing)mark.type='button';mark.className='qs-chord';mark.dataset.chord=chord.symbol;mark.dataset.chordId=chord.id;mark.style.left=(chord.column-word.index)+'ch';mark.style.top=(lanes.get(chord.id)*rowHeight)+'px';mark.setAttribute('aria-label','Аккорд '+chord.symbol+', '+chord.beats+' доли');span.append(mark);
  }line.append(span);
 }
 line.setAttribute('aria-label','Строка '+(index+1)+': '+entry.text);
};
const globalPrefs=get('kvinta.preferences.v1',{}),theme=['light','dark'].includes(globalPrefs.theme)?globalPrefs.theme:'auto';
function setTheme(value){const prefs=get('kvinta.preferences.v1',{});prefs.theme=value==='auto'?null:value;put('kvinta.preferences.v1',prefs);const resolved=value==='auto'?(matchMedia('(prefers-color-scheme:light)').matches?'light':'dark'):value;document.documentElement.style.colorScheme=resolved;document.querySelector('meta[name="theme-color"]').content=resolved==='light'?'#edf3f7':'#181b22';}
setTheme(theme);
const initialState={...song.rehearsal,key:song.rehearsal.key??initialKey,theme,saved:savedSongs().some(s=>s.id===song.id)};
window.openai={widgetState:{privateContent:{screens:{bottom:initialState}}},setWidgetState:async value=>{
 const prefs=value.privateContent?.screens?.bottom||value.modelContent?.screens?.bottom;
 if(prefs){song.rehearsal=normalizeRehearsal(prefs);if(!shared&&!put('kvinta-song-current',song))notify('Не хватает памяти для черновика.');}
 put(savedKey(),value);
}};
await import('./song.js');
const phone=document.querySelector('.qs-phone'),library=document.createElement('section');library.className='kl-library';library.setAttribute('aria-label','Песни');library.hidden=true;phone.append(library);
phone.querySelector('.qs-appearance').setAttribute('aria-label','Общие настройки');
library.innerHTML=`<div class="kl-heading"><div><h2>Песни</h2><small>Текст, аккорды и ваши версии</small></div><button class="qs-icon kl-close" aria-label="Вернуться к песне"><i data-lucide="x" aria-hidden="true"></i></button></div>
<div class="kl-tabs" role="group" aria-label="Открыть песню"><button data-tab="search" aria-pressed="true">Поиск</button><button data-tab="link" aria-pressed="false">Ссылка</button><button data-tab="saved" aria-pressed="false">Мои песни</button></div>
<div class="kl-scroll"><section data-panel="search"><form class="kl-search-form"><label for="kl-query">Песня или исполнитель</label><div class="kl-input-row"><input id="kl-query" name="q" type="search" maxlength="100" placeholder="Например: Во поле береза" required minlength="2"><button class="kl-primary" type="submit">Найти</button></div></form><div class="kl-search-source"><span>Поиск по AmDm</span><a class="kl-mytabs" href="https://mytabs.ru/" target="_blank" rel="noopener noreferrer">Искать на MyTabs ↗</a></div><div class="kl-results"></div></section>
<section data-panel="link" hidden><form class="kl-import-form"><label for="kl-url">Ссылка на песню</label><input id="kl-url" name="url" type="url" placeholder="https://…" required><p>AmDm, MyTabs или сохранённая версия из Квинты.</p><button class="kl-primary" type="submit">Открыть в Квинте</button></form><button class="kl-text-mode">Вставить свой текст с аккордами</button><form class="kl-text-form" hidden><label for="kl-title">Название</label><input id="kl-title" maxlength="180" required placeholder="Моя песня"><label for="kl-text">Текст с аккордами</label><textarea id="kl-text" rows="8" maxlength="100000" required placeholder="[Куплет 1]&#10;Am       F&#10;Текст песни…"></textarea><button class="kl-primary" type="submit">Открыть текст</button></form></section>
<section data-panel="saved" hidden><div class="kl-saved"></div></section><p class="kl-status" role="status" aria-live="polite"></p></div>`;
const $=s=>library.querySelector(s);let notifyTimer;
function notify(text){const status=phone.querySelector('.qs-status');status.textContent=text;let toast=phone.querySelector('.ke-toast');if(!toast){toast=document.createElement('div');toast.className='ke-toast';toast.setAttribute('role','status');phone.append(toast);}toast.textContent=text;toast.hidden=false;clearTimeout(notifyTimer);notifyTimer=setTimeout(()=>toast.hidden=true,2400);}
function status(text){$('.kl-status').textContent=text;}
function openLibrary(tab='search'){window.kvintaPlayer.stop();library.hidden=false;setTab(tab);$('.kl-close').focus();}
function closeLibrary(){library.hidden=true;document.querySelector('.qs-about').focus();}
function setTab(tab){library.querySelectorAll('[data-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.tab===tab)));library.querySelectorAll('[data-panel]').forEach(p=>p.hidden=p.dataset.panel!==tab);status('');if(tab==='saved')renderSaved();}
$('.kl-close').onclick=closeLibrary;library.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>setTab(b.dataset.tab));
window.addEventListener('kvinta:library',e=>openLibrary(e.detail?.saved?'saved':'search'));
window.addEventListener('kvinta:theme',e=>setTheme(e.detail));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!library.hidden)closeLibrary();});
let busy=false;
async function request(url,message){
 if(busy)return null;busy=true;status(message);library.querySelectorAll('button[type=submit]').forEach(b=>b.disabled=true);library.setAttribute('aria-busy','true');
 try{const r=await fetch(apiUrl(url),{signal:AbortSignal.timeout(45000)}),data=await r.json();if(!r.ok)throw Error(data.error||'Источник не ответил.');status('');return data;}
 catch(e){status(e.name==='TimeoutError'?'Загрузка затянулась. Попробуйте ещё раз или вставьте текст.':e.message);return null;}
 finally{busy=false;library.querySelectorAll('button[type=submit]').forEach(b=>b.disabled=false);library.removeAttribute('aria-busy');}
}
function loadSong(next){try{next=normalizeSong(next);}catch(e){status(e.message);return;}if(!put('kvinta-song-current',next)){status('Не хватает памяти браузера для песни.');return;}if(location.hash)history.replaceState(null,'',location.pathname);location.reload();}
async function importUrl(value){
 let u;try{u=new URL(value);}catch{status('Вставьте полную ссылку.');return;}
 const sharedId=new URLSearchParams(u.hash.slice(1)).get('song');
 if(sharedId&&isKvintaSongUrl(u)){try{const next=await readSharedSong(sharedId);next.id=crypto.randomUUID();loadSong(next);}catch(e){status(e.message);}return;}
 const data=await request('/api/songs/import?url='+encodeURIComponent(value),'Открываю текст и аккорды…');if(data?.song)loadSong(data.song);
}
$('.kl-search-form').onsubmit=async e=>{
 e.preventDefault();const query=$('#kl-query').value.trim();$('.kl-mytabs').href='https://mytabs.ru/searchsite?text='+encodeURIComponent(query)+'&searchid=2308090&web=0';
 const data=await request('/api/songs/search?q='+encodeURIComponent(query),'Ищу на AmDm…');if(!data)return;const results=$('.kl-results');results.replaceChildren();
 if(!data.results.length){status('Ничего не найдено. Попробуйте другое название или вставьте ссылку.');return;}
 for(const row of data.results){const card=document.createElement('article');card.className='kl-result';card.innerHTML='<div><h3>'+esc(row.title)+'</h3><p>'+esc(row.artist)+'</p><a target="_blank" rel="noopener noreferrer">На сайте ↗</a></div><button type="button">Открыть</button>';card.querySelector('a').href=row.url;card.querySelector('button').onclick=()=>importUrl(row.url);results.append(card);}status('Найдено: '+data.results.length);
};
$('.kl-import-form').onsubmit=e=>{e.preventDefault();void importUrl($('#kl-url').value.trim());};
$('.kl-text-mode').onclick=()=>$('.kl-text-form').hidden=!$('.kl-text-form').hidden;
$('.kl-text-form').onsubmit=e=>{e.preventDefault();try{loadSong({schema:1,title:$('#kl-title').value.trim(),artist:'Свой текст',parts:parseText($('#kl-text').value),source:null});}catch(error){status(error.message);}};
function renderSaved(){
 const box=$('.kl-saved'),items=savedSongs();box.replaceChildren();
 if(!items.length){box.textContent='Откройте песню и нажмите «Сохранить». Ваша расстановка, доли и пометки останутся на этом устройстве.';return;}
 for(const item of items){const row=document.createElement('article');row.className='kl-result';row.innerHTML='<div><h3>'+esc(item.title)+'</h3><p>'+esc(item.artist||'')+'</p></div><button type="button">Открыть</button>';row.querySelector('button').onclick=()=>loadSong(item);box.append(row);}
}
function getPrefs(){return window.kvintaPlayer.getState();}
function saveSong(){
 const next=snapshot(song,getPrefs()),items=savedSongs().filter(s=>s.id!==song.id);items.unshift(next);
 if(!put('kvinta-song-saved',items.slice(0,50))||!put('kvinta-song-current',next)){notify('Не хватает памяти браузера для сохранения.');return false;}
 song=next;shared=false;if(location.hash)history.replaceState(null,'',location.pathname);phone.querySelector('.ke-shared-banner')?.remove();window.kvintaPlayer.change({saved:true});editor?.markSaved();notify('Композиция сохранена');return true;
}
function applySong(next){
 song=normalizeSong({...next,rehearsal:getPrefs()});shared=false;scoreLines=linesOf(song);window.kvintaSongPreview.parts=previewParts();window.kvintaSongPreview.title=song.title;
 put('kvinta-song-current',song);window.kvintaPlayer.refresh();
}
let editor;
editor=mountEditor({phone,getSong:()=>song,onChange:applySong,onSave:saveSong,onShare:()=>showSongShare({getSong:()=>song,getPrefs,save:saveSong,privateTrial:false}),toDisplay:s=>transpose(s,getPrefs().key),toStored:s=>shift(s,initialKey-getPrefs().key)});
// The star saves the complete current version; editing never toggles it off accidentally.
const star=phone.querySelector('.qs-save');star.replaceWith(star.cloneNode(true));phone.querySelector('.qs-save').onclick=saveSong;
phone.querySelector('.qs-nav').innerHTML='<button class="qs-library-button" type="button">Песни</button><button class="qs-saved-button" type="button">Сохранённые</button>';
phone.querySelector('.qs-library-button').onclick=()=>openLibrary();phone.querySelector('.qs-saved-button').onclick=()=>openLibrary('saved');
const sourceLink=document.createElement('a');sourceLink.className='kl-source-link';if(song.source){sourceLink.href=song.source.url;sourceLink.target='_blank';sourceLink.rel='noopener noreferrer';sourceLink.textContent=song.source.name+' ↗';phone.querySelector('.qs-title-block').append(sourceLink);}
phone.querySelector('.qs-help').addEventListener('click',()=>{const content=phone.querySelector('.qs-modal-content'),p=document.createElement('p');p.textContent='В редакторе удерживайте аккорд и переносите на текст. Короткое нажатие открывает замену, доли и удаление. Нажмите на текст, чтобы добавить аккорд, сценическую пометку или новый блок. Заголовок блока открывает его общие доли. Перед обменом нажмите «Сохранить». Темп, размер 4/4 и исходный ориентир тональности требуют вашей проверки.';content.append(p);});
phone.querySelector('.qs-appearance').addEventListener('click',()=>{const button=document.createElement('button');button.type='button';button.className='ke-help-link';button.textContent='Как репетировать и редактировать';button.onclick=()=>phone.querySelector('.qs-help').click();phone.querySelector('.qs-modal-content').append(button);const install=document.createElement('button');install.type='button';install.className='ke-help-link';install.textContent='Добавить на экран телефона';install.onclick=()=>{window.kvintaPlayer.closeModal();window.dispatchEvent(new Event('kvinta:install'));};phone.querySelector('.qs-modal-content').append(install);});
if(shared){const banner=document.createElement('div');banner.className='ke-shared-banner';banner.innerHTML='<span>Версия по ссылке</span><button>Сохранить себе</button>';banner.querySelector('button').onclick=saveSong;phone.querySelector('.qs-song-heading').after(banner);}
if(globalThis.lucide)lucide.createIcons();
if(wasExample&&!shared)openLibrary();if(sharedError){openLibrary('link');status(sharedError);}
