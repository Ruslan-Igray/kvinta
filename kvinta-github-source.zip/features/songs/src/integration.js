import {analytics} from '../modules/analytics.js';
import {createInstallGuide} from '../modules/install-guide.js';
import {setupPortrait} from '../modules/portrait.js';
import {setupSwitchGestures} from '../modules/switch-gestures.js';
const install=createInstallGuide();analytics.start();setupPortrait();setupSwitchGestures();
window.addEventListener('kvinta:install',()=>install.show());
setTimeout(()=>install.show({automatic:true}),1800);
let reloading=false;
if('serviceWorker' in navigator){navigator.serviceWorker.addEventListener('controllerchange',()=>{if(reloading)return;reloading=true;window.dispatchEvent(new Event('kvinta:stop'));location.reload();});navigator.serviceWorker.register('../sw.js',{scope:'../',updateViaCache:'none'}).then(r=>r.update()).catch(()=>{});}
