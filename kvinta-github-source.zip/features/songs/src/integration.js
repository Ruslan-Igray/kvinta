import {analytics} from '../modules/analytics.js';
import {createInstallGuide} from '../modules/install-guide.js';
import {createReleaseNotice} from '../modules/release-notice.js';
import {setupPortrait} from '../modules/portrait.js';
import {setupSwitchGestures} from '../modules/switch-gestures.js';
const install=createInstallGuide(),releaseNotice=createReleaseNotice();analytics.start();setupPortrait();setupSwitchGestures();
window.addEventListener('kvinta:install',()=>install.show());
let startupChecked=false;
function finishStartup(){if(startupChecked)return;startupChecked=true;if(install.startupDecision()==='tips')releaseNotice.startup();else install.show({automatic:true});}
setTimeout(finishStartup,1800);
let reloading=false;
if('serviceWorker' in navigator){navigator.serviceWorker.addEventListener('controllerchange',()=>{if(reloading)return;reloading=true;window.dispatchEvent(new Event('kvinta-before-update'));window.dispatchEvent(new Event('kvinta:stop'));location.reload();});navigator.serviceWorker.register('../sw.js',{scope:'../',updateViaCache:'none'}).then(r=>r.update()).catch(()=>{}).finally(finishStartup);}else finishStartup();
