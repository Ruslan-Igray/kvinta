import {startLiveUpdates} from '../modules/live-updates.js';
import {analytics} from '../modules/analytics.js';
import {createInstallGuide} from '../modules/install-guide.js';
import {createReleaseNotice} from '../modules/release-notice.js';
import {setupPortrait} from '../modules/portrait.js';
import {setupSwitchGestures} from '../modules/switch-gestures.js';
const install=createInstallGuide(),releaseNotice=createReleaseNotice();analytics.start();setupPortrait();setupSwitchGestures();
window.addEventListener('kvinta:install',()=>install.show());
let startupChecked=false;
function finishStartup(){if(startupChecked)return;startupChecked=true;if(install.startupDecision()==='tips')releaseNotice.startup();else install.show({automatic:true});}
setTimeout(finishStartup,1800);
document.documentElement.dataset.kvintaReady='false';
const updates=startLiveUpdates({scriptUrl:'../sw.js',scope:'../'});updates.ready.finally(finishStartup);
