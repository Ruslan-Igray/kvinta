export const durationValue=value=>Math.max(.5,Math.min(8192,Math.round((Number(value)||.5)*2)/2));
// One value: drag vertically, use a wheel or arrows, or tap and type.
export function mountDurationControl(mount,value,{min=.5,max=8192,label='Длительность аккорда, доли',onChange=()=>{}}={}){
 const doc=mount.ownerDocument,win=doc.defaultView;const bounded=value=>Math.max(min,Math.min(max,Math.round((Number(value)||min)*2)/2));let current=bounded(value),pointer=null,suppress=0;
 mount.className='ke-duration';mount.innerHTML='<button type="button" class="ke-duration-less" aria-label="Уменьшить доли">−</button><input class="ke-duration-value" inputmode="decimal" aria-label="'+label+'" readonly><button type="button" class="ke-duration-more" aria-label="Увеличить доли">+</button>';
 const input=mount.querySelector('input');
 function paint(){input.value=String(current).replace('.',',');}
 function set(value){current=bounded(value);paint();onChange(current);}
 function finishInput(){set(Number(input.value.replace(',','.'))||current);input.readOnly=true;}
 mount.querySelector('.ke-duration-less').onclick=()=>set(current-.5);mount.querySelector('.ke-duration-more').onclick=()=>set(current+.5);
 input.addEventListener('pointerdown',e=>{if(!input.readOnly||e.button!==0)return;e.preventDefault();pointer={id:e.pointerId,y:e.clientY,value:current,moved:false};input.setPointerCapture(e.pointerId);});
 input.addEventListener('pointermove',e=>{if(!pointer||pointer.id!==e.pointerId)return;const delta=pointer.y-e.clientY;if(Math.abs(delta)>6)pointer.moved=true;if(pointer.moved){e.preventDefault();set(pointer.value+Math.round(delta/12)*.5);}});
 input.addEventListener('pointerup',e=>{if(!pointer||pointer.id!==e.pointerId)return;const moved=pointer.moved;pointer=null;suppress=Date.now()+300;e.preventDefault();if(!moved){input.readOnly=false;input.focus({preventScroll:true});input.select();}});
 input.addEventListener('pointercancel',()=>pointer=null);
 input.addEventListener('click',e=>{if(Date.now()<suppress)return;if(e.detail===0){input.readOnly=false;input.focus();input.select();}});
 input.addEventListener('blur',finishInput);
 input.addEventListener('keydown',e=>{if(e.key==='Enter'){finishInput();input.blur();}else if(input.readOnly&&['ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();set(current+(e.key==='ArrowUp'?.5:-.5));}});
 mount.addEventListener('wheel',e=>{e.preventDefault();set(current+(e.deltaY>0?.5:-.5));},{passive:false});paint();
 return {read(){if(!input.readOnly)finishInput();return current;},destroy(){pointer=null;}};
}
