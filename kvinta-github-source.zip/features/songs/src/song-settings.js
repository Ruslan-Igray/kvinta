export const SETTINGS_KEY='kvinta-song-settings.v1',EDITOR_KEY='kvinta-song-editor.v1';
export const QUICK_OPTIONS=[
 {id:'clicks',label:'Метроном',icon:'metronome'},
 {id:'countIn',label:'Отсчёт палочками',icon:'drum'},
 {id:'screenBlink',label:'Мерцание экрана',icon:'sun'},
 {id:'torch',label:'Фотовспышка',icon:'flashlight'},
 {id:'highlightLines',label:'Подсветка строки',icon:'text-cursor'},
 {id:'highlightChords',label:'Подсветка аккорда',icon:'music-2'},
 {id:'fullStart',label:'Полный экран при старте',icon:'maximize'}
];
const keys=['mode','speed','fontSize',...QUICK_OPTIONS.map(x=>x.id)];
export function sharedSongSettings(value={}){
 const out={};for(const key of keys){const v=value[key];if(QUICK_OPTIONS.some(o=>o.id===key)){if(typeof v==='boolean')out[key]=v;}else if(key==='mode'&&['uniform','tempo'].includes(v))out[key]=v;else if(key==='speed'&&Number.isFinite(v)&&v>=.5&&v<=2)out[key]=v;else if(key==='fontSize'&&Number.isFinite(v)&&v>=18&&v<=28)out[key]=v;}
 return out;
}
export function quickActions(value){return [...new Set(Array.isArray(value)?value:['clicks','countIn','screenBlink'])].filter(id=>QUICK_OPTIONS.some(o=>o.id===id)).slice(0,5);}
export function mergeSongSettings(song,common){return {...song,...sharedSongSettings(common)};}
export function editorDefaults(value={}){return {symbol:typeof value.symbol==='string'&&/^[A-H][#b♯♭]*(?:m|7|maj7|m7|sus2|sus4|5|dim|aug|add9|9|m7b5)?$/.test(value.symbol)?value.symbol:'Am',beats:Number.isFinite(value.beats)&&value.beats>=.5&&value.beats<=8192?Math.round(value.beats*2)/2:4,color:['amber','teal','blue','purple','rose','red'].includes(value.color)?value.color:undefined,preset:typeof value.preset==='string'?value.preset:'pedal-on',cueColor:['amber','teal','blue','purple','rose','red'].includes(value.cueColor)?value.cueColor:'amber'};}
