import {createChordTimingSession} from './chord-timing.js';
import {editSafety} from '../modules/edit-safety.js';

export function mountChordTiming({parent,media,transport,getSong,onApply,onConfirmTempo,notify}){
 const doc=parent.ownerDocument,box=doc.createElement('section');box.className='ka-chord-timing';
 box.setAttribute('aria-label','Смена аккордов по тапам');
 box.innerHTML='<h3>Смена аккордов по тапам</h3><p class="ka-chord-help">Включите запись. Нажмите на первом аккорде, затем — при каждой смене.</p><div class="ka-chord-tempo"><span></span><button type="button">Темп верный</button></div><label class="ka-chord-start">Начать с аккорда<select aria-label="Первый аккорд для разметки"></select></label><button type="button" class="ka-chord-tap"><span class="ka-chord-tap-label"></span><strong></strong><span class="ka-chord-next"></span></button><p class="ka-chord-message" role="status"></p><div class="ka-chord-actions"><button type="button" class="ka-chord-undo">Отменить тап</button><button type="button" class="ka-chord-finish">Конец фрагмента</button></div><div class="ka-chord-result"><span></span><button type="button" class="ka-chord-apply">Применить</button></div><button type="button" class="ka-chord-reset">Сбросить отметки</button>';
 parent.append(box);const $=s=>box.querySelector(s),safety=editSafety,session=createChordTimingSession({getSong,getTime:()=>media.currentTime,isPlaying:()=>transport.markingReady,getRate:()=>media.playbackRate});let listKey='',notice='',previewKey='',previewValue='';
 const text=beats=>String(beats).replace('.',',');
 function paint(){
  const state=session.state(),record=getSong().recording,keys=state.chords.map(c=>c.id).join('|');
  safety.set('chord-timing',state.dirty);
  if(keys!==listKey){listKey=keys;const select=$('select');select.replaceChildren();state.chords.forEach((c,i)=>{const option=doc.createElement('option');option.value=i;option.textContent=(i+1)+'. '+c.symbol+' · '+c.part;select.append(option);});}
  $('select').value=state.start;$('select').disabled=state.dirty||!state.chords.length;
  $('.ka-chord-tempo span').textContent=(record?.referenceBpm||120)+' BPM'+(record?.tempoVerified?' · подтверждён':' · проверьте темп');
  $('.ka-chord-tempo button').hidden=!!record?.tempoVerified;
  $('.ka-chord-tempo').hidden=!!record?.tempoVerified;
  $('.ka-chord-tap').disabled=!state.canTap;
  const first=state.chords[state.start],target=state.boundaries.length?state.next:first;
  $('.ka-chord-tap-label').textContent=state.finished?'Фрагмент размечен':!record?.tempoVerified?'Сначала подтвердите темп':!state.boundaries.length?'Первый аккорд':target?'Следующий аккорд':'Последний аккорд';
  $('.ka-chord-tap strong').textContent=state.finished?'Готово':target?.symbol||state.current?.symbol||'Нет аккордов';
  $('.ka-chord-next').textContent=state.finished?'Примените результат':!state.chords.length?'Добавьте аккорды в редакторе':!record?.tempoVerified?'Можно настучать его выше':!transport.markingReady?'Нажмите «Слушать»':!target&&state.boundaries.length?'Тап в конце его звучания':state.current?'Сейчас: '+state.current.symbol+' · нажмите при смене':'Нажмите в момент вступления';
  $('.ka-chord-undo').disabled=!state.canUndo;$('.ka-chord-finish').disabled=!state.canTap||!state.boundaries.length;
  $('.ka-chord-apply').disabled=!state.canApply;$('.ka-chord-reset').hidden=!state.dirty;
  let preview='Пока без отметок',valid=state.canApply;if(state.count){try{const key=JSON.stringify([getSong().id,record.referenceBpm,state.start,state.boundaries]);if(key!==previewKey){const result=session.result();previewValue=result.durations.map(d=>d.symbol+' ≈ '+text(d.beats)).slice(-3).join(' · ')+' доли';previewKey=key;}preview=previewValue;}catch(error){preview=error.message;valid=false;}}
  $('.ka-chord-apply').disabled=!valid;
  $('.ka-chord-result span').textContent=preview;
  $('.ka-chord-message').textContent=state.message||notice||(state.finished?'Точные моменты смен и рассчитанные доли готовы к сохранению.':state.count?'Завершено аккордов: '+state.count+'. Последний завершите кнопкой «Конец фрагмента».':'Первый тап — начало, следующий — смена. В конце нажмите «Конец фрагмента».');
 }
 const run=action=>{notice='';try{action();}catch(error){notice=error.message;}paint();};
 $('.ka-chord-tempo button').onclick=()=>run(onConfirmTempo);
 $('select').onchange=event=>run(()=>session.reset(Number(event.target.value)));
 const tap=()=>run(()=>{const state=session.tap();if(state.finished)transport.pause();});
 $('.ka-chord-tap').addEventListener('pointerdown',event=>{if(event.button!==0||event.isPrimary===false)return;event.preventDefault();tap();});
 $('.ka-chord-tap').onclick=event=>{if(event.detail===0)tap();};
 $('.ka-chord-finish').onclick=()=>run(()=>{const state=session.finish();if(state.finished)transport.pause();});
 $('.ka-chord-undo').onclick=()=>run(()=>session.undo());
 $('.ka-chord-reset').onclick=()=>run(()=>{transport.pause();session.reset(session.state().start);});
 $('.ka-chord-apply').onclick=()=>run(()=>{
  transport.pause();const result=session.result(),stored=onApply(result.song);session.reset();safety.set('chord-timing',false);
  notice=stored===false?'Не удалось записать черновик. Разметка остаётся открытой; освободите память и сохраните песню.':'Сохранено в черновик: '+result.durations.length+' аккордов. Нажмите «Сохранить песню», чтобы обновить «Мои песни».';
  notify(stored===false?'Разметка пока только в памяти. Обновление отложено.':'Доли рассчитаны. Разметка сохранена в черновике.');
 });
 return {paint,get dirty(){return session.state().dirty;}};
}
