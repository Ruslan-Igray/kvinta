import {canPlaceChord} from './score-model.js';
export function chordWordPositions(line,column,symbol,excludeId=null){return wordPositions(line.text,column).map(word=>({...word,occupied:!canPlaceChord(line,word.column,symbol,excludeId)}));}
export function wordPositions(text,column=0){
 const words=[...text.matchAll(/\S+/g)].map(m=>({column:m.index,label:m[0]}));
 if(!words.length)return [{column:0,label:'Начало строки'}];
 if(!words.some(w=>w.column===column))words.push({column,label:column>=text.length?'После текста':'Текущее место'});
 return words.sort((a,b)=>a.column-b.column);
}
export const COMMON_BEATS=[.5,1,2,3,4,6,8,12,16];
export function recentSearches(previous,query){
 query=String(query).trim().replace(/\s+/g,' ').slice(0,100);
 const values=Array.isArray(previous)?previous.filter(x=>typeof x==='string'):[];
 return (query?[query,...values.filter(x=>x.toLocaleLowerCase('ru')!==query.toLocaleLowerCase('ru'))]:values).slice(0,10);
}
