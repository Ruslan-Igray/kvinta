// Four quarter notes at the composition tempo; no song position advances here.
export function createCountIn({setTimer=setTimeout,clearTimer=clearTimeout}={}){
 let generation=0,timers=[],sources=[];
 function cancel(){generation++;timers.forEach(clearTimer);timers=[];for(const source of sources)try{source?.stop();source?.disconnect();}catch{}sources=[];}
 function start({bpm,onBeat,onDone,context,onSchedule,onScheduleEnd,outputTime=()=>context.currentTime,onInterrupted=()=>{}}){
  cancel();const token=generation,period=60000/Math.max(40,Math.min(220,bpm));
  if(context?.state==='running'&&onSchedule){
   const at=context.currentTime+.06,end=at+4*period/1000;let shown=-1;
   for(let i=0;i<4;i++)sources.push(onSchedule(at+i*period/1000));onScheduleEnd?.(end);
   const paint=()=>{if(token!==generation)return;if(context.state!=='running'){cancel();onInterrupted();return;}const time=outputTime(),beat=Math.floor((time-at)/(period/1000)+1e-7);if(beat>=0&&beat<4&&beat!==shown){shown=beat;onBeat(beat+1);}if(time>=end){timers=[];sources=[];onDone();}else timers.push(setTimer(paint,8));};paint();return;
  }
  for(let i=0;i<4;i++)timers.push(setTimer(()=>{if(token===generation)onBeat(i+1);},i*period));
  timers.push(setTimer(()=>{if(token===generation){timers=[];onDone();}},period*4));
 }
 return {start,cancel};
}
