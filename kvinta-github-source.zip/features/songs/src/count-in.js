// Four quarter notes at the composition tempo; no song position advances here.
export function createCountIn({setTimer=setTimeout,clearTimer=clearTimeout}={}){
 let generation=0,timers=[];
 function cancel(){generation++;timers.forEach(clearTimer);timers=[];}
 function start({bpm,onBeat,onDone}){
  cancel();const token=generation,period=60000/Math.max(40,Math.min(220,bpm));
  for(let i=0;i<4;i++)timers.push(setTimer(()=>{if(token===generation)onBeat(i+1);},i*period));
  timers.push(setTimer(()=>{if(token===generation){timers=[];onDone();}},period*4));
 }
 return {start,cancel};
}
