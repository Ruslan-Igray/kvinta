import {audibleAudioTime} from '../modules/audio-clock.js';

// Audio is scheduled by a short look-ahead timer. Animation only consumes the
// same events when they reach the device output; it never starts a click.
export function createSongSync({getSettings,makeBuffer,onInterrupted=()=>{},setTimer=setInterval,clearTimer=clearInterval,now=()=>performance.now()}={}){
 let context=null,active=false,timer=null,external=null,segments=[],queue=[],next=0,options=null,stopped=0;
 const nodes=new Set();
 const settings=()=>{const s=getSettings();return {bpm:s.bpm,meter:s.meter,clicks:!!s.clicks,sound:s.sound||''};};
 function internal(time){let s=segments[0];for(const item of segments)if(item.time<=time)s=item;return s?s.beat+(time-s.time)*s.bpm/60:stopped;}
 function sample(){if(external){const value=external();return value&&Number.isFinite(value.beat)&&Number.isFinite(value.rate)&&value.rate>0?{...value,time:audibleAudioTime(context,now)}:null;}return {beat:internal(context.currentTime),rate:options.bpm/60,time:context.currentTime};}
 function position(){if(!active)return stopped;if(external)return external()?.beat??stopped;return Math.max(segments[0].beat,internal(audibleAudioTime(context,now)));}
 function cancelFuture(all=false){for(const item of [...nodes])if(all||item.time>context.currentTime){try{item.source.stop();item.source.disconnect();}catch{}nodes.delete(item);}queue=all?[]:queue.filter(e=>e.time<=context.currentTime);}
 function stop(){if(active)stopped=position();active=false;if(timer!==null)clearTimer(timer);timer=null;cancelFuture(true);}
 function refresh(){
  if(!active)return;const value=settings();if(JSON.stringify(value)===JSON.stringify(options))return;
  if(value.bpm!==options.bpm&&!external&&context.currentTime<segments[0].time){segments[0].bpm=value.bpm;}else if(value.bpm!==options.bpm&&!external){const beat=internal(context.currentTime);segments.push({time:context.currentTime,beat,bpm:value.bpm});if(segments.length>32)segments.splice(0,segments.length-32);}
  options=value;cancelFuture();const at=sample();if(at)next=Math.ceil(at.beat+Math.max(0,context.currentTime-at.time)*at.rate-1e-7);
 }
 function pump(){
  if(!active)return;if(context.state!=='running'){stop();onInterrupted();return;}refresh();
  const at=sample();if(!at){cancelFuture();next=null;return;}
  const current=context.currentTime;
  // Skip beats whose audio deadline has already passed instead of replaying a burst.
  next=Math.max(next??-Infinity,Math.ceil(at.beat+(current-at.time-.015)*at.rate-1e-7));
  for(let guard=0;guard<16;guard++){
   const time=at.time+(next-at.beat)/at.rate;if(time>current+.12)break;
   const ordinal=next++||0;if(time<current-.015)continue;
   const event={ordinal,time:Math.max(current+.002,time),bpm:options.bpm,meter:options.meter};
   if(options.clicks){try{const source=context.createBufferSource();source.buffer=makeBuffer(context,event);source.connect(context.destination);const item={source,time:event.time};nodes.add(item);source.onended=()=>{nodes.delete(item);source.disconnect();};source.start(event.time);}catch{stop();onInterrupted();return;}}
   queue.push(event);
  }
 }
 function start({context:ctx,position:beat=0,external:clock=null,when=ctx?.currentTime+.06}={}){
  stop();if(!ctx||ctx.state!=='running')return false;
  context=ctx;options=settings();external=clock;segments=[{time:when,beat,bpm:options.bpm}];stopped=beat;next=Math.ceil(beat-1e-7);active=true;pump();if(!active)return false;timer=setTimer(pump,25);return true;
 }
 function drain(){
  if(!active)return [];const audible=audibleAudioTime(context,now),due=[];
  while(queue.length&&queue[0].time<=audible){const event=queue.shift();if(audible-event.time<=.12)due.push({...event,performanceTime:now()-(audible-event.time)*1000});}
  return due;
 }
 return {start,stop,refresh,pump,position,drain,get running(){return active;}};
}
