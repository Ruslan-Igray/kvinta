import {diagram} from '../modules/chord-diagram.js';
import {TYPES,chordNotes,voicingsFor} from '../modules/guitar.js';
export function chordSpec(symbol){
 const match=String(symbol).replaceAll('♯','#').replaceAll('♭','b').match(/^([A-H][#b]*)(.*)$/);if(!match)return null;
 const type=({'':'major',m:'minor','°':'dim'})[match[2]]||match[2];return TYPES.some(t=>t.id===type)?{root:match[1].replace('H','B'),type}:null;
}
export function showChordDiagram(overlay,parent,symbol){
 const doc=overlay.ownerDocument,layer=doc.createElement('section');layer.className='ke-chord-viewer';layer.setAttribute('role','dialog');layer.setAttribute('aria-modal','true');layer.setAttribute('aria-label','Аккорд на грифе');
 layer.innerHTML='<header><h2></h2><button type="button" class="ke-viewer-back">Назад</button></header><div class="ke-viewer-neck"></div><div class="ke-viewer-positions"><button type="button" aria-label="Предыдущая аппликатура">‹</button><span></span><button type="button" aria-label="Следующая аппликатура">›</button></div><p class="ke-viewer-legend">× — не играть · ○ — открытая струна<br>Цифры — пальцы. Основной тон выделен.</p>';
 layer.querySelector('h2').textContent=symbol;overlay.append(layer);parent.hidden=true;
 const spec=chordSpec(symbol),positions=spec?voicingsFor(spec.root,spec.type):[];let index=0;
 if(spec){const link=doc.createElement('a');link.className='ke-viewer-tools';link.textContent='Открыть в инструментах';link.href='../?'+new URLSearchParams({from:'song','chord-root':spec.root,'chord-type':spec.type});layer.append(link);}
 function render(){const neck=layer.querySelector('.ke-viewer-neck');if(!positions.length){neck.textContent='Для этого аккорда пока нет проверенной аппликатуры в справочнике.';layer.querySelector('.ke-viewer-positions').hidden=true;layer.querySelector('.ke-viewer-legend').hidden=true;return;}neck.innerHTML=diagram(positions[index],spec.root,chordNotes(spec.root,spec.type),n=>n.replaceAll('#','♯').replaceAll('b','♭'),'horizontal');const [prev,next]=layer.querySelectorAll('.ke-viewer-positions button');prev.disabled=index===0;next.disabled=index===positions.length-1;layer.querySelector('.ke-viewer-positions span').textContent=(index+1)+' / '+positions.length;}
 function close(){parent.hidden=false;layer.remove();parent.querySelector('.ke-chord-view')?.focus({preventScroll:true});}
 layer.querySelector('.ke-viewer-back').onclick=close;const buttons=layer.querySelectorAll('.ke-viewer-positions button');buttons[0].onclick=()=>{index--;render();};buttons[1].onclick=()=>{index++;render();};
 layer.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close();}});render();layer.querySelector('.ke-viewer-back').focus();
}
