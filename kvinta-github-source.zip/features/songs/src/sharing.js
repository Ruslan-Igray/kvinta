import {apiUrl} from './api.js';
import {normalizeSong,snapshot} from './score-model.js';
export async function readSharedSong(id){
 if(!/^[a-zA-Z0-9_-]{22}$/.test(id))throw Error('Некорректная ссылка на композицию.');
 const response=await fetch(apiUrl('/api/song-shares/'+id),{signal:AbortSignal.timeout(20000)}),data=await response.json();
 if(!response.ok)throw Error(data.error||'Не удалось открыть композицию.');return normalizeSong(data.song);
}
let cached=null;
export async function showSongShare({getSong,getPrefs,save,privateTrial=false}){
 if(!save())return;
 const song=snapshot(getSong(),{...getPrefs(),line:0}),player=window.kvintaPlayer;
 player.stop();player.openModal('Поделиться песней','<div class="ke-share-body"><p class="ke-share-status" role="status">Подготавливаю ссылку…</p><div class="ke-share-ready" hidden><textarea class="ke-share-url" readonly aria-label="Ссылка на композицию"></textarea><div class="ke-share-buttons"><button class="ke-share-send">Отправить</button><button class="ke-share-copy">Копировать сообщение</button></div><p class="ke-share-limit"></p></div></div>');
 const body=document.querySelector('.ke-share-body');
 try{
  const raw=JSON.stringify(song),digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(raw))),x=>x.toString(16).padStart(2,'0')).join('');
  let url;
  if(cached?.digest===digest)url=cached.url;
  else{const response=await fetch(apiUrl('/api/song-shares'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({song}),signal:AbortSignal.timeout(25000)}),data=await response.json();if(!response.ok)throw Error(data.error||'Не удалось подготовить ссылку.');url=data.url;cached={digest,url};}
  if(!body.isConnected)return;
  body.querySelector('.ke-share-status').textContent='Аккорды, доли, темп и пометки сохранены в этой версии.';
  body.querySelector('.ke-share-url').value=url;body.querySelector('.ke-share-ready').hidden=false;
  body.querySelector('.ke-share-limit').textContent=privateTrial?'В закрытой пробе ссылку можете открыть только вы. Обмен с друзьями — после выхода раздела в основной Квинте.':'';
  const message='Квинта. — композиция «'+song.title+'»\nТекст, аккорды и мои пометки для репетиции.\n'+url;
  body.querySelector('.ke-share-copy').onclick=async()=>{try{await navigator.clipboard.writeText(message);body.querySelector('.ke-share-status').textContent='Сообщение со ссылкой скопировано.';}catch{const input=body.querySelector('.ke-share-url');input.focus();input.select();body.querySelector('.ke-share-status').textContent='Выделил ссылку. Скопируйте её через меню телефона.';}};
  body.querySelector('.ke-share-send').onclick=async()=>{if(!navigator.share){body.querySelector('.ke-share-copy').click();return;}try{await navigator.share({title:'Квинта. — '+song.title,text:'Композиция «'+song.title+'»: текст, аккорды и мои пометки для репетиции.',url});}catch(e){if(e.name!=='AbortError')body.querySelector('.ke-share-status').textContent='Не удалось открыть отправку. Скопируйте сообщение со ссылкой.';}};
 }catch(e){if(body.isConnected){body.querySelector('.ke-share-status').textContent=e.message||'Не удалось подготовить ссылку.';const retry=document.createElement('button');retry.textContent='Попробовать ещё раз';retry.className='kl-primary';retry.onclick=()=>showSongShare({getSong,getPrefs,save,privateTrial});body.append(retry);}}
}
