import {QUICK_OPTIONS,QUICK_ACTION_LIMIT,quickActions} from './song-settings.js';
import {showQuickSettings} from '../modules/settings-menu.js';
export function quickActionIcon(option){return option.id==='clicks'?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 3-5 18h16L15 3ZM8 15h8M12 16l5-10"/><circle cx="17" cy="6" r="1.5"/></svg>':'<i data-lucide="'+option.icon+'" aria-hidden="true"></i>';}
export function mountQuickActions({phone,player,initial,onChange,onTorch,notify}){
 let actions=quickActions(initial);if(Array.isArray(initial)&&JSON.stringify(initial)!==JSON.stringify(actions))onChange(actions.slice());const doc=phone.ownerDocument,bar=doc.createElement('div');bar.className='ks-quick-actions';bar.setAttribute('role','toolbar');bar.setAttribute('aria-label','Быстрые настройки');phone.querySelector('.qs-transport').before(bar);
 const icons=()=>globalThis.lucide?.createIcons();let rendered='',pointer=null,hold=null,skipUntil=0;
 bar.tabIndex=0;bar.setAttribute('aria-description','Удерживайте панель, чтобы настроить кнопки. С клавиатуры: Shift и F10.');
 function render(){const state=player.getState(),signature=JSON.stringify(actions.map(id=>[id,!!state[id]]));if(rendered===signature)return;rendered=signature;bar.replaceChildren();for(const id of actions){const option=QUICK_OPTIONS.find(x=>x.id===id),button=doc.createElement('button');button.type='button';button.setAttribute('aria-label',option.label);button.title=option.label;button.setAttribute('aria-pressed',String(!!state[id]));button.innerHTML=quickActionIcon(option);button.onclick=()=>{const value=!player.getState()[id];player.change({[id]:value});notify(option.label+(value?' — вкл.':' — выкл.'));if(id==='torch')onTorch(value);};bar.append(button);}if(!actions.length){const hint=doc.createElement('span');hint.className='kw-quick-hint';hint.textContent='Удерживайте, чтобы настроить';bar.append(hint);}bar.dataset.full=String(actions.length===QUICK_ACTION_LIMIT);icons();}
 function persist(){actions=quickActions(actions);onChange(actions);render();}
 function configure(){player.stop();return showQuickSettings({doc,getValue:()=>actions,onChange:next=>{actions=quickActions(next);persist();}});}
 function cancelHold(){clearTimeout(hold);hold=null;pointer=null;bar.classList.remove('kw-holding');}
 bar.addEventListener('pointerdown',event=>{if(event.button!==0||event.isPrimary===false)return;cancelHold();pointer={id:event.pointerId,x:event.clientX,y:event.clientY};hold=setTimeout(()=>{hold=null;skipUntil=performance.now()+1200;bar.classList.remove('kw-holding');configure();},600);bar.classList.add('kw-holding');},true);
 bar.addEventListener('pointermove',event=>{if(pointer?.id===event.pointerId&&Math.hypot(event.clientX-pointer.x,event.clientY-pointer.y)>9)cancelHold();},true);
 bar.addEventListener('pointerup',cancelHold,true);bar.addEventListener('pointercancel',cancelHold,true);bar.addEventListener('pointerleave',cancelHold);
 bar.addEventListener('click',event=>{if(performance.now()<skipUntil){event.preventDefault();event.stopImmediatePropagation();}},true);
 bar.addEventListener('contextmenu',event=>{event.preventDefault();});
 bar.addEventListener('keydown',event=>{if(event.key==='ContextMenu'||event.key==='F10'&&event.shiftKey){event.preventDefault();cancelHold();configure();}});
 doc.addEventListener('visibilitychange',()=>{if(doc.hidden)cancelHold();});
 window.addEventListener('kvinta:song-state',render);render();return {configure,setActions(next){actions=quickActions(next);persist();},get actions(){return [...actions];}};
}
