const median=values=>{const sorted=[...values].sort((a,b)=>a-b),middle=Math.floor(sorted.length/2);return sorted.length%2?sorted[middle]:(sorted[middle-1]+sorted[middle])/2;};

export function createRecordingTapEstimator({minBpm=40,maxBpm=220,minIntervals=3,maxIntervals=9,doubleTapSeconds=.18,resetAfterSeconds=2.2}={}){
 let last=null,intervals=[],scale=1;
 function state(){
  const center=intervals.length?median(intervals):null,usable=center===null?[]:intervals.filter(value=>Math.abs(value-center)<=center*.2);
  const raw=usable.length>=minIntervals?60/(usable.reduce((sum,value)=>sum+value,0)/usable.length):null;
  const stable=raw!==null&&median(usable.map(value=>Math.abs(value-center)))/center<=.1;
  const bpm=raw===null?null:Math.round(raw*scale),within=value=>value!==null&&value>=minBpm&&value<=maxBpm;
  return {bpm,stable,taps:last===null?0:intervals.length+1,usableIntervals:usable.length,inRange:within(bpm),canHalve:stable&&within(raw*scale/2),canDouble:stable&&within(raw*scale*2)};
 }
 function reset(){last=null;intervals=[];scale=1;return state();}
 function tap(at){
  if(!Number.isFinite(at))return {...state(),ignored:true};
  if(last===null){last=at;return state();}
  const elapsed=at-last;
  if(elapsed>=0&&elapsed<doubleTapSeconds)return {...state(),ignored:true};
  if(elapsed<=0||elapsed>resetAfterSeconds){reset();last=at;return state();}
  last=at;intervals.push(elapsed);intervals=intervals.slice(-maxIntervals);return state();
 }
 function adjust(factor){const current=state();if(factor===.5&&current.canHalve||factor===2&&current.canDouble)scale*=factor;return state();}
 return {tap,reset,adjust,state};
}

export function createRecordingTempoTap({getSong,getTime,isPlaying,getRate=()=>1,onRecord,estimator=createRecordingTapEstimator()}){
 let identity=null;
 function sync(){const song=getSong(),record=song.recording,key=record?JSON.stringify([song.id,record.localId,record.name,record.duration]):null;if(key!==identity){identity=key;estimator.reset();}return record;}
 function state(){const record=sync(),value=estimator.state();return {...value,canTap:!!record&&isPlaying()&&Math.abs(getRate()-1)<.0001,canApply:!!record&&value.stable&&value.inRange};}
 function tap(){const current=state();if(!current.canTap)return {...current,ignored:true};estimator.tap(getTime());return state();}
 function reset(){sync();estimator.reset();return state();}
 function adjust(factor){sync();estimator.adjust(factor);return state();}
 function apply(){const value=state();if(!value.canApply)return null;const record=getSong().recording;onRecord({...record,referenceBpm:value.bpm,tempoVerified:true});return value.bpm;}
 return {tap,reset,adjust,apply,state};
}
