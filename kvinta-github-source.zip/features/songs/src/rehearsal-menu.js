import {showCommonSettings} from '../modules/settings-menu.js';
export function organizeRehearsalMenu({phone,player,toolbar,songTorch,openHelp}){
 player.closeModal();
 return showCommonSettings({doc:phone.ownerDocument,getRehearsal:()=>player.getState(),
  onPreferences:patch=>{if('theme'in patch){const theme=patch.theme||'auto';player.change({theme});window.dispatchEvent(new CustomEvent('kvinta:theme',{detail:theme}));}},
  onRehearsal:patch=>player.change(patch),onQuick:actions=>toolbar.setActions(actions),
  onBeforeSound:()=>{player.stop();window.kvintaRecording?.pause();},onTorch:()=>songTorch.open(),
  onHelp:openHelp,onRecording:()=>window.kvintaRecording?.open(),openSheet:(title,body)=>player.openModal(title,body)
 });
}
