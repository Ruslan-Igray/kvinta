import {APP_SOUNDS} from '../modules/ui-sounds.js';
import {appSound,readPreferences,savePreferences} from '../modules/preferences.js';
import {createClickFeedback} from '../modules/feedback.js';
import {playbackAudio} from '../modules/playback-audio.js';
import {showVisualRhythmSettings} from '../modules/visual-rhythm.js';
import {mountUpdateControls} from '../modules/live-updates.js';
import {showAppShare} from '../modules/application-sharing.js';
import {mountSettingsMenu,toolPreferencesControls,showQuickSettings,readRehearsalPreferences} from '../modules/settings-menu.js';
export function organizeRehearsalMenu({phone,player,toolbar,songTorch,openHelp,version}){
 const doc=phone.ownerDocument,content=phone.querySelector('.qs-modal-content'),heading=content.querySelector('h2');
 const groups={sound:[],light:[],rehearsal:[],tools:toolPreferencesControls({doc}),app:[]};
 const font=content.querySelector('.qs-font-slider')?.closest('label');if(font)groups.rehearsal.push(font);
 for(const input of content.querySelectorAll('[data-setting]')){const id=input.dataset.setting;groups[['clicks','countIn'].includes(id)?'sound':['screenBlink','torch'].includes(id)?'light':'rehearsal'].push(input.closest('label'));}
 const theme=content.querySelector('.ke-theme')?.closest('label');if(theme)groups.app.push(theme);
 for(const button of content.querySelectorAll(':scope > button'))groups.rehearsal.push(button);
 function action(group,text,fn){const button=doc.createElement('button');button.type='button';button.className='kvs-action';button.textContent=text;button.onclick=fn;groups[group].push(button);return button;}
 action('rehearsal','Быстрые кнопки',()=>showQuickSettings({doc,getValue:()=>readRehearsalPreferences().quickActions,onChange:actions=>toolbar.setActions(actions)}));
 action('light','Вид такта',()=>showVisualRhythmSettings());
 action('light','Подключение фотовспышки',()=>songTorch.open());
 const sound=doc.createElement('label');sound.className='ks-app-sound';sound.innerHTML='<span>Звук приложения</span><select aria-label="Звук приложения">'+APP_SOUNDS.map(s=>'<option value="'+s.id+'">'+s.label+'</option>').join('')+'</select>';
 const select=sound.querySelector('select');select.value=appSound();select.onchange=()=>savePreferences({metronome:{sound:select.value}});groups.sound.unshift(sound);
 const feedback=createClickFeedback({getSound:()=>appSound()});
 action('sound','Воспроизвести звук',()=>{void feedback.play();});
 action('sound','Восстановить звук',async()=>{player.stop();await playbackAudio.restore();void feedback.play();});
 const tips=doc.createElement('label');tips.className='qs-option';tips.innerHTML='<span>Подсказки при запуске</span><input type="checkbox" aria-label="Подсказки при запуске">';tips.querySelector('input').checked=readPreferences().startupTips!==false;tips.querySelector('input').onchange=e=>savePreferences({startupTips:e.target.checked});groups.app.push(tips);
 action('app','Как репетировать и редактировать',openHelp);
 action('app','Добавить на экран телефона',()=>{player.closeModal();window.dispatchEvent(new Event('kvinta:install'));});
 action('app','Поделиться приложением',()=>showAppShare({openSheet:(title,body)=>player.openModal(title,body),doc}));
 const creator=doc.createElement('a');creator.className='kvs-action';creator.href='https://t.me/ruscooool';creator.target='_blank';creator.rel='noopener noreferrer';creator.textContent='Написать создателю';groups.app.push(creator);
 const updates=doc.createElement('div');groups.app.push(updates);
 const footer=doc.createElement('p');footer.textContent='Квинта. · '+version;
 const menu=mountSettingsMenu({content,groups,footer,heading});mountUpdateControls(updates,{beforeApply:()=>player.closeModal()});return menu;
}
