import {APP_SOUNDS} from '../modules/ui-sounds.js';
import {appSound,readPreferences,savePreferences} from '../modules/preferences.js';
import {createClickFeedback} from '../modules/feedback.js';
import {playbackAudio} from '../modules/playback-audio.js';
import {showVisualRhythmSettings} from '../modules/visual-rhythm.js';
import {mountUpdateControls} from '../modules/live-updates.js';
import {showAppShare} from '../modules/application-sharing.js';
export function organizeRehearsalMenu({phone,player,toolbar,songTorch,openHelp,version}){
 const doc=phone.ownerDocument,content=phone.querySelector('.qs-modal-content');
 content.querySelector('h2').textContent='Настройки репетиции';
 const tabs=doc.createElement('div');tabs.className='ks-settings-tabs';tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','Раздел настроек');
 const panels=doc.createElement('div');panels.className='ks-settings-panels';
 const sections=[['play','Игра'],['light','Экран и свет'],['app','Приложение']].map(([id,label],index)=>{
  const button=doc.createElement('button');button.type='button';button.textContent=label;button.id='ks-settings-'+id;button.setAttribute('role','tab');button.setAttribute('aria-controls','ks-panel-'+id);
  const panel=doc.createElement('section');panel.id='ks-panel-'+id;panel.setAttribute('role','tabpanel');panel.setAttribute('aria-labelledby',button.id);tabs.append(button);panels.append(panel);
  button.onclick=()=>sections.forEach((section,i)=>{section.panel.hidden=i!==index;section.button.setAttribute('aria-selected',String(i===index));section.button.tabIndex=i===index?0:-1;});
  return {button,panel};
 });
 function move(node,index){if(node)sections[index].panel.append(node);}
 move(content.querySelector('.qs-font-slider')?.closest('label'),0);
 for(const input of content.querySelectorAll('[data-setting]'))move(input.closest('label'),['clicks','countIn','fullStart'].includes(input.dataset.setting)?0:1);
 move(content.querySelector('.ke-theme')?.closest('label'),2);
 for(const button of content.querySelectorAll(':scope > button'))move(button,0);
 function action(index,text,fn){const button=doc.createElement('button');button.type='button';button.className='ke-help-link';button.textContent=text;button.onclick=fn;sections[index].panel.append(button);return button;}
 action(0,'Быстрые кнопки',()=>toolbar.configure());
 action(1,'Вид такта и интенсивность',()=>showVisualRhythmSettings());
 action(1,'Подключение фотовспышки',()=>songTorch.open());
 const note=doc.createElement('p');note.className='ks-settings-note';note.textContent='На быстром темпе камера отмечает доли через равные интервалы. Пропущенные импульсы не догоняются.';sections[1].panel.append(note);
 const sound=doc.createElement('label');sound.className='ks-app-sound';sound.innerHTML='<span>Звук приложения</span><select aria-label="Звук приложения">'+APP_SOUNDS.map(s=>'<option value="'+s.id+'">'+s.label+'</option>').join('')+'</select>';
 const select=sound.querySelector('select');select.value=appSound();select.onchange=()=>savePreferences({metronome:{sound:select.value}});sections[2].panel.append(sound);
 const feedback=createClickFeedback({getSound:()=>appSound()});
 action(2,'Воспроизвести звук',()=>{void feedback.play();});
 action(2,'Восстановить звук',async()=>{player.stop();await playbackAudio.restore();void feedback.play();});
 const tips=doc.createElement('label');tips.className='qs-option';tips.innerHTML='<span>Подсказки при запуске</span><input type="checkbox" aria-label="Подсказки при запуске">';tips.querySelector('input').checked=readPreferences().startupTips!==false;tips.querySelector('input').onchange=e=>savePreferences({startupTips:e.target.checked});sections[2].panel.append(tips);
 const updates=doc.createElement('div');sections[2].panel.append(updates);
 action(2,'Как репетировать и редактировать',openHelp);
 action(2,'Добавить на экран телефона',()=>{player.closeModal();window.dispatchEvent(new Event('kvinta:install'));});
 action(2,'Поделиться приложением',()=>showAppShare({openSheet:(title,body)=>player.openModal(title,body),doc}));
 const footer=doc.createElement('p');footer.className='ks-settings-note';footer.textContent='Квинта. · '+version+' · Общие настройки действуют и в инструментах.';sections[2].panel.append(footer);
 content.append(tabs,panels);mountUpdateControls(updates,{beforeApply:()=>player.closeModal()});sections[0].button.click();
}
