 export function upgrade220(input){
 let js=input;const edit=(a,b)=>{if(!js.includes(a))throw Error('Song 2.2 anchor: '+a.slice(0,90));js=js.replaceAll(a,b);};
 edit('return {bpm:clamp(',"return {meter:window.kvintaSongTiming.meter(value.meter).id,meterIndex:window.kvintaSongTiming.meters.findIndex(m=>m.id===window.kvintaSongTiming.meter(value.meter).id),bpm:clamp(");
 const keyField="'<div><label class=\"qs-field-label\" for=\"'+uid+'-key\">Тональность";
 edit(keyField,"'<div><label class=\"qs-field-label\" for=\"'+uid+'-meter\">Размер</label><button id=\"'+uid+'-meter\" class=\"qs-dial qs-meter cursor-interaction\" role=\"spinbutton\" aria-label=\"Размер песни\" aria-valuemin=\"1\" aria-valuemax=\"11\" aria-valuenow=\"3\"><span class=\"qs-dial-values\" aria-hidden=\"true\"><span data-step=\"-1\">3/4</span><span data-step=\"0\">4/4</span><span data-step=\"1\">5/4</span></span></button></div>'+\n   "+keyField);
 edit("   paintDial($('.qs-key'),state.key,", "   const meter=window.kvintaSongTiming.meter(state.meter);paintDial($('.qs-meter'),state.meterIndex,n=>window.kvintaSongTiming.meters[n]?.id||'—');$('.qs-bpm').previousElementSibling.textContent='Темп · '+meter.unit+' BPM';\n   for(const pulse of phone.querySelectorAll('.qs-pulse'))if(pulse.children.length!==meter.beats)pulse.innerHTML='<i></i>'.repeat(meter.beats);$('.qs-beat-strip>span').textContent=state.meter;$('.qs-focus-context').textContent=state.meter;phone.dataset.recording=String(!!window.kvintaRecording?.following);\n   paintDial($('.qs-key'),state.key,");
 edit("(window.kvintaSongPreview?.subtitle||'Учебный пример · 4/4')","(window.kvintaSongPreview?.subtitle||'Своя песня')+' · '+state.meter");
 edit("const read=state.mode==='uniform'?readingPosition():null;","const read=!window.kvintaRecording?.requested&&state.mode==='uniform'?readingPosition():null;");
 edit("beat%4", "beat%window.kvintaSongTiming.meter(state.meter).beats");
 edit("bindDial($('.qs-bpm'),'bpm',40,220);", "bindDial($('.qs-meter'),'meterIndex',0,window.kvintaSongTiming.meters.length-1);bindDial($('.qs-bpm'),'bpm',40,220);");
 edit("if(next!==state[key])change({[key]:next});", "if(next!==state[key]){void window.kvintaSongTiming.click();change({[key]:next});}");
 edit('function change(patch){Object.assign(state,patch);',"function change(patch){if('bpm' in patch&&window.kvintaRecording&&!window.kvintaRecording.setTempo(patch.bpm)){announce('Для записи доступно изменение темпа от четверти до четырёх исходных темпов.');return;}if('meterIndex' in patch)patch.meter=window.kvintaSongTiming.meters[patch.meterIndex].id;if('meter' in patch)patch.meterIndex=window.kvintaSongTiming.meters.findIndex(m=>m.id===patch.meter);Object.assign(state,patch);");
 edit('window.kvintaSongEffects?.stop();running=false;', 'window.kvintaSongEffects?.stop();window.kvintaRecording?.pause();running=false;');
 edit('  function loop(now){\n   if(!running)return;',`  function loop(now){
   if(!running)return;
   if(window.kvintaRecording?.requested){
    const position=window.kvintaRecording.beat();if(position===null){stop();return;}
    const dt=Math.min(.1,Math.max(0,(now-previous)/1000));previous=now;beats=position;
    const offsets=starts();let index=0;for(let i=0;i<lineNodes.length;i++)if(beats>=offsets[i])index=i;
    if(index!==current)highlight(index);const phase=clamp((beats-offsets[index])/lineBeats(index),0,1);uniformRead={index,phase};
    const desired=playbackTarget(index,phase);reader.scrollTop=window.kvintaSongScroll.followReadingScroll(reader.scrollTop,desired,dt);paintChord();
    const pulse=Math.floor(window.kvintaRecording.pulse());if(pulse!==lastBeat){lastBeat=pulse;beatPulse(pulse,now);}frame=requestAnimationFrame(loop);return;
   }`);
 edit('const begin=()=>{starting=false;',"const begin=async()=>{if(window.kvintaRecording?.requested){try{await window.kvintaRecording.play();}catch{stop();announce('Не удалось включить запись. Откройте её и повторите.');return;}if(!starting||token!==startGeneration){window.kvintaRecording.pause();return;}}starting=false;");
 edit("starting=true;running=true;paintTransport();const token=++startGeneration;await Promise.all([", "starting=true;running=true;paintTransport();const token=++startGeneration;try{if(window.kvintaRecording?.requested&&!await window.kvintaRecording.prepare()){stop();window.kvintaRecording.open();return;}}catch{stop();announce('Не удалось включить запись. Нажмите Старт ещё раз.');return;}if(!starting||token!==startGeneration)return;await Promise.all([");
 edit("if(ended){beats=0;", "if(ended){window.kvintaRecording?.restart();beats=0;");
 edit("stop();hasPlayed=false;beats=0;", "stop();window.kvintaRecording?.restart();hasPlayed=false;beats=0;");
 edit('highlight(index);uniformRead={index,phase:0};scrollToLine(index);', 'highlight(index);uniformRead={index,phase:0};window.kvintaRecording?.seekLine(index);scrollToLine(index);');
 edit('beats=starts()[current]+read.phase*lineBeats(current);paintChord();', 'beats=starts()[current]+read.phase*lineBeats(current);window.kvintaRecording?.seekBeat(beats);paintChord();');
 edit("window.kvintaPlayer={stop(){", "window.addEventListener('kvinta:recording-ended',()=>{if(window.kvintaRecording?.requested){stop({complete:true});persist();}});window.kvintaPlayer={stop(){");
 edit("e.target.closest('.qs-fullscreen-exit,.qs-overlay')","e.target.closest('.qs-fullscreen-exit,.qs-overlay,.ka-overlay')");
 edit("try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return;audio??=new C();if(audio.state!=='running')await audio.resume();}catch{}","try{audio=window.kvintaSongTiming.audioContext();await window.kvintaSongTiming.unlockAudio(audio);}catch{}");
 edit('starting=true;running=true;paintTransport();const token=',"starting=true;running=true;paintTransport();const outputReady=(state.countIn||state.clicks)?unlockAudio():Promise.resolve();const token=");
 edit('Promise.race([unlockAudio(),','Promise.race([outputReady,');
 edit('i===beat%window.kvintaSongTiming.meter(state.meter).beats','i===((beat%window.kvintaSongTiming.meter(state.meter).beats)+window.kvintaSongTiming.meter(state.meter).beats)%window.kvintaSongTiming.meter(state.meter).beats');
 edit("ended?'Конец песни':'Пауза'","ended?(window.kvintaRecording?.requested?'Конец записи':'Конец песни'):'Пауза'");
 edit("try{const osc=audio.createOscillator(),gain=audio.createGain(),at=audio.currentTime;osc.type='triangle';osc.frequency.setValueAtTime(accent?1250:850,at);gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(.12,at+.002);gain.gain.exponentialRampToValueAtTime(.0001,at+.04);osc.connect(gain);gain.connect(audio.destination);osc.onended=()=>{osc.disconnect();gain.disconnect();};osc.start(at);osc.stop(at+.045);}catch{}", "try{const source=audio.createBufferSource();source.buffer=window.kvintaSongTiming.soundBuffer(audio,accent);source.connect(audio.destination);source.onended=()=>source.disconnect();source.start();}catch{}");
 return js;
}
