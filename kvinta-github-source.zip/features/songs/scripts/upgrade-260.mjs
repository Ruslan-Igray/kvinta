export function upgrade260(input){
 let js=input;const edit=(from,to)=>{if(!js.includes(from))throw Error('Song workspace anchor missing: '+from.slice(0,90));js=js.replaceAll(from,to);};
 edit('  let geometryCache=null,uniformRead={index:state.line,phase:0},playbackScroll=null;',`  let geometryCache=null,uniformRead={index:state.line,phase:0},playbackScroll=null;
  const pinch=window.kvintaMountPinch?.({phone,reader,getSize:()=>state.fontSize,onStart:()=>{clearTap();smooth=null;mousePan=null;},onSize:fontSize=>{geometryCache=null;change({fontSize});},onEnd:()=>{uniformPosition=reader.scrollTop;playbackScroll=null;smooth=null;}});
`);
 edit('function followPlayback(target,dt){','function followPlayback(target,dt){if(pinch?.active)return;');
 edit('reader.scrollTop=Math.min(maxScroll(),uniformPosition);','if(!pinch?.active)reader.scrollTop=Math.min(maxScroll(),uniformPosition);');
 edit('function pauseForTouch(){if(window.kvintaEditing)return;','function pauseForTouch(){if(window.kvintaEditing||pinch?.blocked)return;');
 edit('function syncManualPosition(){if(window.kvintaEditing)return;','function syncManualPosition(){if(window.kvintaEditing||pinch?.blocked)return;');
 edit('if(!running&&!manualSeeking&&!window.kvintaEditing)scrollToLine(current);','if(!running&&!manualSeeking&&!window.kvintaEditing&&!pinch?.blocked)scrollToLine(current);');
 edit('const inReader=!!e.target.closest', 'if(pinch?.blocked)return;const inReader=!!e.target.closest');
 edit('phone.addEventListener(\'pointermove\',e=>{if(tapPointer','phone.addEventListener(\'pointermove\',e=>{if(pinch?.blocked)return;if(tapPointer');
 return js;
}
