export function upgradeSync(input){
 let js=input;const edit=(a,b)=>{if(!js.includes(a))throw Error('Song sync anchor: '+a.slice(0,100));js=js.replaceAll(a,b);};
 edit('  let geometryCache=null,','  const sync=window.kvintaCreateSongSync({getSettings:()=>state,makeBuffer:(ctx,event)=>window.kvintaSongTiming.soundBuffer(ctx,((event.ordinal%window.kvintaSongTiming.meter(state.meter).beats)+window.kvintaSongTiming.meter(state.meter).beats)%window.kvintaSongTiming.meter(state.meter).beats===0),onInterrupted:()=>{stop();announce("Звук прерван. Нажмите Старт ещё раз.");}});\n  let geometryCache=null,');
 edit('   startGeneration++;starting=false;','   sync.stop();startGeneration++;starting=false;');
 const a=js.indexOf('  function beatPulse('),b=js.indexOf('  function loop(',a);if(a<0||b<0)throw Error('Missing song beat visual');
 js=js.slice(0,a)+`  function beatPulse(beat,now){
   const meter=window.kvintaSongTiming.meter(state.meter),index=((beat%meter.beats)+meter.beats)%meter.beats;
   phone.querySelectorAll('.qs-pulse').forEach(group=>group.querySelectorAll('i').forEach((el,i)=>el.classList.toggle('active',i===index)));
   if(!window.kvintaSongTiming.flashOnBeat({part:0,beat:index,ordinal:beat,bpm:state.bpm}))return;
   if(state.torch)window.kvintaSongEffects?.pulse(now);
   if(!reduced.matches&&state.screenBlink){screenAnimation?.cancel();screenAnimation=$('.qs-screen-pulse').animate([{opacity:.12},{opacity:0}],{duration:170,easing:'ease-out'});}
  }
`+js.slice(b);
 edit('   beats+=dt*state.bpm/60;','   beats=sync.position();');
 edit('   const beat=Math.floor(beats);\n   if(beat!==lastBeat){lastBeat=beat;beatPulse(beat,now);}', '');
 edit('const pulse=Math.floor(window.kvintaRecording.pulse());if(pulse!==lastBeat){lastBeat=pulse;beatPulse(pulse,now);}', '');
 edit('  function loop(now){\n   if(!running)return;', '  function loop(now){\n   if(!running)return;\n   const tick=sync.drain().at(-1);if(tick){lastBeat=tick.ordinal;beatPulse(tick.ordinal,tick.performanceTime??now);}');
 edit('starting=false;counter.hidden=true;manualSeeking=false;running=true;', 'if(!sync.running&&!sync.start({context:audio,position:beats,external:window.kvintaRecording?.requested?()=>window.kvintaRecording.rhythmClock():null})){stop();announce("Не удалось включить звук. Нажмите Старт ещё раз.");return;}starting=false;counter.hidden=true;manualSeeking=false;running=true;');
 edit("const outputReady=(state.countIn||state.clicks)?unlockAudio():Promise.resolve();",'const outputReady=unlockAudio();');
 edit('(state.countIn||state.clicks)?Promise.race([outputReady,new Promise(resolve=>setTimeout(resolve,500))]):Promise.resolve()', 'Promise.race([outputReady,new Promise(resolve=>setTimeout(resolve,1500))])');
 edit('Object.assign(state,patch);update();persist();window.dispatchEvent','Object.assign(state,patch);sync.refresh();update();persist();window.dispatchEvent');
 edit('function sticks(){','function sticks(when){');
 edit('gain=audio.createGain(),at=audio.currentTime;', 'gain=audio.createGain(),at=when??audio.currentTime;');
 edit('osc.stop(at+.05);', 'osc.stop(at+.05);return osc;');
 edit('countIn.start({bpm:state.bpm,onBeat:n=>{counter.textContent=String(n);sticks();},onDone:begin});','countIn.start({bpm:state.bpm,context:audio,onSchedule:at=>sticks(at),outputTime:()=>window.kvintaSongTiming.audioOutputTime(audio),onScheduleEnd:when=>{if(!window.kvintaRecording?.requested)sync.start({context:audio,position:beats,when});},onInterrupted:()=>{stop();announce("Звук прерван.");},onBeat:n=>{counter.textContent=String(n);},onDone:begin});');
 edit('if(!sync.running&&!sync.start(', 'if(audio?.state!=="running")await unlockAudio();if(!starting||token!==startGeneration)return;if(!sync.running&&!sync.start(');
 edit('if(!starting||token!==startGeneration)return;if(state.countIn){', 'if(!starting||token!==startGeneration)return;await unlockAudio();if(!starting||token!==startGeneration)return;if(audio?.state!=="running"){stop();announce("Не удалось запустить звук.");return;}if(state.countIn){');
 const clickStart=js.indexOf('  function clickSound('),clickEnd=js.indexOf('  function stop(',clickStart);if(clickStart<0||clickEnd<0)throw Error('Missing obsolete frame click');js=js.slice(0,clickStart)+js.slice(clickEnd);
 return js;
}
