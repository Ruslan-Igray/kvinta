import http from 'node:http';
import {createHmac,randomBytes} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {songsRequest} from '../../features/songs/worker/songs.js';

const ORIGINS=new Set(['https://ruslan-igray.github.io','https://kvinta-guitar-circle.sappy-mule-8607.chatgpt.site']);
const ROUTES=new Set(['/api/songs/search','/api/songs/artist','/api/songs/import']);
// No lyrics, search queries, cookies or raw network addresses are logged or stored.
export function createSearchServer({handler=songsRequest,now=Date.now,perClient=180,total=3000,maxActive=8}={}){
 const secret=randomBytes(32),clients=new Map();let hour=-1,hits=0,active=0;
 const server=http.createServer(async(req,res)=>{
  const origin=req.headers.origin,cors=ORIGINS.has(origin)?{'Access-Control-Allow-Origin':origin,Vary:'Origin','Access-Control-Allow-Methods':'GET, OPTIONS','Access-Control-Allow-Headers':'Content-Type','Access-Control-Max-Age':'600'}:{};
  const send=(status,data,headers={})=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...cors,...headers});res.end(JSON.stringify(data));};
  if((req.url||'').length>12000){send(414,{error:'Слишком длинный запрос.'});return;}
  const url=new URL(req.url||'/','http://search.local');
  if(url.pathname==='/health'&&req.method==='GET'){send(200,{ok:true,service:'kvinta-search'});return;}
  if(!ORIGINS.has(origin)){send(403,{error:'Этот адрес не поддерживается.'});return;}
  if(!ROUTES.has(url.pathname)){send(404,{error:'Страница не найдена.'});return;}
  if(req.method==='OPTIONS'){res.writeHead(204,cors);res.end();return;}
  if(req.method!=='GET'){send(405,{error:'Поддерживается GET.'},{Allow:'GET, OPTIONS'});return;}
  const current=Math.floor(now()/3600000);if(current!==hour){hour=current;hits=0;clients.clear();}
  // Use the direct peer only. Untrusted forwarded headers cannot bypass quotas.
  const client=createHmac('sha256',secret).update(String(hour)+':'+req.socket.remoteAddress).digest('hex'),count=clients.get(client)||0;
  if(hits>=total||count>=perClient){send(429,{error:'Много запросов. Попробуйте позже.'},{'Retry-After':'3600'});return;}
  if(active>=maxActive){send(503,{error:'Сервис занят. Повторите поиск немного позже.'},{'Retry-After':'5'});return;}
  hits++;clients.set(client,count+1);active++;
  try{const result=await handler(new Request(url));if(!result){send(404,{error:'Страница не найдена.'});return;}send(result.status,await result.json());}
  catch{send(502,{error:'Не удалось связаться с источниками песен. Попробуйте позже.'});}
  finally{active--;}
 });
 server.requestTimeout=20000;server.headersTimeout=10000;server.keepAliveTimeout=5000;
 return server;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 const port=Number(process.env.PORT)||8080,server=createSearchServer();server.listen(port,'0.0.0.0',()=>console.log('Kvinta search ready on port '+port));
 for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{server.close(()=>process.exit(0));setTimeout(()=>process.exit(1),15000).unref();});
}
