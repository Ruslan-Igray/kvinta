export const EVENT_TYPES=['launch','active','install','share_copy','share_send','set_open','set_save'];
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const PLATFORMS=['ios','android','desktop','other'];
const DAY=86400000,MAX_AGE=7*DAY;
const encoder=new TextEncoder();
export const moscowDay=at=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Moscow',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(at));
const bytes64=bytes=>btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const from64=text=>Uint8Array.from(atob(text.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
async function signingKey(secret){return crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);}
export async function issueToken(claims,secret){const payload=bytes64(encoder.encode(JSON.stringify(claims))),signature=await crypto.subtle.sign('HMAC',await signingKey(secret),encoder.encode(payload));return payload+'.'+bytes64(new Uint8Array(signature));}
export async function verifyToken(token,secret,origin,now){
 try{if(typeof token!=='string'||token.length>1500)return null;const [payload,sig,...rest]=token.split('.');if(rest.length||!payload||!sig)return null;if(!await crypto.subtle.verify('HMAC',await signingKey(secret),from64(sig),encoder.encode(payload)))return null;const c=JSON.parse(new TextDecoder().decode(from64(payload)));return UUID.test(c.id)&&c.origin===origin&&Number.isFinite(c.exp)&&c.exp>now&&c.exp<=now+3*DAY&&['sites','github'].includes(c.source)&&PLATFORMS.includes(c.platform)?c:null;}catch{return null;}
}
export async function verifyReportTicket(token,secret,origin,period,source,now){
 try{const [version,payload,sig,...rest]=String(token).split('.');if(version!=='r1'||rest.length||token.length>1800||!payload||!sig)return false;const key=await signingKey(secret);if(!await crypto.subtle.verify('HMAC',key,from64(sig),encoder.encode('r1.'+payload)))return false;const c=JSON.parse(new TextDecoder().decode(from64(payload)));return c.role==='report'&&c.origin===origin&&c.period===period&&c.source===source&&Number.isFinite(c.iat)&&c.iat<=now+30000&&c.exp===c.iat+120000&&c.exp>now&&UUID.test(c.nonce);}catch{return false;}
}
export async function sameSecret(a,b){if(!a||!b)return false;const [x,y]=await Promise.all([crypto.subtle.digest('SHA-256',encoder.encode(a)),crypto.subtle.digest('SHA-256',encoder.encode(b))]);let different=0;const p=new Uint8Array(x),q=new Uint8Array(y);for(let i=0;i<p.length;i++)different|=p[i]^q[i];return different===0;}
const json=(value,status=200,headers={})=>new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
async function body(request,max=8192){if(!request.headers.get('content-type')?.startsWith('application/json'))throw Error('type');if(Number(request.headers.get('content-length'))>max)throw Error('size');const raw=await request.text();if(raw.length>max)throw Error('size');return JSON.parse(raw);}
export function validateEvents(value,now){
 if(!value||Object.keys(value).some(k=>k!=='events')||!Array.isArray(value.events)||value.events.length<1||value.events.length>20)throw Error('batch');
 return value.events.map(e=>{if(!e||Object.keys(e).some(k=>!['id','type','at'].includes(k))||!UUID.test(e.id)||!EVENT_TYPES.includes(e.type)||!Number.isInteger(e.at)||e.at<now-MAX_AGE||e.at>now+120000)throw Error('event');return {...e,at:Math.min(e.at,now),day:moscowDay(Math.min(e.at,now))};});
}
function allowedOrigin(request,env){const origin=request.headers.get('origin');const allowed=(env.TELEMETRY_ORIGINS||'https://kvinta-guitar-circle.sappy-mule-8607.chatgpt.site,https://ruslan-igray.github.io').split(',');return origin&&allowed.includes(origin)?origin:null;}
export async function ingest(db,claims,events){
 const first=Math.min(...events.map(e=>e.at)),last=Math.max(...events.map(e=>e.at)),installed=events.filter(e=>e.type==='install').map(e=>e.at),at=installed.length?Math.min(...installed):null;
 const statements=[db.prepare(`INSERT INTO telemetry_instances(id,source,platform,first_seen,last_seen,installed_at) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET first_seen=MIN(first_seen,excluded.first_seen),last_seen=MAX(last_seen,excluded.last_seen),installed_at=CASE WHEN installed_at IS NULL THEN excluded.installed_at WHEN excluded.installed_at IS NULL THEN installed_at ELSE MIN(installed_at,excluded.installed_at) END`).bind(claims.id,claims.source,claims.platform,first,last,at)];
 for(const e of events)statements.push(db.prepare(`INSERT OR IGNORE INTO telemetry_events(id,instance_id,type,day,occurred_at) SELECT ?,?,?,?,? WHERE (SELECT COUNT(*) FROM telemetry_events WHERE instance_id=? AND day=?)<600`).bind(e.id,claims.id,e.type,e.day,e.at,claims.id,e.day));
 const results=await db.batch(statements);return results.slice(1).reduce((sum,r)=>sum+(r.meta?.changes||0),0);
}
export async function report(db,period='7',source='all',now=Date.now()){
 if(!['1','7','30','all'].includes(period)||!['all','sites','github'].includes(source))throw Error('filter');
 const today=moscowDay(now),since=period==='all'?'0000-00-00':moscowDay(now-(Number(period)-1)*DAY),start=period==='all'?0:Date.parse(since+'T00:00:00+03:00');
 const sourceSQL=source==='all'?'':' AND i.source=?',params=source==='all'?[since,today]:[since,today,source];
 const counts=await db.prepare(`SELECT e.type,COUNT(*) AS n FROM telemetry_events e JOIN telemetry_instances i ON i.id=e.instance_id WHERE e.day>=? AND e.day<=?${sourceSQL} GROUP BY e.type`).bind(...params).all();
 const active=await db.prepare(`SELECT COUNT(DISTINCT e.instance_id) AS n FROM telemetry_events e JOIN telemetry_instances i ON i.id=e.instance_id WHERE e.day>=? AND e.day<=?${sourceSQL}`).bind(...params).first();
 const installations=await db.prepare(`SELECT COUNT(*) AS n FROM telemetry_instances i WHERE i.installed_at>=? AND i.installed_at<=?${sourceSQL}`).bind(...(source==='all'?[start,now]:[start,now,source])).first();
 const daily=await db.prepare(`SELECT e.day,COUNT(DISTINCT e.instance_id) AS active,SUM(CASE WHEN e.type='launch' THEN 1 ELSE 0 END) AS launches,SUM(CASE WHEN e.type IN ('share_copy','share_send') THEN 1 ELSE 0 END) AS exchanges FROM telemetry_events e JOIN telemetry_instances i ON i.id=e.instance_id WHERE e.day>=? AND e.day<=?${sourceSQL} GROUP BY e.day ORDER BY e.day LIMIT 3660`).bind(...params).all();
 const first=await db.prepare('SELECT MIN(occurred_at) AS at FROM telemetry_events').first();
 const totals=Object.fromEntries(EVENT_TYPES.map(t=>[t,0]));for(const row of counts.results||[])totals[row.type]=Number(row.n)||0;
 return {period,source,timeZone:'Europe/Moscow',updatedAt:now,startedAt:first?.at||null,installations:Number(installations?.n)||0,active:Number(active?.n)||0,totals,daily:daily.results||[]};
}
export async function telemetryRequest(request,env,now=Date.now()){
 const url=new URL(request.url),route=url.pathname;if(!route.startsWith('/api/telemetry/'))return null;
 if(route==='/api/telemetry/report'){
  const origin=request.headers.get('origin'),trusted=(env.REPORT_ORIGINS||'https://kvinta-private-statistics.sappy-mule-8607.chatgpt.site').split(',').includes(origin),cors=trusted?{'Access-Control-Allow-Origin':origin,'Vary':'Origin','Access-Control-Allow-Methods':'GET, OPTIONS','Access-Control-Allow-Headers':'Authorization','Access-Control-Max-Age':'600'}:{};
  if(origin&&!trusted)return json({error:'origin'},403);if(request.method==='OPTIONS')return trusted?new Response(null,{status:204,headers:cors}):json({error:'origin'},403);if(request.method!=='GET')return json({error:'method'},405,cors);
  const period=url.searchParams.get('period')||'7',source=url.searchParams.get('source')||'all',credential=request.headers.get('authorization')?.replace(/^Bearer /,'');if(!['1','7','30','all'].includes(period)||!['all','github','sites'].includes(source))return json({error:'invalid-filter'},400,cors);
  const authorized=origin?trusted&&await verifyReportTicket(credential,env.STATS_READ_KEY,origin,period,source,now):await sameSecret(credential,env.STATS_READ_KEY);if(!authorized)return json({error:'unauthorized'},401,cors);
  try{if(!env.DB)return json({error:'storage-unavailable'},503,cors);return json(await report(env.DB,period,source,now),200,cors);}catch{return json({error:'report-unavailable'},503,cors);}
 }
 const origin=allowedOrigin(request,env);if(!origin)return json({error:'origin'},403);const cors={'Access-Control-Allow-Origin':origin,'Vary':'Origin','Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Max-Age':'600'};
 if(!['/api/telemetry/session','/api/telemetry/events'].includes(route))return json({error:'not-found'},404,cors);
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors});if(request.method!=='POST')return json({error:'method'},405,cors);if(!env.TELEMETRY_SIGN_KEY)return json({error:'not-ready'},503,cors);
 try{
  if(route.endsWith('/session')){let data;try{data=await body(request,1024);}catch{return json({error:'invalid-session'},400,cors);}if(!data||Object.keys(data).some(k=>!['id','platform'].includes(k))||!UUID.test(data.id)||!PLATFORMS.includes(data.platform))return json({error:'invalid-session'},400,cors);const exp=now+2*DAY,claims={id:data.id,platform:data.platform,source:origin==='https://ruslan-igray.github.io'?'github':'sites',origin,exp};return json({token:await issueToken(claims,env.TELEMETRY_SIGN_KEY),expiresAt:exp},200,cors);}
  const claims=await verifyToken(request.headers.get('authorization')?.replace(/^Bearer /,''),env.TELEMETRY_SIGN_KEY,origin,now);if(!claims)return json({error:'unauthorized'},401,cors);
  let events;try{events=validateEvents(await body(request),now);}catch{return json({error:'invalid-events'},400,cors);}if(!env.DB)return json({error:'storage-unavailable'},503,cors);return json({accepted:await ingest(env.DB,claims,events)},200,cors);
 }catch{return json({error:'unavailable'},503,cors);}
}
