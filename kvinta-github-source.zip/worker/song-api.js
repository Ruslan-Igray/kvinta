import {songsRequest} from '../features/songs/worker/songs.js';
import {sharesRequest} from '../features/songs/worker/shares.js';
const SONG_ORIGINS=['https://kvinta-guitar-circle.sappy-mule-8607.chatgpt.site','https://ruslan-igray.github.io'];
const songApiJson=(error,status,headers={})=>new Response(JSON.stringify({error}),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}});
export function songOriginAllowed(origin,url){return SONG_ORIGINS.includes(origin)||origin===url.origin&&['localhost','127.0.0.1','trial.test','test.local'].includes(url.hostname);}
let lastPrune=0;
export async function allowSongRequest(request,env,kind,now=Date.now()){
 const url=new URL(request.url);if(!env.DB||!env.TELEMETRY_SIGN_KEY)return ['localhost','127.0.0.1','trial.test','test.local'].includes(url.hostname);
 const hour=Math.floor(now/3600000),ip=request.headers.get('cf-connecting-ip')||'unknown';
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(env.TELEMETRY_SIGN_KEY),{name:'HMAC',hash:'SHA-256'},false,['sign']);
 const hash=await crypto.subtle.sign('HMAC',key,new TextEncoder().encode('song-rate:'+Math.floor(now/86400000)+':'+ip));
 const client=Array.from(new Uint8Array(hash),n=>n.toString(16).padStart(2,'0')).join('');
 const limits={share:[30,500],search:[180,3000],import:[120,1000]}[kind],expires=now+2*3600000;
 const hit=async(id,limit)=>{const row=await env.DB.prepare('INSERT INTO song_request_limits (id, hits, expires_at) VALUES (?, 1, ?) ON CONFLICT(id) DO UPDATE SET hits=hits+1 WHERE hits<? RETURNING hits').bind(id,expires,limit).first();return !!row;};
 if(now-lastPrune>60000){lastPrune=now;await env.DB.prepare('DELETE FROM song_request_limits WHERE expires_at < ?').bind(now).run();}
 // Both UPSERTs are atomic. Reject an exhausted client before touching shared quota.
 if(!await hit(kind+':'+hour+':'+client,limits[0]))return false;
 return hit(kind+':'+hour+':all',limits[1]);
}
export async function songApiRequest(request,env,{limit=allowSongRequest,fetcher=fetch}={}){
 const url=new URL(request.url),route=url.pathname;if(!route.startsWith('/api/songs/')&&!route.startsWith('/api/song-shares'))return null;
 const origin=request.headers.get('origin'),allowed=origin&&songOriginAllowed(origin,url);
 const cors=allowed?{'Access-Control-Allow-Origin':origin,'Vary':'Origin','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type','Access-Control-Max-Age':'600'}:{};
 if(origin&&!allowed)return songApiJson('Этот адрес не поддерживается.',403);
 if(request.method==='OPTIONS')return allowed?new Response(null,{status:204,headers:cors}):songApiJson('Не удалось проверить запрос.',403);
 const isShare=route==='/api/song-shares'&&request.method==='POST',isSource=['/api/songs/search','/api/songs/import','/api/songs/artist'].includes(route);
 if(isShare&&!allowed)return songApiJson('Не удалось проверить запрос.',403);
 try{
  if(isShare||isSource){if(!await limit(request,env,isShare?'share':route.endsWith('/search')?'search':'import'))return songApiJson('Слишком много запросов. Попробуйте немного позже.',429,{...cors,'Retry-After':'3600'});}
  const response=route.startsWith('/api/song-shares')?await sharesRequest(request,env):await songsRequest(request,fetcher);
  const result=new Response(response.body,response);for(const [key,value] of Object.entries(cors))result.headers.set(key,value);return result;
 }catch{return songApiJson('Сервис песен временно недоступен. Попробуйте ещё раз.',503,cors);}
}
