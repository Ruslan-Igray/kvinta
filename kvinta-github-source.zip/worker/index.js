import {telemetryRequest} from './telemetry.js';
// The build embeds the public frontend assets here, without runtime secrets.
export function createWorker(assets){return {async fetch(request,env){
 const telemetry=await telemetryRequest(request,env);if(telemetry)return telemetry;
 if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405});
 let pathname;try{pathname=decodeURIComponent(new URL(request.url).pathname);}catch{return new Response('Not found',{status:404});}if(pathname.endsWith('/'))pathname+='index.html';
 const asset=assets[pathname];if(!asset)return new Response('Not found',{status:404});
 const bytes=Uint8Array.from(atob(asset.data),c=>c.charCodeAt(0));return new Response(request.method==='HEAD'?null:bytes,{headers:{'Content-Type':asset.type,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff',...(pathname==='/sw.js'?{'Service-Worker-Allowed':'/'}:{})}});
}};}
