CREATE TABLE `song_request_limits` (
	`id` text PRIMARY KEY NOT NULL,
	`hits` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `song_request_limits_expiry` ON `song_request_limits` (`expires_at`);